# Getting Started

Tento SDK balík je určený pro MSVC x64 na Windows.

## Build ukázky

    cd <rozbaleny-sdk>
    powershell -NoProfile -ExecutionPolicy Bypass -File examples\build_example.ps1
    build\minimal_app.exe

## Struktura appky

Vedle finálního EXE ponech:

    my_app.exe
    skins\*.json
    fonts\...

Bez skinů a fontů aplikace pořád spadne na fallback vzhled, ale připravené WDUi skiny a app-local fonty jsou doporučená runtime cesta.

## Renderer

Výchozí renderer je wdui::RenderBackend::Auto, takže WDUi preferuje Direct2D/GPU cestu a umí spadnout na GDI fallback.

    wdui::setDefaultRenderBackend(wdui::RenderBackend::Auto);
    wdui::setDefaultPerformanceProfile(wdui::PerformanceProfile::Balanced);

Pro compatibility nebo low-power režim může aplikace před vytvořením oken nastavit RenderBackend::Gdi.

## Identita buildu

    const wdui::BuildInfo info = wdui::buildInfo();
    if (!info.includedHeaderMatchesLibrary) {
        // Header a linknuta knihovna nepatri ke stejnemu WDUi buildu.
    }

Do owner-facing About dialogu nebo servisního logu zapisuj info.summary nebo wdui::currentBuildInfoText(). Obsahuje lib build id, source id, konfiguraci, header id, default skin pack id a runtime skin pack id.