# WDUi výchozí JSON skiny

> **Cinematic refresh, October 2026:** 106 crafted preset skins now use
> harmonious secondary/tertiary tones, sculpted material panels, engraved inner
> rails and an intermittent `materials.edge_glint` contour sparkle. The bundled
> candle-like flame and broad fog/glow treatment are disabled. Old
> `flame_response` options below remain documented only for backwards
> compatibility with existing custom skins. The untouched `stellaris` and
> `taskboard-default` presets preserve framework baselines, and Windows 11
> Modern stays motion-free. Implementation rationale, controls and QA:
> [CINEMATIC_SKIN_DESIGN.md](../docs/CINEMATIC_SKIN_DESIGN.md).

Tato složka obsahuje sdílené připravené WDUi skin presety jako JSON data.
Aktuální sdílený katalog drží 108 skinů, přesně 54 světlých a 54 tmavých (včetně tmavého zděděného základu `taskboard-default`). `00-wdui-default-skins.json` drží
hlavní výchozí katalog včetně skinu `stellaris`, který přesně zachovává původní
bezskinový WDUi/SNC vzhled, a `taskboard-default`, který bez kopie palety přímo
dědí statický `Theme::taskBoardFamily()` základ Task Boardu. `01-wdui-black-gemstone-skins.json` přidává černé
gemstone/soft-glass varianty Emerald/Ruby/Sapphire/Amber Black a Neon Glass
Black/Neon Rose Black a `02-wdui-material-gallery-skins.json` přidává materiálovou galerii
kamenů, polodrahokamů a kovů. Celkem 106 tematických skinů používá
skeuomorfní povrchy a hmatové ovladače; `stellaris` a `taskboard-default`
zachovávají své přesné frameworkové fallbacky. `03-wdui-windows11-modern-skins.json`
obsahuje rodinu `win11-modern-auto`, `win11-modern-black` a
`win11-modern-white` se zaoblenou geometrií Windows 11, jemným kovovým lemem,
vystouplými ovladači a odpovídající světlou či tmavou paletou.
`04-wdui-cinematic-light-skins.json` přidává 50 barevně a materiálově samostatně laděných světlých companion variant (porcelán, perleť, světlý kámen, satin metal, jemné barevné sklo). Nová ID zachovávají původní skiny beze změny, skiny mají kontrastní tmavý text, jemnější filmový záblesk a žádný pohyblivý mlžný/ohnivý zdroj.

Rodina Windows 11 používá jako společný hlavní akcent přesnou modř `#3A83F7`
z ownerovy referenční ukázky. Tato barva je vyhrazena pro rámy, výběry a
primární akce; hover odstíny zůstávají podle kontrastu varianty. `auto` při
načtení dál respektuje systémovou volbu světlého a tmavého vzhledu.

Nové WDUi aplikace a durable šablony mají jako výchozí profil používat
`win11-modern-auto`; WDUi podle `AppsUseLightTheme` vybere bílou nebo černou
variantu. `win11-auto` zůstává kompatibilní alias a uložené preference
existujících aplikací se touto politikou automaticky nemění.

Build skripty trvalých aplikací kopírují `*.json` z této složky do složky
`dist\skins` každé aplikace a tyto soubory embedují do setupu. Setup je potom
rozbalí vedle nainstalovaného EXE do `skins\`.

WDUi samo tyto skiny nekompiluje do knihovny. Runtime discovery skinů čte každý
platný soubor `skins\*.json` vedle EXE přes `wdui::SkinCatalog::availableSkins()`.
Pokud je nainstalovaná složka `skins` prázdná, aplikace by měly dál fungovat s
běžným fallback stylingem WDUi.

`use_framework_defaults: true` použij pouze pro skin, který má začít přesným
frameworkovým `StyleCatalog::taskBoardFamily(theme)` a `WindowStyle::fromTheme(theme)`
základem bez generated skin treatmentu. Material a explicitní style overrides se
na tento základ mohou dál vrstvit. Výchozí `stellaris` tuto volbu používá bez
dalších vrstev, aby byl katalogový a no-skin fallback vzhled totožný.
`taskboard-default` používá stejnou cestu, ale záměrně nemá JSON blok `theme`:
zůstává proto živým katalogovým jménem statického Task Board základu místo jeho
duplicitní paletové kopie.

Výchozí skiny by měly obsahovat palette/material data, volby app-local fontů,
data `shapes` a cílené `styles`/`variants` overrides tam, kde sdílená rodina
controlů musí napříč skiny vizuálně držet pohromadě. Hodnoty shape jsou
`rectangle`, `rounded-rect`, `capsule`, `diamond`, `beveled`, `octagon`,
`hexagon`, `slant-right` a `slant-left`; akceptují se aliasy jako `rect`,
`round-rect`, `win11-rounded`, `pill`, `rhombus`, `cut-corner`, `chamfer` a
`parallelogram-right`. `variants` mohou dodat několik vizuálních rolí stejného
controlu, například toolbar buttons, primary actions, danger actions, compact
selects, bitmap icon buttons nebo app-specific ids; pro dědění z jiného style id
stejného typu controlu používej `base`/`based_on`/`extends`.

Kompaktní blok `materials` je výchozí způsob, jak skin definuje svůj vizuální
materiálový jazyk. Měl by pojmenovat materiály `surface`, `control` a `accent`
plus sdílené hodnoty tint/strength/gradient. Nové skiny mohou použít také
`preset`/`material_preset` pro předladěné kameny, drahokamy a kovy a `finish`
pro povrchovou úpravu (`polished`, `brushed`, `satin`, `matte`, `rough`,
`cracked`, `hammered`, `etched`, `frosted`, `wet_gloss`). Přímé `styles`
overrides používej jen tehdy, když se konkrétní rodina controlů potřebuje od
sdíleného materiálového jazyka odchýlit. Tmavé divadelní skiny mohou používat
`obsidian_glass` pro lahvově černé povrchy a `blood_gloss` pro malé mokře
červené akcenty, ale červená má zůstat na malých plochách, pokud koncept skinu
výslovně nepožaduje červený povrch.
Výchozí skiny mají nastavovat i material `depth`, `light_angle` a
`light_elevation`, aby povrchy nepůsobily jako plochá bitmapová tapeta. Pro
fotorealističtější skiny používej také `roughness`, `specular`,
`ambient_occlusion`, `edge_wear` a `texture_opacity`: společně řídí tvrdost
odlesku, kontaktní stín, hranové světlo a procedurální texturu bez změny
layoutu. WDUi z těchto hodnot kreslí i cached spatial shading pass, takže panely
mohou mít zřetelné horní světlo, spodní stín a barevné 3D hrany bez tvrdých
linek v JSONu. Čisté profesionální skiny drž nízko, crafted/gemstone/divadelní skiny
mohou použít silnější barevné světlo, ale pořád musí zůstat čitelné v
`Balanced` profilu.
`layered_glass`, `gemstone`, `obsidian_relief`, `stone_granite` a
`stone_marble` používej tam, kde má povrch působit jako hluboký 3D materiál
místo plochého přechodu. Široké pruhy na velkých panelech jsou skoro vždy
špatně; preferuj `uv_mapping: "global"`, větší `uv_scale`, jemnou texturu a
barevné edge/rim light. Shape-aware relief je řízený aktivním tvarem/alpha
maskou, takže cutouty, capsules a beveled panely mají působit jako nasvícený
objekt, ne jen jako obdélník s ořezem.
Amber/jantarové skiny mohou používat `amber_glass`: černé base fills,
medově-oranžové material tinty, tmavé spálené okraje a teplé bitmap tint palety
bez čistě bílé špičky, aby výsledek nepůsobil jako bílý odlesk na skle.
Soft/neon glass skiny mohou používat `luminous_glass`: skoro černé base fills,
barevný `backlight_color`, `inner_glow`, `rim_light`, velký `light_blob_scale`
a nízký grain. Tento materiál patří hlavně na panely, popupy, tooltipy,
title cards a vybrané dialogy; text musí zůstat čitelný i bez bloomu v rychlých
performance profilech.
`flame_response` je opt-in odezva povrchu na sdílené neviditelné `AnimatedFlameField`;
výchozí hodnota je `0`. Pokud je kladná, `flame_color` určuje tón jeho nepřímého
světla a `animation_speed` tempo pohybu. Field se sám nikdy nekreslí: plamen se
smí projevit pouze jako vnímatelný nepřímý pohyblivý odlesk, žár a relief materiálu,
nikdy jako malovaná ikona plamene nebo plošné přebarvení. Kladnou odezvu vždy nalaď
v `BestGraphics` preview na tmavých materiálových plochách; pokud člověk pohyb
nevidí, je hodnota příliš slabá. Pro pohyblivý efekt musí mít skin současně kladné
`flame_response` i `animation_speed`; bez rychlosti zůstane reflexe statická.
`flame_glint` řídí jas viditelného přeběhu speculárního záblesku přes vnitřní hranu
controls; vyšší hodnota přidává jas, nikoli rychlost. Záblesk se nikdy nevykresluje
jako samostatná pohybující se vlna: jeho poloha i ostré bílé jádro jsou odvozené z
globálního, procedurálně morfujícího pole plamene.
`flame_surface_blend` (`0..255`) je barevná stabilizace odrazu: `0` ponechá
autorskou `flame_color`, `255` ji celý přimíchá k `fill` přijímajícího controlu.
`flame_resolution` (doporučeně `16..512`, výchozí `128`) určuje délku delší
strany redukovaného bufferu AnimatedFlameField. Druhá strana se vždy dopočítá
z poměru konkrétního okna nebo controlu, takže ani široký panel nedostane
deformovaný čtvercový vzorek. Vyšší hodnoty zvyšují ostrost i CPU náklady;
pro běžné skiny nech `128`, pro výrazné skleněné/gemstone materiály lze použít
`160` nebo `192`.
Bundled skiny `Codex Forge`, `Command Alloy`, `Obsidian Atelier`, `Carmine Rose`,
`Ember Console`, `Ultraviolet Rift`, `Starlance` a `Starlance 3D` používají
`160`; ostatní skiny zůstávají na úsporném výchozím `128`.
Používej zhruba `180..220` na modro-černých skinech, kde jantarový zdroj nesmí
plošně přebarvit panel do žluta; Command Alloy má `208`. Tato volba tlumí jen
nepřímou reflexi a glint, nikoli samotné zdrojové pole v diagnostickém náhledu.
`flame_wind_strength` (`0..255`) řídí laterální průvan zdroje: `0` drží
top-down svíčku kolmo nad pevným knotem, vyšší číslo přidává plynulé náhodné
vychýlení na obě strany bez posuvu knotu nebo převrácení plamene do bočního
pohledu. Výchozí `96` je mírný průvan; Codex Forge používá jemnější `64`.
Používej jej jen s `uv_mapping: "global"` a pouze
u vybraných filmových materiálových skinů. Bundled opt-in tvoří Codex Forge, Command
Alloy, Ember Console, Ultraviolet Rift, Starlance a Starlance 3D; čisté Windows,
light, profesionální a nízkošumové skiny jej musí nechat vypnutý. `flame_glint`
(`0..255`) přidává úzký filmový specular záblesk, který při
průchodu ohněm přejede po skutečné hraně controlu; není to plošný highlight a bez
kladného `flame_response` se nekreslí. Skin-wide `materials.flame_response`,
`materials.flame_color`, `materials.flame_glint`, `materials.flame_wind_strength`, `materials.flame_surface_blend`, `materials.flame_resolution` a `materials.animation_speed` tvoří
výchozí baseline. Všech 106 materiálových bundled skinů má nyní
`animation_speed` explicitně nastavenou na pomalý baseline `6`, stejný jako v
aktuálním Task Boardu; frameworkové `stellaris` a `taskboard-default` dědí
stejnou hodnotu z C++ defaultu. Jednotlivé surface variants jej
mohou přesně přepsat skupinou `flame` ve `styles`; `enabled: false` vypne jen daný
surface a `color_role` naváže tón na aktuální skinovou paletu:

```json
"styles": {
  "window": {
    "default": {
      "surface": {
        "flame": {
          "response": 185,
          "color": "#F0A64B",
          "speed": 7,
          "glint": 190,
          "resolution": 160
        }
      }
    }
  },
  "button": {
    "quiet": {
      "surface": {
        "normal": {
          "flame": { "enabled": false }
        }
      }
    }
  }
}
```

`response`/`intensity`, `glint` a `surface_blend` jsou rozsah `0..255`; `resolution` je délka delší osy redukovaného bufferu v rozsahu `16..512`; `color` má přednost před
`color_role` a `speed` přepisuje zděděné `animation_speed`. Ploché klíče
`flame_response`, `flame_color`, `flame_glint`, `flame_wind_strength`, `flame_surface_blend`, `flame_resolution` a `animation_speed` zůstávají podporované pro
kompatibilitu, ale pro novou style-specific konfiguraci používej skupinu `flame`.
Pokud má velké tmavé pozadí nést jemnou technickou kresbu, použij
`luminous_glass` s `finish: "etched"` hlavně na window/shell surface a drž
controls čistší, aby grid zůstal pozadí místo opakované tapety.

Fonty výchozích skinů musí pocházet z `tools\win32-design-ui\default-fonts\`,
pokud product-specific skin výslovně nepřibaluje vlastní app-local složku fontů.
Platform-bound Windows 11 moderní rodina je výjimka: může použít systémové
`Segoe UI Variable` a `Cascadia Mono`, ale vždy s bezpečným fallbackem na
app-local font catalog. Nesměruj sdílené skiny na jiné fonty, které nejsou
přibalené nebo garantované Windows.

Každý připravený skin by měl mít dostupné `styles.bitmap_button.default`,
`styles.bitmap_button.action` a `styles.bitmap_button.muted`. Tyto varianty
tintují monochromatické bitmap controls z rolí skinu (`text`, `accent`,
`accent_hot`, `muted_text`, `disabled_text`) a přitom zachovávají bitmap alpha
jako skutečnou průhlednost a hit mask. Výchozí varianty bitmap buttonů by měly
používat `palette_map` s plnou 64barvovou `palette`, aby se bitmap art mohl
přebarvit až na 32 současných zdrojových barev; bitmapy s méně barvami použijí
jen potřebnou část mapování. Nekopíruj jeden identický tint blok do každého
skinu: každý připravený skin by měl zvolit bitmap tint profil, který sedí jeho
materiálovému jazyku, včetně `mode`, `palette`, `secondary_role`,
`preserve_luminance`, `amount`, `coverage_threshold` a state-specific
normal/hot/pressed/active/disabled rolí tam, kde jsou užitečné.

Sdílená výchozí kompatibilní rodina Windows 11 je `win11-auto`, `win11-dark` a
`win11-light`. Aplikace mohou ukládat `win11-auto`; WDUi ho při renderování
vyřeší na světlý nebo tmavý preset podle Windows app light/dark setting.
Pro nové produktové UI je k dispozici moderní Fluent 2/Mica-inspirovaná rodina
`win11-modern-auto`, `win11-modern-black` a `win11-modern-white`. Moderní auto
se stejným systémovým signálem resolveuje na explicitní Modern White nebo
Modern Black; explicitní varianty jsou deterministické a hodí se pro snapshoty,
testy a uživatelské profily. Všechny tři používají `surface_mode:
"windows-11-modern"`: tónové Mica vrstvy pro shell, příkazové plochy a obsah,
Segoe UI Variable/Cascadia Mono, čisté zaoblené shape-safe controls a mělkou
elevation. Flame, animace, plošný grain a výrazná reflection jsou v tomto
profesionálním režimu záměrně vypnuté; hloubku tvoří kontrast vrstev a jemný
kontaktní stín. Opora: [Fluent 2 material](https://fluent2.microsoft.design/material),
[Mica](https://learn.microsoft.com/en-us/windows/apps/design/style/mica),
[typografie](https://learn.microsoft.com/en-us/windows/apps/design/signature-experiences/typography),
[elevation](https://fluent2.microsoft.design/elevation) a
[color/focus](https://fluent2.microsoft.design/color).

Výchozí skiny nemají působit jako stejné UI přebarvené padesátkrát. Každý
připravený skin má zvolit tvary controlů a proporce scrollbarů podle svého
významu: klidné obdélníkové formuláře pro čisté profesionální skiny, beveled
tvary pro crafted/workbench skiny, hex/octagonal tvary pro game-like nebo signal
skiny a slanted tvary tam, kde má skin záměrně energický pocit. Platí to i pro
`ScrollBar` controls a `SelectBox` dropdown scrollbars; uvnitř jednoho skinu by
měly sdílet stejné metriky, ale ne nutně napříč všemi skiny.

Barvy scrollbar track, thumb, hot, pressed, shadow, glow a outline mají pořád
pocházet z aktivního skin theme, pokud skin nepotřebuje konkrétní override.
Arctic Instrument má zůstat ledový, Obsidian Atelier teplý/tmavý, Codex Forge
teal/gold a app-local skiny si mohou držet vlastní materiálový jazyk.

Toto jsou katalogová data, ne trvalé pravidlo WDUi. Jediné tvrdé pravidlo pro
shape je, že capsule má být skutečná capsule: průměr koncové čepičky se rovná
kratší straně kresleného rectu a zbytek délky tvoří tělo.

Když výchozí skin používá angled, cut, hexagonal, capsule nebo diamond povrchy,
jeho metriky musí nechat dost prostoru pro WDUi shape-safe obsah a layout area.
Text, table cells, combo items, input text, status chips, action labels a child
controls mají zůstat uvnitř použitelného tvaru po aplikování surface safe insetu
a vlastního paddingu controlu. Agresivní tvary jsou v pořádku pro vizuální
identitu, ale kompaktní controls pořád potřebují čitelné přirozené minimální
rozměry. Výchozí `FollowParentEdge + Band` zároveň zmenšuje společné řádky jako
jednu jednotku: zachová horizontální poměry, aspect ratio a zobrazení textu a
na šikmé hraně vykreslí schody z jednotlivých contour scanline segmentů. Jeden
šikmý okraj vytvoří schody na jedné straně, oboustranně šikmý tvar na obou.
