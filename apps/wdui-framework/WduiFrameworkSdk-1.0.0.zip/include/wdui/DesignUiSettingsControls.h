#pragma once

// EN: This header provides the two shared settings controls used by WDUi
//     applications. The control structure and item catalog are static from
//     the caller's point of view; the selected value remains runtime state.
// CZ: Tento header poskytuje dva sdílené nastavovací prvky pro aplikace WDUi.
//     Struktura ovladače a katalog položek jsou z pohledu volajícího statické;
//     vybraná hodnota zůstává runtime stavem.

#include <algorithm>
#include <string>
#include <utility>
#include <vector>

#include "wdui/DesignUi.h"
#include "wdui/WindowsLanguages.h"

namespace wdui {

class LanguageSelector final : public SelectBox {
public:
    // EN: Keep the automatic Windows choice as the one portable default so a
    //     newly created settings panel behaves consistently across apps.
    // CZ: Automatickou volbu Windows držíme jako přenositelný výchozí stav,
    //     aby se nově vytvořený panel choval ve všech aplikacích stejně.
    inline static constexpr const wchar_t* kDefaultLanguage = L"auto";

    LanguageSelector(
        std::wstring id,
        Rect bounds,
        Theme theme = Theme::taskBoardFamily())
        : SelectBox(std::move(id), bounds, theme)
    {
        setAccessibilityName(L"Language");
        setLanguageItems();
        setSelectedLanguage(kDefaultLanguage);
    }

    LanguageSelector(
        std::wstring id,
        Rect bounds,
        const StyleCatalog& catalog)
        : SelectBox(std::move(id), bounds, catalog)
    {
        setAccessibilityName(L"Language");
        setLanguageItems();
        setSelectedLanguage(kDefaultLanguage);
    }

    // EN: Rebuild the fixed Windows language catalog while preserving the
    //     current runtime value when a host refreshes the control.
    // CZ: Obnov pevný katalog jazyků Windows a při refreshi hostitele zachovej
    //     aktuální runtime hodnotu.
    void setLanguageItems(const std::wstring& languageCodeLabel = L"Language code")
    {
        const std::wstring current = selectedLanguage();
        std::vector<SelectBoxItem> items;
        std::vector<std::wstring> values;
        items.reserve(kWindowsDisplayLanguages.size() + 1);
        values.reserve(kWindowsDisplayLanguages.size() + 1);

        items.push_back(SelectBoxItem{
            L"Automatic (Windows)",
            L"Use the Windows display language.\nLanguage code: auto"});
        values.emplace_back(kDefaultLanguage);

        for (const WindowsLanguageInfo& language : kWindowsDisplayLanguages) {
            const std::wstring label = compactWindowsLanguageName(language);
            items.push_back(SelectBoxItem{
                label,
                windowsLanguageTooltip(language, languageCodeLabel)});
            values.emplace_back(language.code != nullptr ? language.code : L"");
        }

        languageValues_ = std::move(values);
        setItems(std::move(items));
        setSelectedLanguage(current);
    }

    // EN: Accept host-localized labels while retaining the shared positional
    //     language-id map used by the typed read-back API.
    // CZ: Přijmi lokalizované popisky hostitele a přitom zachovej společnou
    //     poziční mapu ID jazyků používanou typovým read-back API.
    void setLanguageItems(std::vector<std::wstring> items)
    {
        const std::wstring current = selectedLanguage();
        std::vector<std::wstring> values;
        values.reserve(items.size());
        for (std::size_t index = 0; index < items.size(); ++index) {
            values.push_back(index == 0
                ? std::wstring(kDefaultLanguage)
                : (index - 1 < kWindowsDisplayLanguages.size()
                    ? std::wstring(kWindowsDisplayLanguages[index - 1].code)
                    : std::wstring{}));
        }
        if (values.size() != items.size() ||
            std::any_of(values.begin(), values.end(), [](const std::wstring& value) { return value.empty(); })) {
            setLanguageItems();
            return;
        }
        languageValues_ = std::move(values);
        setItems(std::move(items));
        setSelectedLanguage(current);
    }

    // EN: The item-record overload preserves host tooltip text and uses the
    //     same deterministic value ordering as the label-only overload.
    // CZ: Recordový overload zachová tooltipy hostitele a používá stejné
    //     deterministické pořadí hodnot jako overload pouze s popisky.
    void setLanguageItems(std::vector<SelectBoxItem> items)
    {
        const std::wstring current = selectedLanguage();
        std::vector<std::wstring> values;
        values.reserve(items.size());
        for (std::size_t index = 0; index < items.size(); ++index) {
            values.push_back(index == 0
                ? std::wstring(kDefaultLanguage)
                : (index - 1 < kWindowsDisplayLanguages.size()
                    ? std::wstring(kWindowsDisplayLanguages[index - 1].code)
                    : std::wstring{}));
        }
        if (values.size() != items.size() ||
            std::any_of(values.begin(), values.end(), [](const std::wstring& value) { return value.empty(); })) {
            setLanguageItems();
            return;
        }
        languageValues_ = std::move(values);
        setItems(std::move(items));
        setSelectedLanguage(current);
    }

    // EN: Return the stable language identifier rather than the display text,
    //     so persistence and localization do not depend on visible labels.
    // CZ: Vrať stabilní identifikátor jazyka místo zobrazovaného textu, aby
    //     ukládání a lokalizace nezávisely na viditelném popisku.
    std::wstring selectedLanguage() const
    {
        const int index = selectedIndex();
        if (index >= 0 && static_cast<std::size_t>(index) < languageValues_.size() &&
            !languageValues_[static_cast<std::size_t>(index)].empty()) {
            return languageValues_[static_cast<std::size_t>(index)];
        }
        return kDefaultLanguage;
    }

    // EN: Unknown or malformed values fail closed to the automatic Windows
    //     entry; a primary-language match still accepts locale-only settings.
    // CZ: Neznámé nebo chybné hodnoty skončí bezpečně na automatické volbě
    //     Windows; shoda primárního jazyka přijme i locale bez regionu.
    void setSelectedLanguage(const std::wstring& languageTag)
    {
        const std::wstring wanted = LocalizationCatalog::normalizeLanguageTag(languageTag);
        const std::wstring wantedPrimary = LocalizationCatalog::primaryLanguageTag(wanted);
        int fallbackIndex = 0;
        int primaryIndex = -1;

        for (std::size_t index = 0; index < languageValues_.size(); ++index) {
            const std::wstring candidate =
                LocalizationCatalog::normalizeLanguageTag(languageValues_[index]);
            if (candidate == wanted) {
                setSelectedIndex(static_cast<int>(index));
                return;
            }
            if (primaryIndex < 0 && !wantedPrimary.empty() &&
                LocalizationCatalog::primaryLanguageTag(candidate) == wantedPrimary) {
                primaryIndex = static_cast<int>(index);
            }
        }

        setSelectedIndex(primaryIndex >= 0 ? primaryIndex : fallbackIndex);
    }

private:
    // EN: SelectBox exposes display items but intentionally has no value field;
    //     this parallel vector keeps the typed language contract local to the
    //     specialized control without changing the generic WDUi ABI.
    // CZ: SelectBox vystavuje zobrazované položky, ale záměrně nemá value pole;
    //     paralelní vektor drží typový kontrakt jazyka v specializaci bez změny
    //     obecného ABI WDUi.
    std::vector<std::wstring> languageValues_;
};

class SkinSelector final : public SelectBox {
public:
    // EN: New WDUi settings use the modern Windows 11 auto preset. The older
    //     win11-auto identifier remains a catalog compatibility alias.
    // CZ: Nové WDUi nastavení používá moderní auto preset Windows 11. Starší
    //     identifikátor win11-auto zůstává kompatibilním aliasem katalogu.
    inline static constexpr const wchar_t* kDefaultSkinId = L"win11-modern-auto";

    SkinSelector(
        std::wstring id,
        Rect bounds,
        Theme theme = Theme::taskBoardFamily())
        : SelectBox(std::move(id), bounds, theme)
    {
        setAccessibilityName(L"Skin");
        setItemPreviewHeight(52);
        setMaxVisibleItems(5);
        setDropdownWidth(270);
        setSkinItems();
        setSelectedSkinId(kDefaultSkinId);
    }

    SkinSelector(
        std::wstring id,
        Rect bounds,
        const StyleCatalog& catalog)
        : SelectBox(std::move(id), bounds, catalog)
    {
        setAccessibilityName(L"Skin");
        setItemPreviewHeight(52);
        setMaxVisibleItems(5);
        setDropdownWidth(270);
        setSkinItems();
        setSelectedSkinId(kDefaultSkinId);
    }

    // EN: Re-read the active catalog at runtime so external skin packs remain
    //     dynamic while the control type and default policy stay shared.
    // CZ: Načti aktivní katalog za běhu, aby externí balíčky skinů zůstaly
    //     dynamické, zatímco typ ovladače a defaultní politika jsou sdílené.
    void setSkinItems()
    {
        setSkinItems(SkinCatalog::availableSkins());
    }

    // EN: Hosts may provide a merged runtime catalog (for example embedded
    // setup skins plus the external pack) without losing typed ID mapping.
    // CZ: Hostitel může dodat sloučený runtime katalog (například embedded
    // setup skiny spolu s externím balíkem) bez ztráty typového mapování ID.
    void setSkinItems(const std::vector<SkinPreset>& skins)
    {
        const std::wstring current = selectedSkinId();
        std::vector<SelectBoxItem> items;
        std::vector<std::wstring> values;
        items.reserve(skins.empty() ? 1 : skins.size());
        values.reserve(skins.empty() ? 1 : skins.size());

        for (const SkinPreset& skin : skins) {
            const std::wstring id = skin.id.empty() ? kDefaultSkinId : skin.id;
            const std::wstring label = skin.name.empty() ? id : skin.name;
            std::wstring tooltip = skin.description;
            if (!skin.category.empty()) {
                if (!tooltip.empty()) {
                    tooltip += L"\n";
                }
                tooltip += L"Category: ";
                tooltip += skin.category;
            }
            if (!skin.harmony.empty()) {
                if (!tooltip.empty()) {
                    tooltip += L"\n";
                }
                tooltip += L"Harmony: ";
                tooltip += skin.harmony;
            }
            if (!tooltip.empty()) {
                tooltip += L"\n";
            }
            tooltip += L"Skin ID: ";
            tooltip += id;
            items.push_back(SelectBoxItem{label, tooltip, 0, makeSkinPreview(skin)});
            values.push_back(id);
        }

        if (items.empty()) {
            // EN: Keep the selector usable even if a host temporarily exposes
            //     an empty external catalog; the value remains explicit.
            // CZ: Selektor zůstane použitelný i při dočasně prázdném externím
            //     katalogu hostitele; hodnota zůstane explicitní.
            SkinPreset fallbackSkin{};
            fallbackSkin.id = kDefaultSkinId;
            fallbackSkin.name = L"Modern Windows 11 (automatic)";
            fallbackSkin.theme = Theme::taskBoardFamily();
            items.push_back(SelectBoxItem{
                L"Modern Windows 11 (automatic)",
                L"Built-in WDUi default.\nSkin ID: win11-modern-auto",
                0,
                makeSkinPreview(fallbackSkin)});
            values.emplace_back(kDefaultSkinId);
        }

        skinValues_ = std::move(values);
        setItems(std::move(items));
        setSelectedSkinId(current);
    }

    // EN: Return the catalog identifier, including an external skin's exact
    //     id, instead of exposing a localized display name.
    // CZ: Vrať identifikátor z katalogu, včetně přesného ID externího skinu,
    //     místo lokalizovaného zobrazovaného názvu.
    std::wstring selectedSkinId() const
    {
        const int index = selectedIndex();
        if (index >= 0 && static_cast<std::size_t>(index) < skinValues_.size() &&
            !skinValues_[static_cast<std::size_t>(index)].empty()) {
            return skinValues_[static_cast<std::size_t>(index)];
        }
        return kDefaultSkinId;
    }

    // EN: Prefer an exact persisted id, then resolve legacy aliases, and fall
    //     back to the canonical default or the first available catalog item.
    // CZ: Preferuj přesné uložené ID, potom vyřeš staré aliasy a nakonec použij
    //     kanonický default nebo první dostupnou položku katalogu.
    void setSelectedSkinId(const std::wstring& skinId)
    {
        const std::wstring resolvedWanted = SkinCatalog::resolveSkinId(skinId);
        int fallbackIndex = -1;
        int resolvedIndex = -1;
        for (std::size_t index = 0; index < skinValues_.size(); ++index) {
            const std::wstring& candidate = skinValues_[index];
            if (candidate == skinId) {
                setSelectedIndex(static_cast<int>(index));
                return;
            }
            if (resolvedIndex < 0 && SkinCatalog::resolveSkinId(candidate) == resolvedWanted) {
                resolvedIndex = static_cast<int>(index);
            }
            if (fallbackIndex < 0 && candidate == kDefaultSkinId) {
                fallbackIndex = static_cast<int>(index);
            }
        }

        if (resolvedIndex >= 0) {
            setSelectedIndex(resolvedIndex);
        } else if (fallbackIndex >= 0) {
            setSelectedIndex(fallbackIndex);
        } else {
            setSelectedIndex(skinValues_.empty() ? -1 : 0);
        }
    }

    // EN: Every visible skin entry has a deterministic thumbnail, so a large
    //     catalog remains scannable without changing the persisted skin ID.
    // CZ: Každá viditelná položka skinu má deterministický náhled, takže velký
    //     katalog zůstává přehledný bez změny ukládaného ID skinu.
    std::size_t skinPreviewCountForDiagnostics() const
    {
        return itemPreviewCountForDiagnostics();
    }

private:
    static Image makeSkinPreview(const SkinPreset& skin)
    {
        const Theme theme = skin.theme;
        const auto mix = [](COLORREF first, COLORREF second, int percent) {
            const int amount = std::clamp(percent, 0, 100);
            const auto channel = [amount](int a, int b) {
                return (a * (100 - amount) + b * amount + 50) / 100;
            };
            return RGB(
                channel(GetRValue(first), GetRValue(second)),
                channel(GetGValue(first), GetGValue(second)),
                channel(GetBValue(first), GetBValue(second)));
        };

        return Image::makeProcedural(96, 52, [theme, mix](Image::ProceduralCanvas& canvas) {
            canvas.fillRect(Rect{0, 0, 96, 52}, theme.shell);
            canvas.fillRect(Rect{2, 3, 92, 46}, mix(theme.shell, theme.frame, 28));
            canvas.fillRect(Rect{4, 5, 88, 42}, theme.panel);
            canvas.fillRect(Rect{5, 6, 86, 13}, theme.header);
            canvas.fillRect(Rect{7, 21, 82, 22}, theme.control);
            canvas.fillRect(Rect{8, 22, 58, 5}, mix(theme.control, theme.accent, 24));
            canvas.fillRect(Rect{8, 30, 38, 6}, mix(theme.control, theme.header, 38));
            canvas.fillRect(Rect{50, 30, 37, 6}, mix(theme.control, theme.header, 55));
            canvas.fillRect(Rect{68, 22, 19, 5}, theme.accent);
            canvas.fillRect(Rect{69, 23, 17, 2}, theme.accentHot, 210);
            canvas.drawLine(Point{5, 19}, Point{90, 19}, theme.border, 1, 230);
            canvas.drawLine(Point{5, 47}, Point{90, 47}, theme.frame, 1, 210);
            canvas.drawLine(Point{4, 5}, Point{91, 5}, theme.textHot, 1, 110);
            canvas.drawLine(Point{7, 21}, Point{87, 21}, theme.border, 1, 220);
            canvas.fillEllipse(Rect{8, 8, 5, 5}, theme.accentHot, 230);
            canvas.fillEllipse(Rect{15, 8, 5, 5}, theme.accent, 190);
        });
    }

    // EN: The mapping mirrors SelectBox item order and makes runtime selection
    //     independent from translated labels or changing catalog names.
    // CZ: Mapování kopíruje pořadí položek SelectBoxu a odděluje runtime volbu
    //     od přeložených popisků i měnících se názvů katalogu.
    std::vector<std::wstring> skinValues_;
};

} // namespace wdui
