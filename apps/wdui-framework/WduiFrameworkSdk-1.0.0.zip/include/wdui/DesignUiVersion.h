#pragma once

#include <cstdint>

#define WDUI_HEADER_API_VERSION 2026101401u
#define WDUI_HEADER_BUILD_ID L"wdui-header-20261014-skin-picker"
#define WDUI_SKIN_SCHEMA_VERSION 2026090301u
