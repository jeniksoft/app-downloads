#pragma once

#include <wdui/DesignUi.h>

#include <string>

namespace wdui {

// EN: BrowserControl exposes only the host lifecycle surface. It is not a
//     WebView2 controller and never owns a URL, page content, process handle,
//     network client or action callback.
// CZ: BrowserControl zveřejňuje pouze hostitelský životní cyklus. Není to
//     WebView2 controller a nikdy nevlastní URL, obsah stránky, handle procesu,
//     síťového klienta ani callback akce.
enum class BrowserControlHostState {
    Unavailable,
    Ready,
    Failed,
    Closed,
};

// EN: The snapshot is deliberately digest-only so WDUi can render state
//     without becoming a browser, navigation or credential authority.
// CZ: Snapshot je záměrně pouze digestový, aby WDUi mohlo vykreslit stav,
//     ale nestalo se autoritou browseru, navigace ani credentialů.
struct BrowserControlSnapshot final {
    BrowserControlHostState state = BrowserControlHostState::Unavailable;
    std::wstring sessionDigest;
    std::wstring engineVersionDigest;
    std::wstring skinDigest;
    int tabCount = 0;
    int activeTabIndex = -1;
    int viewportWidth = 0;
    int viewportHeight = 0;
    int dpi = 96;
    bool focused = false;
    bool hostVisible = false;
    bool closeRequested = false;
};

struct BrowserControlStyle final {
    SurfaceStyle surface;
    SurfaceStyle chrome;
    SurfaceStyle readyBadge;
    SurfaceStyle warningBadge;
    TextStyle text;
    TextStyle mutedText;
    int chromeHeight = 26;
    int padding = 10;
    int badgeWidth = 86;

    static BrowserControlStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

// EN: Provider-free WDUi browser host surface. A future WebView2 adapter may
//     feed a validated snapshot, but this control itself never creates or
//     controls an engine.
// CZ: Provider-free WDUi plocha browserového hostitele. Budoucí WebView2
//     adapter může předat ověřený snapshot, ale tento control sám engine
//     nikdy nevytváří ani neovládá.
class BrowserControl final : public Control {
public:
    BrowserControl(
        std::wstring id,
        Rect bounds,
        Theme theme = Theme::taskBoardFamily());

    void setStyle(BrowserControlStyle style);
    const BrowserControlStyle& style() const noexcept;
    const BrowserControlSnapshot& snapshot() const noexcept;

    // EN: Replace the complete host observation atomically after bounded
    //     validation. Invalid observations are rejected without mutation.
    // CZ: Nahraď celý host observation atomicky po omezeném ověření. Neplatné
    //     observations se odmítnou bez změny aktuálního stavu.
    bool applyHostSnapshot(BrowserControlSnapshot snapshot);
    void resetHostSnapshot();

    void paint(HDC hdc, Point origin) override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void onOwningWindowGeometryChanged() override;

private:
    static bool validSnapshot(const BrowserControlSnapshot& snapshot);
    static const wchar_t* stateLabel(BrowserControlHostState state) noexcept;
    std::wstring statusLine() const;
    std::wstring detailLine() const;

    BrowserControlStyle style_;
    BrowserControlSnapshot snapshot_;
};

} // namespace wdui
