#pragma once

#include <cstdint>

#define WDUI_HEADER_API_VERSION 2026091401u
#define WDUI_HEADER_BUILD_ID L"wdui-header-20260914-popup-resources"
#define WDUI_SKIN_SCHEMA_VERSION 2026090301u
