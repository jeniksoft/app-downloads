# Getting Started

Tento SDK balĂ­k je urÄŤenĂ˝ pro MSVC x64 na Windows.

## Build ukĂˇzky

    cd <rozbaleny-sdk>
    powershell -NoProfile -ExecutionPolicy Bypass -File examples\build_example.ps1
    build\minimal_app.exe

## Struktura appky

Vedle finĂˇlnĂ­ho EXE ponech:

    my_app.exe
    skins\*.json
    fonts\...

Bez skinĹŻ a fontĹŻ aplikace poĹ™Ăˇd spadne na fallback vzhled, ale pĹ™ipravenĂ© WDUi skiny a app-local fonty jsou doporuÄŤenĂˇ runtime cesta.

## Renderer

VĂ˝chozĂ­ renderer je wdui::RenderBackend::Auto, takĹľe WDUi preferuje Direct2D/GPU cestu a umĂ­ spadnout na GDI fallback.

    wdui::setDefaultRenderBackend(wdui::RenderBackend::Auto);
    wdui::setDefaultPerformanceProfile(wdui::PerformanceProfile::Balanced);

Pro compatibility nebo low-power reĹľim mĹŻĹľe aplikace pĹ™ed vytvoĹ™enĂ­m oken nastavit RenderBackend::Gdi.

## Identita buildu

    const wdui::BuildInfo info = wdui::buildInfo();
    if (!info.includedHeaderMatchesLibrary) {
        // Header a linknuta knihovna nepatri ke stejnemu WDUi buildu.
    }

Do owner-facing About dialogu nebo servisnĂ­ho logu zapisuj info.summary nebo wdui::currentBuildInfoText(). Obsahuje lib build id, source id, konfiguraci, header id, default skin pack id a runtime skin pack id.