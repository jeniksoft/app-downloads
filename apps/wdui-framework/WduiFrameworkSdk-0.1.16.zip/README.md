# WDUi Framework SDK 0.1.16

WDUi je proprietĂˇrnĂ­ C++/Win32 UI framework od Jeniksoft pro skinovatelnĂ© nativnĂ­ Windows aplikace.

Tento veĹ™ejnĂ˝ SDK balĂ­k obsahuje hotovou x64 statickou knihovnu, veĹ™ejnĂ© hlaviÄŤky, vĂ˝chozĂ­ skiny, app-local fonty, binĂˇrnĂ­ demo a ukĂˇzkovĂ˝ zdrojovĂ˝ kĂłd aplikace. Neobsahuje zdrojovĂ© .cpp soubory knihovny.

## Obsah balĂ­ku

    include/wdui/           veĹ™ejnĂ© hlaviÄŤky
    lib/x64/wdui.lib        statickĂˇ knihovna pro MSVC x64
    bin/wdui_demo.exe       binĂˇrnĂ­ demo a smoke nĂˇstroj
    bin/skins/, bin/fonts/  runtime assety pĹ™Ă­mo vedle demo EXE
    assets/skins/           vĂ˝chozĂ­ JSON skiny
    assets/fonts/           app-local fonty a OFL licence
    examples/               otevĹ™enĂ© ukĂˇzky pouĹľitĂ­ SDK
    docs/                   struÄŤnĂ˝ nĂˇvod a poznĂˇmky k licenci

## RychlĂ˝ start

1. Rozbal ZIP mimo systĂ©movĂ© sloĹľky, napĹ™Ă­klad do C:\SDK\WDUi.
2. OtevĹ™i "x64 Native Tools Command Prompt for VS" nebo PowerShell s dostupnĂ˝m cl.exe.
3. SpusĹĄ:

    powershell -NoProfile -ExecutionPolicy Bypass -File examples\build_example.ps1

VĂ˝sledkem bude build\minimal_app.exe. Skript vedle EXE zkopĂ­ruje skins\ a fonts\, aby runtime naĹˇel vĂ˝chozĂ­ WDUi assety.

## LinkovĂˇnĂ­

MinimĂˇlnĂ­ MSVC link pouĹľĂ­vĂˇ:

    /I include examples\minimal_app.cpp lib\x64\wdui.lib /link /LTCG
    User32.lib Gdi32.lib D2d1.lib Dwrite.lib D3d11.lib Msimg32.lib Ole32.lib Advapi32.lib Windowscodecs.lib

Kompiluj jako C++20 a UTF-8:

    /std:c++20 /utf-8 /EHsc /DUNICODE /D_UNICODE

## Runtime assets

WDUi hledĂˇ skiny v skins\*.json vedle EXE a fonty v fonts\ vedle EXE. Fonty se naÄŤĂ­tajĂ­ jako private process fonts, takĹľe se neinstalujĂ­ globĂˇlnÄ› do Windows.

## Build identity

Pro About dialog, bug report nebo diagnostiku pouĹľij:

    const wdui::BuildInfo info = wdui::buildInfo();
    std::wstring diagnostic = info.summary;

info.libraryBuildId identifikuje linknutou wdui.lib, info.includedHeaderMatchesLibrary hlĂ­dĂˇ, Ĺľe appka pouĹľĂ­vĂˇ odpovĂ­dajĂ­cĂ­ public header, a info.runtimeSkinPackId fingerprintuje skuteÄŤnĂ© skins\*.json vedle EXE. RychlĂ˝ gate je bin\wdui_demo.exe --build-info-smoke.

VolĂˇnĂ­ ÄŤte runtime skin JSONy kvĹŻli fingerprintu, takĹľe ho pouĹľĂ­vej pĹ™i startupu, v About dialogu nebo pĹ™i tvorbÄ› diagnostickĂ©ho reportu, ne v paint/input hot path.

## Licence

WDUi knihovna a veĹ™ejnĂ© hlaviÄŤky nejsou open source. Podrobnosti jsou v LICENSE-NOTICE.md.

UkĂˇzkovĂ© zdroje v examples\ jsou volnÄ› pouĹľitelnĂ© pod MIT-0 licencĂ­; viz examples\LICENSE-MIT-0.txt. PĹ™ibalenĂ© fonty jsou pod SIL Open Font License 1.1; ponech u nich pĹ™Ă­sluĹˇnĂ© OFL.txt.