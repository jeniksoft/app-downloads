# Skiny a fonty

VĂ˝chozĂ­ skiny jsou JSON soubory v assets\skins. PĹ™i instalaci aplikace je kopĂ­ruj vedle EXE do sloĹľky skins.

Fonty jsou v assets\fonts. Jsou app-local a WDUi je naÄŤĂ­tĂˇ jen pro aktuĂˇlnĂ­ proces. Neinstaluj je do %WINDIR%\Fonts.

ZĂˇkladnĂ­ runtime layout:

    my_app.exe
    skins\00-wdui-default-skins.json
    skins\01-wdui-black-gemstone-skins.json
    fonts\inter\Inter[opsz,wght].ttf
    fonts\...\OFL.txt

VlastnĂ­ skin pĹ™idej jako dalĹˇĂ­ skins\*.json. Pokud pouĹľije stejnĂ© id jako existujĂ­cĂ­ skin a naÄŤte se pozdÄ›ji, nahradĂ­ pĹ™edchozĂ­ preset.