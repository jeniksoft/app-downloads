#pragma once

// EN: Shared, debug/QA-only control-plane contracts for WDUi applications.
//     WDUi owns the typed request/receipt boundary and bounded serialization;
//     the host bridge and the application adapter remain separate authorities.
// CZ: Sdílené kontrakty control-plane pouze pro debug/QA buildy aplikací WDUi.
//     WDUi vlastní typovanou hranici požadavků/receiptů a omezenou serializaci;
//     host bridge a aplikační adaptér zůstávají oddělenými autoritami.

#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace wdui {

enum class DebugApiTargetKind : std::uint8_t {
    Application = 0,
    Setup = 1,
};

enum class DebugApiDialogAction : std::uint8_t {
    Inventory = 0,
    Invoke = 1,
    SetValue = 2,
    Toggle = 3,
    OpenTrayPopup = 4,
};

enum class DebugApiProcessAction : std::uint8_t {
    Inspect = 0,
    Shutdown = 1,
    Restart = 2,
    Kill = 3,
};

struct DebugApiDialogRequest {
    DebugApiTargetKind target = DebugApiTargetKind::Application;
    std::uint32_t targetProcessId = 0;
    std::uint64_t targetWindowHandle = 0;
    DebugApiDialogAction action = DebugApiDialogAction::Inventory;
    std::wstring automationId;
    std::wstring value;
    std::wstring artifactDirectory;
    bool mutationRequested = false;
};

struct DebugApiDialogWindowReceipt {
    std::uint64_t windowHandle = 0;
    std::string windowClass;
    bool visible = false;
    bool minimized = false;
    bool inspected = false;
    std::wstring snapshotPath;
    std::uint32_t controlCount = 0;
    bool controlsTruncated = false;
    bool sensitiveControlsRedacted = false;
};

struct DebugApiDialogReceipt {
    DebugApiTargetKind target = DebugApiTargetKind::Application;
    // EN: Applications may preserve a legacy wire label while sharing the
    //     generic target enum, e.g. Jarvis keeps "jarvis" for old scripts.
    // CZ: Aplikace mohou při sdíleném enumu zachovat starý wire label, např.
    //     Jarvis ponechá "jarvis" kvůli starým skriptům.
    std::string targetKindLabel;
    std::uint32_t targetProcessId = 0;
    std::uint32_t targetSessionId = 0;
    std::string targetImageSha256;
    std::uint64_t targetProcessStartTime100ns = 0;
    std::uint64_t targetWindowHandle = 0;
    std::string action;
    std::string failureStage;
    std::uint32_t failureStatus = 0;
    bool targetIdentityVerified = false;
    bool mutationRequestReceived = false;
    bool actionIssued = false;
    bool valueAppliedVerified = false;
    bool toggleAppliedVerified = false;
    bool targetWindowClosed = false;
    bool semanticOutcomeVerified = false;
    std::uint32_t matchedControlCount = 0;
    std::wstring preActionSnapshotPath;
    std::wstring postActionSnapshotPath;
    std::vector<DebugApiDialogWindowReceipt> windows;
};

struct DebugApiProcessControlRequest {
    DebugApiTargetKind target = DebugApiTargetKind::Application;
    std::uint32_t targetProcessId = 0;
    std::uint64_t targetWindowHandle = 0;
    std::uint64_t expectedProcessStartTime100ns = 0;
    std::string expectedImageSha256;
    DebugApiProcessAction action = DebugApiProcessAction::Inspect;
    std::uint32_t timeoutMs = 0;
    bool mutationRequested = false;
};

struct DebugApiProcessWindowReceipt {
    std::uint64_t windowHandle = 0;
    std::string windowClass;
    bool visible = false;
    bool minimized = false;
};

struct DebugApiProcessControlReceipt {
    DebugApiTargetKind target = DebugApiTargetKind::Application;
    std::string targetKindLabel;
    std::uint32_t targetProcessId = 0;
    std::uint32_t targetSessionId = 0;
    std::uint64_t targetWindowHandle = 0;
    std::uint64_t targetProcessStartTime100ns = 0;
    std::string targetImageSha256;
    std::string action;
    bool targetIdentityVerified = false;
    bool actionIssued = false;
    bool processExited = false;
    bool forcedTermination = false;
    bool alreadyRunning = false;
    std::uint32_t replacementProcessId = 0;
    std::uint64_t replacementProcessStartTime100ns = 0;
    std::string replacementImageSha256;
    std::string diagnostic;
    std::vector<DebugApiProcessWindowReceipt> windows;
};

[[nodiscard]] const char* debugApiTargetKindName(DebugApiTargetKind kind) noexcept;
[[nodiscard]] const char* debugApiDialogActionName(DebugApiDialogAction action) noexcept;
[[nodiscard]] const char* debugApiProcessActionName(DebugApiProcessAction action) noexcept;

// EN: These validators are transport-level gates. The target-specific Tyr
//     adapter remains authoritative for process identity and UIA semantics.
// CZ: Tyto validátory jsou transportní brány. Tyr adaptér zůstává autoritou
//     pro identitu procesu a význam UIA akcí.
[[nodiscard]] bool validateDebugApiDialogRequest(
    const DebugApiDialogRequest& request,
    std::wstring& error);

[[nodiscard]] bool validateDebugApiProcessControlRequest(
    const DebugApiProcessControlRequest& request,
    std::wstring& error);

[[nodiscard]] std::string serializeDebugApiDialogReceipt(
    const DebugApiDialogReceipt& receipt,
    bool ok,
    std::string_view code);

[[nodiscard]] std::string serializeDebugApiProcessControlReceipt(
    const DebugApiProcessControlReceipt& receipt,
    bool ok,
    std::string_view code,
    std::wstring_view diagnostic);

// EN: Bounded UTF-8 file input is used for one non-sensitive WDUi value.
// CZ: Omezený UTF-8 soubor slouží pro jednu necitlivou hodnotu WDUi.
[[nodiscard]] bool readDebugApiUtf8ValueFile(
    const std::wstring& path,
    std::wstring& value);

// EN: CREATE_NEW plus an absolute local path prevents receipt collisions and
//     avoids turning the shared control plane into a network file sink.
// CZ: CREATE_NEW s absolutní lokální cestou brání kolizím receiptů a nedovolí
//     ze sdíleného control-plane udělat síťový souborový sink.
[[nodiscard]] bool writeDebugApiResponseFile(
    const std::wstring& path,
    std::string_view response);

}  // namespace wdui
