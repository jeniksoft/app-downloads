# License Notice

WDUi Framework SDK je proprietĂˇrnĂ­ binĂˇrnĂ­ SDK od Jeniksoft.

Tento balĂ­k je veĹ™ejnÄ› ke staĹľenĂ­, ale WDUi knihovna, veĹ™ejnĂ© hlaviÄŤky, JSON skiny a souvisejĂ­cĂ­ runtime assety nejsou vydanĂ© jako open-source projekt. NenĂ­ udÄ›lena licence k redistribuci samotnĂ©ho SDK, repackagingu knihovny nebo publikovĂˇnĂ­ zdrojovĂ˝ch souborĹŻ knihovny bez samostatnĂ©ho svolenĂ­ Jeniksoft.

Aplikace vytvoĹ™enĂ© s tĂ­mto SDK mohou linkovat wdui.lib podle domluvenĂ˝ch podmĂ­nek projektu. Pokud potĹ™ebujeĹˇ distribuovat WDUi SDK dĂˇl, domluv si licenci pĹ™Ă­mo s Jeniksoft.

SloĹľka examples\ je vĂ˝jimka: ukĂˇzkovĂ© zdrojovĂ© soubory mĹŻĹľeĹˇ pouĹľĂ­vat, kopĂ­rovat a upravovat pod MIT-0 licencĂ­; viz examples\LICENSE-MIT-0.txt.

PĹ™ibalenĂ© fonty jsou licencovanĂ© samostatnÄ› pod SIL Open Font License 1.1. Ponech u nich pĹ™Ă­sluĹˇnĂ© OFL.txt soubory.