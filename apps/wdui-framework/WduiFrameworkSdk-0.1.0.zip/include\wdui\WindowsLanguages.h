#pragma once

#include <array>
#include <algorithm>
#include <cwctype>
#include <string>

namespace wdui {

struct WindowsLanguageInfo {
    const wchar_t* code;
    const wchar_t* displayName;
    const wchar_t* nativeName;
};

inline constexpr std::array<WindowsLanguageInfo, 88> kWindowsDisplayLanguages{{
    {L"ar-SA", L"Arabic (Saudi Arabia)", L"العربية (المملكة العربية السعودية)"},
    {L"eu-ES", L"Basque (Spain)", L"euskara (Espainia)"},
    {L"bg-BG", L"Bulgarian (Bulgaria)", L"български (България)"},
    {L"ca-ES", L"Catalan (Spain)", L"català (Espanya)"},
    {L"zh-CN", L"Chinese (China)", L"中文（中国）"},
    {L"zh-TW", L"Chinese (Taiwan)", L"中文（台灣）"},
    {L"hr-HR", L"Croatian (Croatia)", L"hrvatski (Hrvatska)"},
    {L"cs-CZ", L"Czech (Czechia)", L"čeština (Česko)"},
    {L"da-DK", L"Danish (Denmark)", L"dansk (Danmark)"},
    {L"nl-NL", L"Dutch (Netherlands)", L"Nederlands (Nederland)"},
    {L"en-US", L"English (United States)", L"English (United States)"},
    {L"en-GB", L"English (United Kingdom)", L"English (United Kingdom)"},
    {L"et-EE", L"Estonian (Estonia)", L"eesti (Eesti)"},
    {L"fi-FI", L"Finnish (Finland)", L"suomi (Suomi)"},
    {L"fr-CA", L"French (Canada)", L"français (Canada)"},
    {L"fr-FR", L"French (France)", L"français (France)"},
    {L"gl-ES", L"Galician (Spain)", L"galego (España)"},
    {L"de-DE", L"German (Germany)", L"Deutsch (Deutschland)"},
    {L"el-GR", L"Greek (Greece)", L"Ελληνικά (Ελλάδα)"},
    {L"he-IL", L"Hebrew (Israel)", L"עברית (ישראל)"},
    {L"hu-HU", L"Hungarian (Hungary)", L"magyar (Magyarország)"},
    {L"id-ID", L"Indonesian (Indonesia)", L"Indonesia (Indonesia)"},
    {L"it-IT", L"Italian (Italy)", L"italiano (Italia)"},
    {L"ja-JP", L"Japanese (Japan)", L"日本語 (日本)"},
    {L"ko-KR", L"Korean (Korea)", L"한국어(대한민국)"},
    {L"lv-LV", L"Latvian (Latvia)", L"latviešu (Latvija)"},
    {L"lt-LT", L"Lithuanian (Lithuania)", L"lietuvių (Lietuva)"},
    {L"nb-NO", L"Norwegian Bokmål (Norway)", L"norsk bokmål (Norge)"},
    {L"pl-PL", L"Polish (Poland)", L"polski (Polska)"},
    {L"pt-BR", L"Portuguese (Brazil)", L"português (Brasil)"},
    {L"pt-PT", L"Portuguese (Portugal)", L"português (Portugal)"},
    {L"ro-RO", L"Romanian (Romania)", L"română (România)"},
    {L"ru-RU", L"Russian (Russia)", L"русский (Россия)"},
    {L"sr-Latn-RS", L"Serbian (Latin, Serbia)", L"srpski (latinica, Srbija)"},
    {L"sk-SK", L"Slovak (Slovakia)", L"slovenčina (Slovensko)"},
    {L"sl-SI", L"Slovenian (Slovenia)", L"slovenščina (Slovenija)"},
    {L"es-MX", L"Spanish (Mexico)", L"español (México)"},
    {L"es-ES", L"Spanish (Spain)", L"español (España)"},
    {L"sv-SE", L"Swedish (Sweden)", L"svenska (Sverige)"},
    {L"th-TH", L"Thai (Thailand)", L"ไทย (ไทย)"},
    {L"tr-TR", L"Turkish (Türkiye)", L"Türkçe (Türkiye)"},
    {L"uk-UA", L"Ukrainian (Ukraine)", L"українська (Україна)"},
    {L"vi-VN", L"Vietnamese (Vietnam)", L"Tiếng Việt (Việt Nam)"},
    {L"af-ZA", L"Afrikaans (South Africa)", L"Afrikaans (Suid-Afrika)"},
    {L"sq-AL", L"Albanian (Albania)", L"shqip (Shqipëri)"},
    {L"am-ET", L"Amharic (Ethiopia)", L"አማርኛ (ኢትዮጵያ)"},
    {L"hy-AM", L"Armenian (Armenia)", L"հայերեն (Հայաստան)"},
    {L"as-IN", L"Assamese (India)", L"অসমীয়া (ভাৰত)"},
    {L"az-Latn-AZ", L"Azerbaijani (Latin, Azerbaijan)", L"azərbaycan (latın, Azərbaycan)"},
    {L"be-BY", L"Belarusian (Belarus)", L"беларуская (Беларусь)"},
    {L"bn-IN", L"Bangla (India)", L"বাংলা (ভারত)"},
    {L"bs-Latn-BA", L"Bosnian (Latin, Bosnia & Herzegovina)", L"bosanski (latinica, Bosna i Hercegovina)"},
    {L"chr-CHER-US", L"Cherokee (Cherokee, United States)", L"ᏣᎳᎩ (ᏣᎳᎩ, ᏌᏊ ᎢᏳᎾᎵᏍᏔᏅ ᏍᎦᏚᎩ)"},
    {L"fil-PH", L"Filipino (Philippines)", L"Filipino (Pilipinas)"},
    {L"ka-GE", L"Georgian (Georgia)", L"ქართული (საქართველო)"},
    {L"gu-IN", L"Gujarati (India)", L"ગુજરાતી (ભારત)"},
    {L"hi-IN", L"Hindi (India)", L"हिन्दी (भारत)"},
    {L"is-IS", L"Icelandic (Iceland)", L"íslenska (Ísland)"},
    {L"ga-IE", L"Irish (Ireland)", L"Gaeilge (Éire)"},
    {L"kn-IN", L"Kannada (India)", L"ಕನ್ನಡ (ಭಾರತ)"},
    {L"kk-KZ", L"Kazakh (Kazakhstan)", L"қазақ тілі (Қазақстан)"},
    {L"km-KH", L"Khmer (Cambodia)", L"ខ្មែរ (កម្ពុជា)"},
    {L"kok-IN", L"Konkani (India)", L"कोंकणी (भारत)"},
    {L"lo-LA", L"Lao (Laos)", L"ລາວ (ລາວ)"},
    {L"lb-LU", L"Luxembourgish (Luxembourg)", L"Lëtzebuergesch (Lëtzebuerg)"},
    {L"mk-MK", L"Macedonian (North Macedonia)", L"македонски (Северна Македонија)"},
    {L"ms-MY", L"Malay (Malaysia)", L"Melayu (Malaysia)"},
    {L"ml-IN", L"Malayalam (India)", L"മലയാളം (ഇന്ത്യ)"},
    {L"mt-MT", L"Maltese (Malta)", L"Malti (Malta)"},
    {L"mi-NZ", L"Māori (New Zealand)", L"Māori (Aotearoa)"},
    {L"mr-IN", L"Marathi (India)", L"मराठी (भारत)"},
    {L"ne-NP", L"Nepali (Nepal)", L"नेपाली (नेपाल)"},
    {L"nn-NO", L"Norwegian Nynorsk (Norway)", L"norsk nynorsk (Noreg)"},
    {L"or-IN", L"Odia (India)", L"ଓଡ଼ିଆ (ଭାରତ)"},
    {L"fa-IR", L"Persian (Iran)", L"فارسی (ایران)"},
    {L"pa-IN", L"Punjabi (India)", L"ਪੰਜਾਬੀ (ਭਾਰਤ)"},
    {L"quz-PE", L"Quechua (Peru)", L"Runasimi (Perú)"},
    {L"gd-GB", L"Scottish Gaelic (United Kingdom)", L"Gàidhlig (An Rìoghachd Aonaichte)"},
    {L"sr-Cyrl-BA", L"Serbian (Cyrillic, Bosnia & Herzegovina)", L"српски (ћирилица, Босна и Херцеговина)"},
    {L"sr-Cyrl-RS", L"Serbian (Cyrillic, Serbia)", L"српски (ћирилица, Србија)"},
    {L"ta-IN", L"Tamil (India)", L"தமிழ் (இந்தியா)"},
    {L"tt-RU", L"Tatar (Russia)", L"татар (Россия)"},
    {L"te-IN", L"Telugu (India)", L"తెలుగు (భారతదేశం)"},
    {L"ur-PK", L"Urdu (Pakistan)", L"اردو (پاکستان)"},
    {L"ug-CN", L"Uyghur (China)", L"ئۇيغۇرچە (جۇڭگو)"},
    {L"uz-Latn-UZ", L"Uzbek (Latin, Uzbekistan)", L"o‘zbek (lotin, Oʻzbekiston)"},
    {L"ca-ES-valencia", L"Catalan (Spain, Valencian)", L"català (Espanya, valencià)"},
    {L"cy-GB", L"Welsh (United Kingdom)", L"Cymraeg (Y Deyrnas Unedig)"},
}};

inline std::wstring trimWindowsLanguageText(std::wstring text)
{
    auto isSpace = [](wchar_t ch) {
        return std::iswspace(ch) != 0;
    };
    text.erase(text.begin(), std::find_if_not(text.begin(), text.end(), isSpace));
    text.erase(std::find_if_not(text.rbegin(), text.rend(), isSpace).base(), text.end());
    return text;
}

inline std::wstring compactWindowsLanguageName(const std::wstring& value)
{
    std::wstring text = trimWindowsLanguageText(value);
    const std::size_t asciiParen = text.find(L'(');
    const std::size_t fullParen = text.find(L'（');
    std::size_t cut = std::wstring::npos;
    if (asciiParen != std::wstring::npos) {
        cut = asciiParen;
    }
    if (fullParen != std::wstring::npos) {
        cut = cut == std::wstring::npos ? fullParen : std::min(cut, fullParen);
    }
    if (cut != std::wstring::npos) {
        text = trimWindowsLanguageText(text.substr(0, cut));
    }
    return text.empty() ? trimWindowsLanguageText(value) : text;
}

inline std::wstring compactWindowsLanguageName(const WindowsLanguageInfo& language)
{
    std::wstring label = compactWindowsLanguageName(language.nativeName != nullptr ? language.nativeName : L"");
    if (label.empty()) {
        label = compactWindowsLanguageName(language.displayName != nullptr ? language.displayName : L"");
    }
    if (label.empty()) {
        label = language.code != nullptr ? language.code : L"";
    }
    return label;
}

inline std::wstring windowsLanguageTooltip(
    const WindowsLanguageInfo& language,
    const std::wstring& languageCodeLabel = L"Language code")
{
    const std::wstring native = language.nativeName != nullptr ? language.nativeName : L"";
    const std::wstring display = language.displayName != nullptr ? language.displayName : L"";
    const std::wstring code = language.code != nullptr ? language.code : L"";

    std::wstring tooltip = native.empty() ? display : native;
    if (!display.empty() && display != tooltip) {
        if (!tooltip.empty()) {
            tooltip += L"\n";
        }
        tooltip += display;
    }
    if (!code.empty()) {
        if (!tooltip.empty()) {
            tooltip += L"\n";
        }
        tooltip += languageCodeLabel.empty() ? L"Language code" : languageCodeLabel;
        tooltip += L": ";
        tooltip += code;
    }
    return tooltip;
}

} // namespace wdui
