#pragma once

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>

#include <cstdint>
#include <cstddef>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <utility>
#include <array>
#include <vector>

struct ID2D1Factory;
struct ID2D1GdiInteropRenderTarget;
struct ID2D1HwndRenderTarget;

#ifndef WDUI_DEPRECATED
#if defined(__has_cpp_attribute)
#if __has_cpp_attribute(deprecated)
#define WDUI_DEPRECATED(message) [[deprecated(message)]]
#endif
#endif
#endif
#ifndef WDUI_DEPRECATED
#if defined(_MSC_VER)
#define WDUI_DEPRECATED(message) __declspec(deprecated(message))
#elif defined(__clang__) || defined(__GNUC__)
#define WDUI_DEPRECATED(message) __attribute__((deprecated(message)))
#else
#define WDUI_DEPRECATED(message)
#endif
#endif

namespace wdui {

struct Point {
    int x = 0;
    int y = 0;
};

struct Rect {
    int x = 0;
    int y = 0;
    int width = 0;
    int height = 0;

    bool contains(Point point) const;
    RECT toWin32(Point origin = {}) const;
};

struct Size {
    int width = 0;
    int height = 0;
};

enum LayoutAnchor : std::uint32_t {
    AnchorNone = 0,
    AnchorLeft = 1 << 0,
    AnchorTop = 1 << 1,
    AnchorRight = 1 << 2,
    AnchorBottom = 1 << 3,
};

using LayoutAnchors = std::uint32_t;

struct LayoutOptions {
    LayoutAnchors anchors = AnchorLeft | AnchorTop;
    int minWidth = 0;
    int minHeight = 0;
    bool hasExplicitMinimumSize = false;
};

struct RelativeAnchor {
    double ratio = 0.0;
    int offset = 0;
};

struct RelativeLayoutOptions {
    std::optional<RelativeAnchor> left;
    std::optional<RelativeAnchor> right;
    std::optional<RelativeAnchor> top;
    std::optional<RelativeAnchor> bottom;
    std::optional<RelativeAnchor> centerX;
    std::optional<RelativeAnchor> centerY;
    std::optional<int> widthPx;
    std::optional<int> heightPx;
};

struct StateValue {
    std::wstring key;
    std::wstring value;
};

struct ControlState {
    std::wstring id;
    Rect bounds;
    bool visible = true;
    bool enabled = true;
    bool collapsed = false;
    std::wstring styleId;
    std::vector<StateValue> values;
};

struct WindowState {
    Rect normalBounds;
    int showCommand = SW_SHOWNORMAL;
    bool maximized = false;
    bool minimized = false;
};

struct AppUiState {
    WindowState window;
    std::vector<ControlState> controls;
};

struct LocalizedTextEntry {
    std::wstring languageTag;
    std::wstring text;
};

class LocalizationCatalog {
public:
    void clear();
    void set(std::wstring key, std::vector<LocalizedTextEntry> entries);
    void add(std::wstring key, std::wstring languageTag, std::wstring text);
    void setDefault(std::wstring key, std::wstring text);
    bool has(const std::wstring& key) const;
    std::wstring text(
        const std::wstring& key,
        const std::wstring& languageTag,
        const std::wstring& fallbackLanguageTag = L"en") const;

    static std::wstring normalizeLanguageTag(std::wstring tag);
    static std::wstring primaryLanguageTag(std::wstring tag);
    static std::wstring resolveLanguageTag(
        const std::wstring& configuredLanguageTag,
        const std::wstring& fallbackLanguageTag = L"en");
    static std::wstring detectWindowsLanguageTag();

private:
    using TranslationMap = std::unordered_map<std::wstring, std::wstring>;

    static const std::wstring* findTranslation(
        const TranslationMap& translations,
        const std::wstring& languageTag);
    static std::vector<std::wstring> fallbackLanguageTags(
        const std::wstring& languageTag,
        const std::wstring& fallbackLanguageTag);

    std::unordered_map<std::wstring, TranslationMap> entries_;
};

class FontCatalog {
public:
    static int loadAppFontsFromExeDirectory();
    static int loadAppFontsFromDirectory(const std::wstring& directory);
    static void unloadAppFonts();
};

class Window;
class Panel;
class Control;
struct SelectBoxTransientState;
struct DateInputTransientState;
struct MenuBarTransientState;

struct SignalConnectionState {
    bool connected = true;
};

class Connection {
public:
    Connection() = default;

    void disconnect()
    {
        if (auto state = state_.lock()) {
            state->connected = false;
        }
    }

    bool connected() const
    {
        if (auto state = state_.lock()) {
            return state->connected;
        }
        return false;
    }

    explicit operator bool() const
    {
        return connected();
    }

private:
    explicit Connection(std::shared_ptr<SignalConnectionState> state)
        : state_(std::move(state))
    {
    }

    template <typename... Args>
    friend class Signal;

    std::weak_ptr<SignalConnectionState> state_;
};

class ScopedConnection {
public:
    ScopedConnection() = default;
    explicit ScopedConnection(Connection connection)
        : connection_(std::move(connection))
    {
    }

    ScopedConnection(const ScopedConnection&) = delete;
    ScopedConnection& operator=(const ScopedConnection&) = delete;

    ScopedConnection(ScopedConnection&& other) noexcept
        : connection_(std::move(other.connection_))
    {
        other.connection_ = {};
    }

    ScopedConnection& operator=(ScopedConnection&& other) noexcept
    {
        if (this != &other) {
            disconnect();
            connection_ = std::move(other.connection_);
            other.connection_ = {};
        }
        return *this;
    }

    ~ScopedConnection()
    {
        disconnect();
    }

    void reset(Connection connection = {})
    {
        disconnect();
        connection_ = std::move(connection);
    }

    void disconnect()
    {
        connection_.disconnect();
        connection_ = {};
    }

    bool connected() const
    {
        return connection_.connected();
    }

private:
    Connection connection_;
};

template <typename... Args>
class Signal {
public:
    using Callback = std::function<void(Args...)>;

    Connection connect(Callback callback)
    {
        cleanupDisconnected();
        if (!callback) {
            return {};
        }
        auto state = std::make_shared<SignalConnectionState>();
        slots_.push_back(Slot{state, std::move(callback)});
        return Connection{state};
    }

    void emit(Args... args)
    {
        cleanupDisconnected();
        const std::vector<Slot> snapshot = slots_;
        for (const Slot& slot : snapshot) {
            if (slot.state && slot.state->connected && slot.callback) {
                slot.callback(args...);
            }
        }
        cleanupDisconnected();
    }

    void operator()(Args... args)
    {
        emit(args...);
    }

    void clear()
    {
        for (Slot& slot : slots_) {
            if (slot.state) {
                slot.state->connected = false;
            }
        }
        slots_.clear();
    }

    bool empty() const
    {
        return listenerCount() == 0;
    }

    std::size_t listenerCount() const
    {
        std::size_t count = 0;
        for (const Slot& slot : slots_) {
            if (slot.state && slot.state->connected && slot.callback) {
                ++count;
            }
        }
        return count;
    }

private:
    struct Slot {
        std::shared_ptr<SignalConnectionState> state;
        Callback callback;
    };

    void cleanupDisconnected()
    {
        for (std::size_t index = 0; index < slots_.size();) {
            const Slot& slot = slots_[index];
            if (!slot.state || !slot.state->connected || !slot.callback) {
                slots_.erase(slots_.begin() + static_cast<std::ptrdiff_t>(index));
            } else {
                ++index;
            }
        }
    }

    std::vector<Slot> slots_;
};

enum class EventPhase {
    Preview,
    Target,
    Bubble,
};

enum class PointerButton {
    None,
    Left,
    Right,
    Middle,
    X1,
    X2,
};

enum class Orientation {
    Horizontal,
    Vertical
};

struct RoutedEvent {
    Control* source = nullptr;
    Control* target = nullptr;
    EventPhase phase = EventPhase::Target;
    bool handled = false;

    void markHandled()
    {
        handled = true;
    }
};

struct PointerEvent : RoutedEvent {
    Point screenPoint{};
    Point localPoint{};
    PointerButton button = PointerButton::None;
    int clickCount = 0;
    WPARAM keyState = 0;
};

struct WheelEvent : RoutedEvent {
    Point screenPoint{};
    Point localPoint{};
    int delta = 0;
    bool horizontal = false;
    WPARAM keyState = 0;
};

struct KeyEvent : RoutedEvent {
    UINT key = 0;
    bool control = false;
    bool shift = false;
    bool alt = false;
    HWND owner = nullptr;
};

struct TextEvent : RoutedEvent {
    wchar_t ch = 0;
    HWND owner = nullptr;
};

struct FocusEvent : RoutedEvent {
    Control* previous = nullptr;
    Control* current = nullptr;
};

enum class SortDirection {
    None = 0,
    Ascending = 1,
    Descending = 2,
};

struct CommandEvent : RoutedEvent {
    std::wstring commandId;
    std::wstring text;
    std::wstring payload;
};

struct ValueChangedEvent : RoutedEvent {
    std::wstring value;
    std::wstring previousValue;
    int intValue = 0;
    int previousIntValue = 0;
    bool boolValue = false;
    bool previousBoolValue = false;
};

struct SelectionChangedEvent : RoutedEvent {
    int index = -1;
    int previousIndex = -1;
    std::vector<int> path;
    std::vector<int> previousPath;
    std::wstring value;
    std::wstring text;
};

struct ActivationEvent : RoutedEvent {
    int index = -1;
    std::vector<int> path;
    std::wstring value;
    std::wstring text;
    std::wstring payload;
};

struct CommitEvent : RoutedEvent {
    std::wstring value;
    std::wstring text;
    int intValue = 0;
    std::wstring payload;
};

struct ExpandedChangedEvent : RoutedEvent {
    std::vector<int> path;
    bool expanded = false;
    std::wstring value;
    std::wstring text;
};

struct SortChangedEvent : RoutedEvent {
    int column = -1;
    int previousColumn = -1;
    SortDirection direction = SortDirection::None;
    SortDirection previousDirection = SortDirection::None;
    std::wstring value;
    std::wstring text;
};

struct ColumnWidthsChangedEvent : RoutedEvent {
    int column = -1;
    int width = 0;
    int previousWidth = 0;
    std::vector<int> widths;
    std::vector<int> previousWidths;
};

struct LinkActionEvent : RoutedEvent {
    std::wstring linkTarget;
    std::wstring text;
    std::wstring payload;
};

enum class PopupEventKind {
    Close,
    Drag,
    Action,
};

struct PopupEvent : RoutedEvent {
    PopupEventKind kind = PopupEventKind::Action;
    int index = -1;
    std::wstring actionId;
    std::wstring text;
    std::wstring payload;
};

struct ScrollEvent : RoutedEvent {
    Orientation orientation = Orientation::Vertical;
    int offset = 0;
    int previousOffset = 0;
    int maxOffset = 0;
    int delta = 0;
    bool userInitiated = true;
    std::wstring sourceKind;
};

struct DragDeltaEvent : RoutedEvent {
    int dx = 0;
    int dy = 0;
    bool horizontal = false;
    bool vertical = false;
    std::wstring sourceKind;
};

struct WindowResizeEvent : RoutedEvent {
    Size size{};
    Size previousSize{};
    bool maximized = false;
    bool restored = true;
};

class EventDispatcher {
public:
    Connection addPreviewListener(std::function<void(RoutedEvent&)> callback);
    Connection addTargetListener(std::function<void(RoutedEvent&)> callback);
    Connection addBubbleListener(std::function<void(RoutedEvent&)> callback);
    void clear();
    bool empty() const;
    std::size_t listenerCount() const;
    void dispatch(RoutedEvent& event);

private:
    Signal<RoutedEvent&> preview_;
    Signal<RoutedEvent&> target_;
    Signal<RoutedEvent&> bubble_;
};

enum class TransientLayer : int {
    Normal = 0,
    Popup = 100,
    Tooltip = 200,
};

enum class ContourMode {
    None,
    FollowParentEdge,
    DeformToParent,
};

enum class ContourFollowMapping {
    Band,
    Scanline,
};

struct TextStyle {
    std::wstring fontFamily = L"Bahnschrift";
    int pointSize = 10;
    int weight = FW_SEMIBOLD;
    COLORREF color = RGB(240, 246, 244);
    COLORREF disabledColor = RGB(110, 120, 118);
    bool italic = false;
    bool underline = false;
};

struct DebugOptions {
    bool enabled = false;
    bool showBounds = true;
    bool showIds = true;
    bool showCursor = true;
    bool showContentRects = true;
    bool showContourRects = true;
    bool showSkinInfo = true;
    bool diagnosticTrace = false;
    int mode = 0;
    std::wstring contextLabel;
};

enum class TextAlignment {
    Left,
    Center,
    Right
};

enum class TextFormat {
    Plain,
    Markdown
};

struct MarkdownTextStyle {
    int heading1PointDelta = 8;
    int heading2PointDelta = 5;
    int heading3PointDelta = 3;
    int heading4PointDelta = 2;
    int heading5PointDelta = 1;
    int heading6PointDelta = 0;
    int headingWeight = FW_BOLD;
    std::wstring headingFontFamily;
    std::wstring codeFontFamily = L"Cascadia Mono";
    int codePointDelta = -1;
    int codeWeight = FW_NORMAL;
    bool codePreserveBaseColor = true;
};

enum class GradientDirection {
    Vertical,
    VerticalUp,
    Horizontal,
    HorizontalLeft,
    DiagonalDown,
    DiagonalDownReverse,
    DiagonalUp,
    DiagonalUpReverse
};

enum class GradientKind {
    Linear,
    Reflected,
    Radial,
    Diamond,
    Conic
};

enum class SurfaceMaterial {
    Matte,
    Glass,
    FrostedGlass,
    Gloss,
    Metal,
    BrushedMetal,
    Plastic,
    Rubber,
    Paper,
    CarbonFiber,
    ObsidianGlass,
    BloodGloss,
    AmberGlass,
    LuminousGlass
};

enum class SurfaceUvMapping {
    Local,
    Global
};

enum class PerformanceProfile {
    BestGraphics,
    Balanced,
    MaximumPerformance
};

PerformanceProfile defaultPerformanceProfile();
void setDefaultPerformanceProfile(PerformanceProfile profile);

enum class RenderBackend {
    Gdi,
    Direct2D,
    Auto
};

RenderBackend defaultRenderBackend();
void setDefaultRenderBackend(RenderBackend backend);

enum class ButtonShape {
    Rectangle,
    RoundedRectangle,
    Capsule,
    Diamond,
    Beveled,
    Octagon,
    Hexagon,
    SlantRight,
    SlantLeft
};

enum class SurfaceGeometryMode {
    FallbackShape,
    SkinAlphaHitTest,
    SkinAlphaLayout,
    MaskAlphaLayout
};

enum class SurfaceRole {
    Paint,
    Hit,
    Text,
    ChildLayout,
    Header,
    ActionRow,
    ScrollTrack
};

enum class EdgeAnchor {
    Left,
    Top,
    Right,
    Bottom
};

struct SliceInsets {
    int left = 0;
    int top = 0;
    int right = 0;
    int bottom = 0;
};

struct Theme {
    COLORREF frame = RGB(164, 122, 69);
    COLORREF shell = RGB(5, 10, 15);
    COLORREF panel = RGB(7, 22, 29);
    COLORREF header = RGB(12, 58, 54);
    COLORREF control = RGB(8, 22, 28);
    COLORREF controlHot = RGB(31, 82, 82);
    COLORREF controlPressed = RGB(18, 70, 65);
    COLORREF border = RGB(34, 66, 68);
    COLORREF accent = RGB(196, 148, 82);
    COLORREF accentHot = RGB(226, 170, 88);
    COLORREF text = RGB(211, 228, 221);
    COLORREF textHot = RGB(246, 238, 207);
    COLORREF mutedText = RGB(176, 204, 196);
    COLORREF disabledText = RGB(122, 146, 140);
    COLORREF disabledFill = RGB(6, 11, 13);
    TextStyle uiText{};
    TextStyle monoText{L"Cascadia Mono", 10, FW_NORMAL, RGB(211, 228, 221), RGB(122, 146, 140)};

    static Theme taskBoardFamily();
};

enum class SkinSurfaceMode {
    Flat2D,
    Sculpted3D,
    Textured,
    BitmapPlates,
    WindowsClean
};

enum class WindowControlGlyph {
    Minimize,
    Maximize,
    Restore,
    ResetSize,
    Close
};

enum class BitmapTintMode {
    None,
    MonochromeMask,
    LumaMask,
    AlphaMask,
    TintColored,
    Multiply,
    PaletteMap
};

enum class BitmapTintMaskChannel {
    Alpha,
    Red,
    Green,
    Blue,
    Luminance
};

struct BitmapTint {
    static constexpr std::size_t MaxPaletteColors = 32;

    BitmapTintMode mode = BitmapTintMode::None;
    BitmapTintMaskChannel maskChannel = BitmapTintMaskChannel::Luminance;
    COLORREF color = RGB(255, 255, 255);
    COLORREF secondaryColor = RGB(0, 0, 0);
    std::array<COLORREF, MaxPaletteColors> palette{};
    std::uint8_t paletteSize = 0;
    std::uint8_t amount = 255;
    std::uint8_t coverageThreshold = 1;
    bool preserveLuminance = true;
    bool invertMask = false;
};

struct SkinScrollBarShapeHints {
    std::optional<ButtonShape> track;
    std::optional<ButtonShape> thumb;
    std::optional<ButtonShape> button;
    int buttonExtent = -1;
    int minThumbExtent = -1;
    int trackPadding = -1;
    int trackThickness = -1;
    int thumbThickness = -1;
    int showButtons = -1;
};

struct SkinShapeHints {
    std::optional<ButtonShape> window;
    std::optional<ButtonShape> primaryButton;
    std::optional<ButtonShape> secondaryButton;
    std::optional<ButtonShape> panel;
    std::optional<ButtonShape> card;
    std::optional<ButtonShape> cardHeader;
    std::optional<ButtonShape> chrome;
    std::optional<ButtonShape> statusChip;
    std::optional<ButtonShape> statusBadge;
    std::optional<ButtonShape> progressFrame;
    std::optional<ButtonShape> progressTrack;
    std::optional<ButtonShape> progressFill;
    std::optional<ButtonShape> checkBox;
    std::optional<ButtonShape> selectBox;
    std::optional<ButtonShape> selectBoxArrow;
    std::optional<ButtonShape> selectBoxDropdown;
    std::optional<ButtonShape> listBox;
    std::optional<ButtonShape> listBoxRow;
    std::optional<ButtonShape> listBoxSelectedRow;
    std::optional<ButtonShape> listBoxSelectedRail;
    std::optional<ButtonShape> tabItem;
    std::optional<ButtonShape> menuBar;
    std::optional<ButtonShape> menuItem;
    std::optional<ButtonShape> menuPopup;
    std::optional<ButtonShape> menuPopupItem;
    std::optional<ButtonShape> table;
    std::optional<ButtonShape> tableHeader;
    std::optional<ButtonShape> tableRow;
    std::optional<ButtonShape> tableSelectedRow;
    std::optional<ButtonShape> tableSelectedRail;
    std::optional<ButtonShape> richText;
    std::optional<ButtonShape> richTextIcon;
    std::optional<ButtonShape> textInput;
    std::optional<ButtonShape> textInputAttachment;
    std::optional<ButtonShape> selectableText;
    std::optional<ButtonShape> popup;
    std::optional<ButtonShape> popupHeader;
    std::optional<ButtonShape> popupIcon;
    std::optional<ButtonShape> tooltip;
    std::optional<ButtonShape> tooltipRail;
    std::optional<ButtonShape> tooltipIcon;
    SkinScrollBarShapeHints scrollBar;
};

struct SkinStyleOverride {
    std::wstring type;
    std::wstring id;
    std::unordered_map<std::wstring, std::wstring> properties;
};

struct SkinMaterialProfile {
    bool enabled = false;
    SurfaceMaterial surface = SurfaceMaterial::Matte;
    SurfaceMaterial control = SurfaceMaterial::Matte;
    SurfaceMaterial accent = SurfaceMaterial::Matte;
    COLORREF tint = RGB(255, 255, 255);
    COLORREF backlightColor = RGB(255, 120, 42);
    std::uint8_t strength = 0;
    std::uint8_t highlightOpacity = 70;
    std::uint8_t reflectionOpacity = 38;
    std::uint8_t grainOpacity = 0;
    std::uint8_t depth = 0;
    std::uint8_t backlightOpacity = 72;
    std::uint8_t innerGlow = 86;
    std::uint8_t rimLight = 88;
    std::uint8_t lightElevation = 62;
    int scale = 18;
    int angle = 0;
    int lightAngle = -45;
    int lightBlobScale = 480;
    int lightBlobAngle = -22;
    int animationSpeed = 0;
    SurfaceUvMapping uvMapping = SurfaceUvMapping::Local;
    int uvScale = 256;
    int uvOffsetX = 0;
    int uvOffsetY = 0;
    GradientKind gradientKind = GradientKind::Linear;
    GradientDirection gradientDirection = GradientDirection::Vertical;
};

struct SkinPreset {
    std::wstring id;
    std::wstring name;
    std::wstring description;
    std::wstring category;
    std::wstring harmony;
    std::wstring sourceDirectory;
    std::vector<std::wstring> tags;
    std::vector<SkinStyleOverride> styleOverrides;
    Theme theme;
    SkinSurfaceMode surfaceMode = SkinSurfaceMode::Sculpted3D;
    SkinMaterialProfile materials;
    SkinShapeHints shapes;
};

class Image {
public:
    Image() = default;
    ~Image();
    Image(const Image& other);
    Image& operator=(const Image& other);
    Image(Image&& other) noexcept;
    Image& operator=(Image&& other) noexcept;

    bool loadFromFile(const std::wstring& path);
    bool loadFromIconHandle(HICON icon, int width = 0, int height = 0);

    static Image makeCapsule(int width, int height, COLORREF top, COLORREF bottom, COLORREF border);
    static Image makeDiamond(int width, int height, COLORREF top, COLORREF bottom, COLORREF border);
    static Image makeWindowControlGlyph(
        WindowControlGlyph glyph,
        int width,
        int height,
        COLORREF color,
        COLORREF shadow = RGB(0, 0, 0),
        COLORREF highlight = RGB(255, 255, 255));

    bool empty() const;
    int width() const;
    int height() const;
    std::uint8_t alphaAt(int x, int y) const;
    std::uint8_t alphaAtScaled(Point localPoint, int drawWidth, int drawHeight) const;
    Image tinted(const BitmapTint& tint) const;
    void draw(HDC hdc, const Rect& destination, std::uint8_t opacity = 255) const;
    void drawTinted(HDC hdc, const Rect& destination, const BitmapTint& tint, std::uint8_t opacity = 255) const;
    void drawNineSlice(HDC hdc, const Rect& destination, SliceInsets insets, std::uint8_t opacity = 255) const;
    void drawNineSliceTinted(HDC hdc, const Rect& destination, SliceInsets insets, const BitmapTint& tint, std::uint8_t opacity = 255) const;

private:
    friend class AnimatedImage;

    int width_ = 0;
    int height_ = 0;
    std::vector<std::uint8_t> pixelsPbgra_;
    mutable HDC drawCacheDc_ = nullptr;
    mutable HBITMAP drawCacheBitmap_ = nullptr;
    mutable HGDIOBJ drawCacheOldBitmap_ = nullptr;
    mutable void* drawCacheBits_ = nullptr;
    mutable bool drawCacheDirty_ = true;
    mutable std::vector<std::pair<std::uint64_t, std::shared_ptr<Image>>> tintedCache_;

    void invalidateDrawCache() const;
    void releaseDrawCache() const;
    bool ensureDrawCache(HDC hdc) const;
    const Image& cachedTinted(const BitmapTint& tint) const;
    void reset(int width, int height);
    void setPixel(int x, int y, COLORREF color, std::uint8_t alpha);
};

struct SurfaceGeometry {
    SurfaceGeometryMode mode = SurfaceGeometryMode::FallbackShape;
    Image mask;
    SliceInsets paintInsets{};
    SliceInsets hitInsets{};
    SliceInsets textInsets{};
    SliceInsets childLayoutInsets{};
    SliceInsets headerInsets{};
    SliceInsets actionRowInsets{};
    SliceInsets scrollTrackInsets{};
    int bandHeight = 14;
};

class AnimatedImage {
public:
    bool loadFromFile(const std::wstring& path);
    bool empty() const;
    int width() const;
    int height() const;
    std::size_t frameCount() const;
    void draw(HDC hdc, const Rect& destination, std::uint8_t opacity = 255) const;

private:
    struct Frame {
        Image image;
        UINT durationMilliseconds = 100;
    };

    std::vector<Frame> frames_;
    UINT totalDurationMilliseconds_ = 0;
};

struct SurfaceStyle {
    ButtonShape shape = ButtonShape::Rectangle;
    COLORREF fill = RGB(8, 22, 28);
    COLORREF border = RGB(196, 148, 82);
    COLORREF shadow = RGB(0, 0, 0);
    COLORREF glow = RGB(80, 210, 190);
    COLORREF outline = RGB(255, 230, 170);
    COLORREF noise = RGB(255, 255, 255);
    COLORREF gradientStart = RGB(8, 22, 28);
    COLORREF gradientMid = RGB(8, 22, 28);
    COLORREF gradientEnd = RGB(8, 22, 28);
    COLORREF materialTint = RGB(255, 255, 255);
    COLORREF backlightColor = RGB(255, 120, 42);
    Image skin;
    BitmapTint tint;
    SurfaceGeometry geometry;
    SliceInsets nineSliceInsets{};
    std::uint8_t opacity = 255;
    std::uint8_t alphaThreshold = 16;
    std::uint8_t shadowOpacity = 120;
    std::uint8_t glowOpacity = 76;
    std::uint8_t noiseOpacity = 0;
    std::uint8_t materialStrength = 0;
    std::uint8_t highlightOpacity = 70;
    std::uint8_t reflectionOpacity = 38;
    std::uint8_t grainOpacity = 0;
    std::uint8_t materialDepth = 0;
    std::uint8_t backlightOpacity = 72;
    std::uint8_t innerGlow = 86;
    std::uint8_t rimLight = 88;
    std::uint8_t materialLightElevation = 62;
    int shadowOffsetX = 0;
    int shadowOffsetY = 0;
    int glowRadius = 0;
    int outlineWidth = 0;
    int materialScale = 18;
    int materialAngle = 0;
    int materialLightAngle = -45;
    int lightBlobScale = 480;
    int lightBlobAngle = -22;
    int animationSpeed = 0;
    SurfaceUvMapping uvMapping = SurfaceUvMapping::Local;
    int uvScale = 256;
    int uvOffsetX = 0;
    int uvOffsetY = 0;
    std::uint32_t noiseSeed = 0x9e3779b9u;
    GradientDirection gradientDirection = GradientDirection::Vertical;
    GradientKind gradientKind = GradientKind::Linear;
    SurfaceMaterial material = SurfaceMaterial::Matte;
    bool drawFill = true;
    bool drawBorder = true;
    bool showShadow = false;
    bool showGlow = false;
    bool showOutline = false;
    bool useGradient = false;
    bool useGradientMid = false;
    bool useNineSlice = false;
    bool useNoise = false;
    bool useSkinAlphaHitTest = false;

    static SurfaceStyle solid(COLORREF fill, COLORREF border, ButtonShape shape = ButtonShape::Rectangle);
    static SurfaceStyle gradient(
        COLORREF start,
        COLORREF end,
        COLORREF border,
        ButtonShape shape = ButtonShape::Rectangle,
        GradientDirection direction = GradientDirection::Vertical);
    static SurfaceStyle bitmap(Image skin, ButtonShape fallbackShape = ButtonShape::Rectangle, std::uint8_t opacity = 255);
    static SurfaceStyle nineSlice(
        Image skin,
        SliceInsets insets,
        ButtonShape fallbackShape = ButtonShape::Rectangle,
        std::uint8_t opacity = 255);
    SurfaceStyle withShadow(
        COLORREF shadowColor = RGB(0, 0, 0),
        int offsetX = 5,
        int offsetY = 6,
        std::uint8_t opacity = 120) const;
    SurfaceStyle withGlow(COLORREF glowColor = RGB(80, 210, 190), int radius = 8, std::uint8_t opacity = 76) const;
    SurfaceStyle withOutline(COLORREF outlineColor = RGB(255, 230, 170), int width = 1) const;
    SurfaceStyle withNoise(
        COLORREF noiseColor = RGB(255, 255, 255),
        std::uint8_t opacity = 14,
        std::uint32_t seed = 0x9e3779b9u) const;
    SurfaceStyle withGradient(
        COLORREF start,
        COLORREF end,
        GradientDirection direction = GradientDirection::Vertical) const;
    SurfaceStyle withGradient(
        COLORREF start,
        COLORREF mid,
        COLORREF end,
        GradientKind kind,
        GradientDirection direction = GradientDirection::Vertical) const;
    SurfaceStyle withMaterial(
        SurfaceMaterial materialKind,
        std::uint8_t strength = 150,
        std::uint8_t highlightOpacity = 70,
        std::uint8_t reflectionOpacity = 38) const;
    SurfaceStyle withMaterialLighting(
        std::uint8_t depth = 34,
        int lightAngle = -45,
        std::uint8_t lightElevation = 62) const;
    SurfaceStyle withGlass(
        std::uint8_t strength = 150,
        std::uint8_t highlightOpacity = 86,
        std::uint8_t reflectionOpacity = 54) const;
    SurfaceStyle withLuminousGlass(
        COLORREF backlightColor,
        std::uint8_t strength = 168,
        std::uint8_t backlightOpacity = 72,
        std::uint8_t innerGlow = 86,
        std::uint8_t rimLight = 88) const;
    SurfaceStyle withUvMapping(
        SurfaceUvMapping mapping,
        int scale = 256,
        int offsetX = 0,
        int offsetY = 0) const;
    SurfaceStyle withNineSlice(SliceInsets insets) const;
    SurfaceStyle withTint(BitmapTint tint) const;
};

struct WindowStyle {
    SurfaceStyle surface;
    COLORREF fallbackBackground = RGB(5, 10, 15);
    bool drawSurface = true;
    bool customFrame = false;
    bool useSurfaceRegion = false;
    bool useChildSurfaceRegion = false;
    bool clipRegionOnResize = true;
    int resizeBorderThickness = 7;

    static WindowStyle fromTheme(Theme theme = Theme::taskBoardFamily());
    static WindowStyle fromSkin(const SkinPreset& skin);
    static WindowStyle dialog(Theme theme = Theme::taskBoardFamily());
};

struct StatefulSurfaceStyle {
    SurfaceStyle normal;
    SurfaceStyle hot;
    SurfaceStyle pressed;
    SurfaceStyle disabled;
    SurfaceStyle active;

    const SurfaceStyle& forState(bool enabled, bool hot, bool pressed, bool active) const;
};

struct StatefulTextStyle {
    TextStyle normal;
    TextStyle hot;
    TextStyle pressed;
    TextStyle disabled;
    TextStyle active;

    const TextStyle& forState(bool enabled, bool hot, bool pressed, bool active) const;
};

struct StatefulBitmapTint {
    BitmapTint normal;
    BitmapTint hot;
    BitmapTint pressed;
    BitmapTint disabled;
    BitmapTint active;

    const BitmapTint& forState(bool enabled, bool hot, bool pressed, bool active) const;
};

struct ButtonStyle {
    StatefulSurfaceStyle surface;
    StatefulTextStyle text;
    ButtonShape hitShape = ButtonShape::Rectangle;
    bool useSurfaceHitTesting = true;

    static ButtonStyle fromTheme(Theme theme = Theme::taskBoardFamily(), ButtonShape shape = ButtonShape::Rectangle);
};

struct BitmapButtonStyle {
    StatefulBitmapTint tint;
    TextStyle text;

    static BitmapButtonStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct PanelStyle {
    SurfaceStyle surface;
    int padding = 0;

    static PanelStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct CardStyle {
    SurfaceStyle surface;
    SurfaceStyle header;
    TextStyle titleText;
    TextStyle subtitleText;
    int headerHeight = 26;
    int contentPadding = 8;

    static CardStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct ChromeTitleBarStyle {
    SurfaceStyle surface;
    ButtonStyle titleButton;
    TextStyle titleText;
    int buttonWidth = 42;
    int buttonHeight = 24;
    int buttonTop = 6;
    int buttonGap = 0;
    int headerActionGap = 4;
    int headerActionGroupGap = 6;
    int rightMargin = 18;
    int iconSize = 20;
    int iconLeft = 10;
    int titleLeft = 42;

    static ChromeTitleBarStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct StatusChipStyle {
    SurfaceStyle surface;
    SurfaceStyle badge;
    TextStyle text;
    int badgeSize = 12;
    int badgeLeft = 8;
    int textLeft = 28;

    static StatusChipStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct ProgressBarStyle {
    SurfaceStyle frame;
    SurfaceStyle track;
    SurfaceStyle fill;
    TextStyle labelText;
    int insetX = 3;
    int insetY = 6;
    int labelWidth = 56;
    int labelPaddingX = 8;

    static ProgressBarStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct ScrollAccelerationStyle {
    bool enabled = true;
    double strength = 0.45;
    double maxMultiplier = 4.0;
    int fastIntervalMs = 42;
    int resetMs = 180;
};

struct ScrollBarStyle {
    SurfaceStyle track;
    StatefulSurfaceStyle thumb;
    StatefulSurfaceStyle decrementButton;
    StatefulSurfaceStyle incrementButton;
    ScrollAccelerationStyle acceleration;
    COLORREF arrow = RGB(176, 204, 196);
    int buttonExtent = 18;
    int minThumbExtent = 28;
    int trackPadding = 2;
    int trackThickness = 0;
    int thumbThickness = 0;
    bool showButtons = true;

    static ScrollBarStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct ToggleSwitchStyle {
    StatefulSurfaceStyle trackOff;
    StatefulSurfaceStyle trackOn;
    StatefulSurfaceStyle knob;
    int trackHeight = 22;
    int padding = 3;

    static ToggleSwitchStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

enum class SplitterOrientation {
    Vertical,
    Horizontal,
    Both
};

struct SplitterStyle {
    SurfaceStyle track;
    StatefulSurfaceStyle grip;
    int trackThickness = 1;
    int gripThickness = 4;
    int gripLength = 54;
    int hotPadding = 2;

    static SplitterStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct CheckBoxStyle {
    SurfaceStyle boxUnchecked;
    SurfaceStyle boxUncheckedHot;
    SurfaceStyle boxUncheckedPressed;
    SurfaceStyle boxUncheckedDisabled;
    SurfaceStyle boxChecked;
    SurfaceStyle boxCheckedHot;
    SurfaceStyle boxCheckedPressed;
    SurfaceStyle boxCheckedDisabled;
    COLORREF checkColor = RGB(246, 238, 207);
    TextStyle text;
    int boxSize = 13;
    int textLeft = 22;

    static CheckBoxStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct SelectBoxStyle {
    SurfaceStyle surface;
    SurfaceStyle hotSurface;
    SurfaceStyle pressedSurface;
    SurfaceStyle disabledSurface;
    SurfaceStyle arrowSurface;
    SurfaceStyle arrowHotSurface;
    SurfaceStyle arrowPressedSurface;
    SurfaceStyle arrowDisabledSurface;
    SurfaceStyle dropdownSurface;
    SurfaceStyle optionHotSurface;
    SurfaceStyle optionSelectedSurface;
    ScrollBarStyle scrollBar;
    TextStyle text;
    COLORREF arrowColor = RGB(176, 204, 196);
    COLORREF recommendationStarFill = RGB(238, 178, 76);
    COLORREF recommendationStarHotFill = RGB(92, 218, 255);
    COLORREF recommendationStarBorder = RGB(255, 238, 184);
    COLORREF recommendationStarShadow = RGB(21, 12, 6);
    COLORREF recommendationStarGlow = RGB(76, 204, 255);
    int arrowWidth = 24;
    int itemHeight = 24;
    int maxVisibleItems = 8;
    int dropdownGap = 2;
    int dropdownPadding = 2;
    int dropdownItemPaddingX = 6;
    int dropdownItemPaddingY = 1;
    int dropdownScrollBarWidth = 18;
    int dropdownScrollRailGap = 6;
    int recommendationStarSize = 10;
    int recommendationStarGap = 2;
    int recommendationStarPadding = 6;
    bool dropdownEmbeddedScrollRail = true;

    static SelectBoxStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct SelectBoxItem {
    std::wstring text;
    std::wstring tooltip;
    int recommendationStars = 0;
};

enum class SelectBoxDropdownMode {
    List,
    HierarchicalListBox,
};

struct ListBoxStyle {
    SurfaceStyle surface;
    SurfaceStyle row;
    SurfaceStyle rowHot;
    SurfaceStyle rowPressed;
    SurfaceStyle selectedRow;
    SurfaceStyle selectedRowHot;
    SurfaceStyle selectedRail;
    ScrollBarStyle scrollBar;
    TextStyle text;
    TextStyle selectedText;
    TextStyle disabledText;
    COLORREF separator = RGB(23, 57, 63);
    int rowHeight = 24;
    int railWidth = 4;
    int linePadding = 1;
    int contentInsetX = 8;
    int contentInsetY = 4;
    int itemPaddingX = 8;
    int itemPaddingY = 2;
    int scrollBarWidth = 12;
    int scrollRailGap = 6;
    bool showSeparators = false;

    static ListBoxStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct ListBoxItem {
    std::wstring text;
    std::wstring value;
    std::wstring tooltip;
    bool enabled = true;
};

enum class HierarchicalListBoxItemRole {
    Default,
    Header,
    Group,
    Info,
    Success,
    Warning,
    Danger,
    Accent,
    Muted,
};

struct HierarchicalListBoxBadge {
    std::wstring text;
    std::wstring tooltip;
    bool enabled = true;
    bool hasTextColor = false;
    COLORREF textColor = RGB(240, 246, 244);
    bool hasFillColor = false;
    COLORREF fillColor = RGB(8, 22, 28);
    bool hasBorderColor = false;
    COLORREF borderColor = RGB(196, 148, 82);
};

struct HierarchicalListBoxItemTooltipButton {
    std::wstring id;
    std::wstring label;
};

struct HierarchicalListBoxItem {
    std::wstring text;
    std::wstring value;
    std::wstring tooltip;
    bool enabled = true;
    bool expanded = true;
    std::vector<HierarchicalListBoxItem> children;
    HierarchicalListBoxItemRole role = HierarchicalListBoxItemRole::Default;
    std::wstring iconText;
    std::vector<HierarchicalListBoxBadge> badges;
    std::vector<HierarchicalListBoxItemTooltipButton> tooltipButtons;
    bool strong = false;
    bool hasTextColor = false;
    COLORREF textColor = RGB(240, 246, 244);
    bool hasRowFillColor = false;
    COLORREF rowFillColor = RGB(8, 22, 28);
    bool hasRowBorderColor = false;
    COLORREF rowBorderColor = RGB(196, 148, 82);
};

class HierarchicalListBoxItemControl;

enum class DiskViewerItemKind {
    Root,
    Parent,
    Directory,
    File,
};

struct DiskViewerItem {
    std::wstring name;
    std::wstring path;
    std::wstring tooltip;
    DiskViewerItemKind kind = DiskViewerItemKind::File;
    bool enabled = true;
};

class DiskViewerItemControl;

struct DateValue {
    int year = 0;
    int month = 0;
    int day = 0;
};

struct DateInputStyle {
    SurfaceStyle surface;
    SurfaceStyle hotSurface;
    SurfaceStyle pressedSurface;
    SurfaceStyle disabledSurface;
    SurfaceStyle arrowSurface;
    SurfaceStyle arrowHotSurface;
    SurfaceStyle arrowPressedSurface;
    SurfaceStyle arrowDisabledSurface;
    SurfaceStyle popupSurface;
    SurfaceStyle headerSurface;
    SurfaceStyle dayHotSurface;
    SurfaceStyle dayPressedSurface;
    SurfaceStyle daySelectedSurface;
    SurfaceStyle todaySurface;
    TextStyle text;
    TextStyle headerText;
    TextStyle weekdayText;
    TextStyle dayText;
    TextStyle saturdayText;
    TextStyle sundayText;
    TextStyle mutedDayText;
    COLORREF arrowColor = RGB(176, 204, 196);
    int arrowWidth = 28;
    int popupWidth = 318;
    int popupPadding = 12;
    int popupGap = 2;
    int headerHeight = 42;
    int weekdayHeight = 28;
    int dayCellHeight = 34;
    int navButtonExtent = 26;

    static DateInputStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct TabStripStyle {
    ButtonStyle itemButton;
    int verticalItemHeight = 32;

    static TabStripStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct MenuBarStyle {
    SurfaceStyle surface;
    SurfaceStyle itemSurface;
    SurfaceStyle itemHotSurface;
    SurfaceStyle itemPressedSurface;
    SurfaceStyle itemActiveSurface;
    SurfaceStyle popupSurface;
    SurfaceStyle popupItemHotSurface;
    SurfaceStyle popupItemPressedSurface;
    TextStyle itemText;
    TextStyle shortcutText;
    COLORREF separator = RGB(34, 66, 68);
    COLORREF check = RGB(246, 238, 207);
    COLORREF arrow = RGB(176, 204, 196);
    int height = 28;
    int itemPaddingX = 12;
    int itemGap = 2;
    int popupPadding = 4;
    int popupItemHeight = 26;
    int popupMinWidth = 180;
    int checkColumnWidth = 24;
    int shortcutColumnWidth = 74;
    int submenuArrowWidth = 22;
    int separatorHeight = 9;
    int popupGap = 2;
    bool drawSurface = true;
    bool drawItemSurface = false;

    static MenuBarStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct TableListStyle {
    SurfaceStyle surface;
    SurfaceStyle header;
    SurfaceStyle row;
    SurfaceStyle selectedRow;
    SurfaceStyle selectedRail;
    TextStyle headerText;
    TextStyle rowText;
    TextStyle selectedText;
    TextStyle highSeverityText;
    COLORREF highSeverityFill = RGB(42, 24, 24);
    COLORREF mediumSeverityFill = RGB(24, 34, 42);
    COLORREF lowSeverityFill = RGB(13, 24, 26);
    COLORREF separator = RGB(23, 57, 63);
    COLORREF resizeGrip = RGB(90, 170, 160);
    COLORREF resizeGripHot = RGB(128, 224, 210);
    COLORREF sortIndicator = RGB(190, 210, 204);
    COLORREF sortIndicatorHot = RGB(223, 238, 232);
    ScrollAccelerationStyle scrollAcceleration;
    int headerHeight = 24;
    int rowHeight = 20;
    int railWidth = 4;
    int resizeGripWidth = 7;
    int sortIndicatorWidth = 14;
    int linePadding = 1;
    int contentInsetX = 10;
    int contentInsetY = 2;

    static TableListStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct RichTextStyle {
    SurfaceStyle surface;
    SurfaceStyle icon;
    TextStyle text;
    TextStyle linkText;
    int paddingX = 8;
    int paddingY = 6;
    int lineHeight = 22;

    static RichTextStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

enum class TextInputAttachmentKind {
    File,
    Image
};

struct TextInputAttachment {
    std::wstring id;
    std::wstring path;
    std::wstring displayName;
    TextInputAttachmentKind kind = TextInputAttachmentKind::File;
    Image thumbnail;
};

struct TextInputFilter {
    std::wstring allowedCharacters;
    std::wstring rejectedCharacters;
    std::function<std::wstring(std::wstring)> sanitizeText;
    std::function<bool(const std::wstring&)> acceptsText;
};

struct TextInputStyle {
    SurfaceStyle surface;
    SurfaceStyle hotSurface;
    SurfaceStyle pressedSurface;
    SurfaceStyle disabledSurface;
    SurfaceStyle focusedSurface;
    SurfaceStyle selection;
    SurfaceStyle attachmentSurface;
    SurfaceStyle attachmentImageSurface;
    SurfaceStyle attachmentRemoveSurface;
    TextStyle text;
    TextStyle placeholderText;
    TextStyle attachmentText;
    ScrollAccelerationStyle scrollAcceleration;
    COLORREF caretColor = RGB(246, 238, 207);
    COLORREF attachmentIconColor = RGB(176, 204, 196);
    int paddingX = 8;
    int paddingY = 6;
    int lineHeight = 20;
    int attachmentHeight = 28;
    int attachmentGap = 4;
    int attachmentRemoveExtent = 18;
    bool showAttachmentRemove = true;

    static TextInputStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct SelectableTextStyle {
    SurfaceStyle surface;
    SurfaceStyle selection;
    TextStyle text;
    TextStyle selectedText;
    ScrollAccelerationStyle scrollAcceleration;
    int paddingX = 8;
    int paddingY = 6;
    int lineHeight = 18;

    static SelectableTextStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct PopupStyle {
    SurfaceStyle surface;
    SurfaceStyle header;
    SurfaceStyle icon;
    ButtonStyle closeButton;
    ButtonStyle primaryAction;
    ButtonStyle secondaryAction;
    TextStyle titleText;
    TextStyle messageText;
    TextStyle iconText;
    int headerHeight = 38;
    int paddingX = 18;
    int paddingY = 16;
    int iconSize = 20;
    int actionWidth = 118;
    int actionHeight = 30;
    int actionGap = 8;
    int shadowOffsetX = 6;
    int shadowOffsetY = 8;
    bool showShadow = true;

    static PopupStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

struct TooltipStyle {
    SurfaceStyle surface;
    SurfaceStyle accentRail;
    SurfaceStyle icon;
    COLORREF shadow = RGB(0, 0, 0);
    TextStyle textStyle{L"Bahnschrift", 9, FW_NORMAL, RGB(211, 228, 221), RGB(122, 146, 140)};
    std::wstring iconText = L"?";
    ScrollAccelerationStyle scrollAcceleration;
    int maxWidth = 360;
    int paddingX = 14;
    int paddingY = 10;
    int iconSize = 18;
    int gap = 8;
    int shadowOffsetX = 7;
    int shadowOffsetY = 8;
    bool showAccentRail = true;
    bool showIcon = true;
    bool showShadow = true;

    static TooltipStyle fromTheme(Theme theme = Theme::taskBoardFamily());
};

enum class TooltipActionKind {
    Link,
    Button
};

enum class TooltipInteractionMode {
    PinOnClick,
    PointerTransit
};

struct TooltipAction {
    std::wstring id;
    std::wstring label;
    TooltipActionKind kind = TooltipActionKind::Link;
};

class Control;

class StyleCatalog {
public:
    explicit StyleCatalog(Theme theme = Theme::taskBoardFamily());

    static StyleCatalog taskBoardFamily(Theme theme = Theme::taskBoardFamily());
    static StyleCatalog fromSkin(const SkinPreset& skin);
    static StyleCatalog fromSkinId(const std::wstring& skinId);

    const Theme& theme() const;
    void setTheme(Theme theme);

    StyleCatalog& setTextStyle(std::wstring id, TextStyle style);
    StyleCatalog& setButton(std::wstring id, ButtonStyle style);
    StyleCatalog& setBitmapButton(std::wstring id, BitmapButtonStyle style);
    StyleCatalog& setPanel(std::wstring id, PanelStyle style);
    StyleCatalog& setCard(std::wstring id, CardStyle style);
    StyleCatalog& setChromeTitleBar(std::wstring id, ChromeTitleBarStyle style);
    StyleCatalog& setStatusChip(std::wstring id, StatusChipStyle style);
    StyleCatalog& setProgressBar(std::wstring id, ProgressBarStyle style);
    StyleCatalog& setScrollBar(std::wstring id, ScrollBarStyle style);
    StyleCatalog& setToggleSwitch(std::wstring id, ToggleSwitchStyle style);
    StyleCatalog& setSplitter(std::wstring id, SplitterStyle style);
    StyleCatalog& setCheckBox(std::wstring id, CheckBoxStyle style);
    StyleCatalog& setSelectBox(std::wstring id, SelectBoxStyle style);
    StyleCatalog& setListBox(std::wstring id, ListBoxStyle style);
    StyleCatalog& setDateInput(std::wstring id, DateInputStyle style);
    StyleCatalog& setTabStrip(std::wstring id, TabStripStyle style);
    StyleCatalog& setMenuBar(std::wstring id, MenuBarStyle style);
    StyleCatalog& setTableList(std::wstring id, TableListStyle style);
    StyleCatalog& setRichText(std::wstring id, RichTextStyle style);
    StyleCatalog& setTextInput(std::wstring id, TextInputStyle style);
    StyleCatalog& setSelectableText(std::wstring id, SelectableTextStyle style);
    StyleCatalog& setPopup(std::wstring id, PopupStyle style);
    StyleCatalog& setTooltip(std::wstring id, TooltipStyle style);

    const TextStyle* textStyle(const std::wstring& id) const;
    const ButtonStyle* button(const std::wstring& id) const;
    const BitmapButtonStyle* bitmapButton(const std::wstring& id) const;
    const PanelStyle* panel(const std::wstring& id) const;
    const CardStyle* card(const std::wstring& id) const;
    const ChromeTitleBarStyle* chromeTitleBar(const std::wstring& id) const;
    const StatusChipStyle* statusChip(const std::wstring& id) const;
    const ProgressBarStyle* progressBar(const std::wstring& id) const;
    const ScrollBarStyle* scrollBar(const std::wstring& id) const;
    const ToggleSwitchStyle* toggleSwitch(const std::wstring& id) const;
    const SplitterStyle* splitter(const std::wstring& id) const;
    const CheckBoxStyle* checkBox(const std::wstring& id) const;
    const SelectBoxStyle* selectBox(const std::wstring& id) const;
    const ListBoxStyle* listBox(const std::wstring& id) const;
    const DateInputStyle* dateInput(const std::wstring& id) const;
    const TabStripStyle* tabStrip(const std::wstring& id) const;
    const MenuBarStyle* menuBar(const std::wstring& id) const;
    const TableListStyle* tableList(const std::wstring& id) const;
    const RichTextStyle* richText(const std::wstring& id) const;
    const TextInputStyle* textInput(const std::wstring& id) const;
    const SelectableTextStyle* selectableText(const std::wstring& id) const;
    const PopupStyle* popup(const std::wstring& id) const;
    const TooltipStyle* tooltip(const std::wstring& id) const;

    bool applyTo(Control& control) const;
    bool applyStyleId(Control& control, std::wstring styleId) const;
    int applyToTree(Control& control) const;

private:
    Theme theme_;
    std::unordered_map<std::wstring, TextStyle> textStyles_;
    std::unordered_map<std::wstring, ButtonStyle> buttonStyles_;
    std::unordered_map<std::wstring, BitmapButtonStyle> bitmapButtonStyles_;
    std::unordered_map<std::wstring, PanelStyle> panelStyles_;
    std::unordered_map<std::wstring, CardStyle> cardStyles_;
    std::unordered_map<std::wstring, ChromeTitleBarStyle> chromeTitleBarStyles_;
    std::unordered_map<std::wstring, StatusChipStyle> statusChipStyles_;
    std::unordered_map<std::wstring, ProgressBarStyle> progressBarStyles_;
    std::unordered_map<std::wstring, ScrollBarStyle> scrollBarStyles_;
    std::unordered_map<std::wstring, ToggleSwitchStyle> toggleSwitchStyles_;
    std::unordered_map<std::wstring, SplitterStyle> splitterStyles_;
    std::unordered_map<std::wstring, CheckBoxStyle> checkBoxStyles_;
    std::unordered_map<std::wstring, SelectBoxStyle> selectBoxStyles_;
    std::unordered_map<std::wstring, ListBoxStyle> listBoxStyles_;
    std::unordered_map<std::wstring, DateInputStyle> dateInputStyles_;
    std::unordered_map<std::wstring, TabStripStyle> tabStripStyles_;
    std::unordered_map<std::wstring, MenuBarStyle> menuBarStyles_;
    std::unordered_map<std::wstring, TableListStyle> tableListStyles_;
    std::unordered_map<std::wstring, RichTextStyle> richTextStyles_;
    std::unordered_map<std::wstring, TextInputStyle> textInputStyles_;
    std::unordered_map<std::wstring, SelectableTextStyle> selectableTextStyles_;
    std::unordered_map<std::wstring, PopupStyle> popupStyles_;
    std::unordered_map<std::wstring, TooltipStyle> tooltipStyles_;
};

class SkinCatalog {
public:
    WDUI_DEPRECATED("SkinCatalog::defaultSkins() is a compatibility hook and is intentionally empty; use SkinCatalog::availableSkins() instead.")
    static const std::vector<SkinPreset>& defaultSkins();
    static const std::vector<SkinPreset>& availableSkins();
    static std::vector<SkinPreset> loadExternalSkinsFromExeDirectory();
    static std::vector<SkinPreset> loadExternalSkinsFromDirectory(const std::wstring& directory);
    static void reloadAvailableSkins();
    static bool windowsAppsUseLightTheme();
    static std::wstring resolveSkinId(const std::wstring& id);
    WDUI_DEPRECATED("SkinCatalog::findDefaultSkin(...) only searches the empty compiled-default compatibility hook; use SkinCatalog::findSkin(...) instead.")
    static const SkinPreset* findDefaultSkin(const std::wstring& id);
    static const SkinPreset* findSkin(const std::wstring& id);
    WDUI_DEPRECATED("SkinCatalog::filterDefaultSkins(...) only searches the empty compiled-default compatibility hook; use SkinCatalog::filterSkins(...) instead.")
    static std::vector<SkinPreset> filterDefaultSkins(
        const std::vector<std::wstring>& requiredTags,
        const std::vector<std::wstring>& optionalTags = {});
    static std::vector<SkinPreset> filterSkins(
        const std::vector<std::wstring>& requiredTags,
        const std::vector<std::wstring>& optionalTags = {});
    static bool hasTag(const SkinPreset& skin, const std::wstring& tag);
};

class Control {
public:
    Control(std::wstring id, Rect bounds);
    virtual ~Control() = default;

    const std::wstring& id() const;
    Rect bounds() const;
    virtual void setBounds(Rect bounds);
    void setRuntimeBounds(Rect bounds);
    void setRuntimeBounds(Rect bounds, bool updateSurfaceRegion);
    void invalidateVisual(int padding = 8) const;
    bool visible() const;
    void setVisible(bool visible);
    bool collapsed() const;
    void setCollapsed(bool collapsed);
    bool enabled() const;
    void setEnabled(bool enabled);
    bool hot() const;
    bool pressed() const;
    const std::wstring& styleId() const;
    void setStyleId(std::wstring styleId);
    TextFormat textFormat() const;
    void setTextFormat(TextFormat format);
    const MarkdownTextStyle& markdownTextStyle() const;
    void setMarkdownTextStyle(MarkdownTextStyle style);
    void setCommandId(std::wstring commandId);
    const std::wstring& commandId() const;
    Connection addCommandListener(std::function<void(CommandEvent&)> callback);
    Connection addValueChangedListener(std::function<void(ValueChangedEvent&)> callback);
    Connection addSelectionChangedListener(std::function<void(SelectionChangedEvent&)> callback);
    Connection addActivationListener(std::function<void(ActivationEvent&)> callback);
    Connection addCommitListener(std::function<void(CommitEvent&)> callback);
    Connection addExpandedChangedListener(std::function<void(ExpandedChangedEvent&)> callback);
    Connection addSortChangedListener(std::function<void(SortChangedEvent&)> callback);
    Connection addColumnWidthsChangedListener(std::function<void(ColumnWidthsChangedEvent&)> callback);
    Connection addLinkActionListener(std::function<void(LinkActionEvent&)> callback);
    Connection addPopupEventListener(std::function<void(PopupEvent&)> callback);
    Connection addScrollListener(std::function<void(ScrollEvent&)> callback);
    Connection addDragDeltaListener(std::function<void(DragDeltaEvent&)> callback);
    virtual bool applyStyleFromCatalog(const StyleCatalog& catalog);
    virtual void onStyleCatalogApplied();
    virtual bool preserveContourFollowSize() const;
    virtual bool usesOwnBoundsForContourFollowRemap() const;
    virtual const std::wstring& tooltipText() const;
    virtual std::wstring autoTooltipText() const;
    const std::wstring& effectiveTooltipText() const;
    void setTooltipText(std::wstring text);
    WDUI_DEPRECATED("Control::setPaintOrder(...) is a compatibility alias; use Control::setZOrder(...) instead.")
    void setPaintOrder(int order);
    int paintOrder() const;
    void setZOrder(int order);
    int zOrder() const;
    bool hasTooltipContent() const;
    const std::vector<TooltipAction>& tooltipActions() const;
    void addTooltipAction(std::wstring id, std::wstring label, TooltipActionKind kind = TooltipActionKind::Link);
    void addTooltipLink(std::wstring id, std::wstring label);
    void addTooltipButton(std::wstring id, std::wstring label);
    void clearTooltipActions();
    Control& addTooltipControl(std::unique_ptr<Control> control);
    void clearTooltipControls();
    const std::vector<std::unique_ptr<Control>>& tooltipControls() const;
    Control& add(std::unique_ptr<Control> control);
    virtual const std::vector<std::unique_ptr<Control>>& children() const;
    const TooltipStyle* tooltipStyle() const;
    void setTooltipStyle(TooltipStyle style);
    void clearTooltipStyle();
    LayoutOptions layoutOptions() const;
    void setLayoutOptions(LayoutOptions options);
    void setAnchors(LayoutAnchors anchors);
    void setMinimumSize(int width, int height);
    void setRelativeLayout(RelativeLayoutOptions options);
    void clearRelativeLayout();
    bool hasRelativeLayout() const;
    const std::optional<RelativeLayoutOptions>& relativeLayoutOptions() const;
    virtual Size minimumSizeHint() const;
    Size minimumParentSizeHint() const;
    virtual Rect contentLayoutRect() const;
    virtual std::vector<Rect> contentLayoutRects() const;
    virtual Rect layoutRect(SurfaceRole role = SurfaceRole::ChildLayout, int requestedBandHeight = 14) const;
    virtual Rect layoutEnvelopeRect(SurfaceRole role = SurfaceRole::ChildLayout, int requestedBandHeight = 14) const;
    virtual std::vector<Rect> layoutRects(SurfaceRole role = SurfaceRole::ChildLayout, int requestedBandHeight = 14) const;
    virtual std::optional<SurfaceStyle> windowRegionSurfaceStyle() const;
    std::vector<Rect> scanlineLayoutRects(SurfaceRole role = SurfaceRole::ChildLayout) const;
    void setContourLayoutRects(std::vector<Rect> rects);
    void setContourLayoutRectsFromParent(const std::vector<Rect>& parentRects, Rect childBounds);
    void setContourLayoutRectsFromParent(const std::vector<Rect>& parentRects, Rect childBounds, Rect parentContentRect);
    void clearContourLayoutRects();
    bool hasContourLayoutRects() const;
    const std::vector<Rect>& contourLayoutRects() const;
    void setContourMode(ContourMode mode);
    ContourMode contourMode() const;
    void setContourFollowMapping(ContourFollowMapping mapping);
    ContourFollowMapping contourFollowMapping() const;
    Point contourFollowOffset() const;
    Rect contourFollowBounds() const;
    WDUI_DEPRECATED("Control::setUseContourLanesForContent(...) is a legacy contour alias; use setContourMode(ContourMode::FollowParentEdge) or setContourMode(ContourMode::DeformToParent) instead.")
    void setUseContourLanesForContent(bool enabled);
    WDUI_DEPRECATED("Control::useContourLanesForContent() is a legacy contour alias; use contourMode() == ContourMode::FollowParentEdge instead.")
    bool useContourLanesForContent() const;
    Rect edgeLayoutRect(EdgeAnchor edge, int thickness, int margin = 0) const;
    Rect edgeLayoutRectForRange(EdgeAnchor edge, int start, int length, int thickness, int margin = 0) const;
    std::vector<Rect> edgeLayoutRects(EdgeAnchor edge, int thickness, int margin = 0) const;
    std::vector<Rect> edgeLayoutRectsForRange(EdgeAnchor edge, int start, int length, int thickness, int margin = 0) const;
    Rect edgeScanlineLayoutRect(EdgeAnchor edge, int thickness, int margin = 0, SurfaceRole role = SurfaceRole::ScrollTrack) const;
    Rect edgeScanlineLayoutRectForRange(EdgeAnchor edge, int start, int length, int thickness, int margin = 0, SurfaceRole role = SurfaceRole::ScrollTrack) const;
    std::vector<Rect> edgeScanlineLayoutRects(EdgeAnchor edge, int thickness, int margin = 0, SurfaceRole role = SurfaceRole::ScrollTrack) const;
    std::vector<Rect> edgeScanlineLayoutRectsForRange(EdgeAnchor edge, int start, int length, int thickness, int margin = 0, SurfaceRole role = SurfaceRole::ScrollTrack) const;
    Control* parent() const;
    Window* owningWindow() const;
    void notifyOwningWindowGeometryChanged();
    void setLocalizationHandler(std::function<void(Control&)> callback);
    void clearLocalizationHandler();
    bool hasLocalizationHandler() const;
    void resetLayoutReference();
    void captureLayoutReference(Size parentSize);
    void captureLayoutReference(Rect parentArea);
    void applyParentLayout(Size parentSize);
    void applyParentLayout(Rect parentArea);
    virtual void captureState(ControlState& state) const;
    virtual void applyState(const ControlState& state, bool restoreGeometry = false);
    virtual void retranslate();

    virtual void paint(HDC hdc, Point origin);
    virtual void paintOverlay(HDC hdc, Point origin);
    virtual Control* hitTestTransientTree(Point point, Point origin);
    virtual Control* hitTestTree(Point point, Point origin);
    virtual bool dismissTransientUi(Point point, Point origin);
    virtual void setHot(bool hot);
    virtual void setPressed(bool pressed);
    virtual void mouseDown();
    virtual void mouseMove();
    void dispatchCapturedMouseMove(Point localPoint);
    virtual void click();
    virtual bool mouseWheel(int delta);
    virtual bool mouseHorizontalWheel(int delta);
    virtual bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner);
    virtual bool textInput(wchar_t ch, HWND owner);
    virtual bool wantsAnimationTick() const;

protected:
    void layoutChildren();
    Size hostedContentSizeHint() const;
    const std::vector<Control*>& orderedVisibleHostedChildren() const;
    void paintHostedChildren(HDC hdc, Point origin);
    void paintHostedChildrenOverlay(HDC hdc, Point origin);
    Control* hitTestHostedTransientTree(Point point, Point origin);
    Control* hitTestHostedTree(Point point, Point origin);
    bool dismissHostedTransientUi(Point point, Point origin);
    bool contourContains(Point localPoint) const;
    Rect contourLaneRectForContent(Rect preferredRect, SurfaceRole role = SurfaceRole::Text) const;
    Point lastLocalPoint() const;
    void setLastLocalPoint(Point point);
    virtual bool hitTestLocal(Point localPoint) const;
    virtual void onBoundsChanged();
    virtual void onOwningWindowChanged();
    virtual void onOwningWindowGeometryChanged();
    virtual void onTextFormatChanged();
    virtual void captureStateValues(ControlState& state) const;
    virtual void applyStateValue(const StateValue& value);
    virtual void invalidateChildTraversalCache() const;
    CommandEvent makeCommandEvent(std::wstring text = {});
    void emitCommand(CommandEvent& event);
    ValueChangedEvent makeValueChangedEvent(std::wstring value = {}, std::wstring previousValue = {});
    void emitValueChanged(ValueChangedEvent& event);
    void emitSelectionChanged(SelectionChangedEvent& event);
    void emitActivation(ActivationEvent& event);
    void emitCommit(CommitEvent& event);
    void emitExpandedChanged(ExpandedChangedEvent& event);
    void emitSortChanged(SortChangedEvent& event);
    void emitColumnWidthsChanged(ColumnWidthsChangedEvent& event);
    void emitLinkAction(LinkActionEvent& event);
    void emitPopupEvent(PopupEvent& event);
    void emitScroll(ScrollEvent& event);
    void emitDragDelta(DragDeltaEvent& event);

private:
    struct ContourContentLane {
        int start = 0;
        int length = 0;
        int leadingOffset = 0;
        int trailingOffset = 0;
    };

    void assignOwningWindow(Window* window);
    void assignParent(Control* parent);

    friend class Panel;
    friend class Window;

    std::wstring id_;
    Rect bounds_;
    Rect layoutReferenceBounds_;
    Size layoutReferenceParent_;
    LayoutOptions layout_;
    std::optional<RelativeLayoutOptions> relativeLayout_;
    bool layoutReferenceCaptured_ = false;
    bool visible_ = true;
    bool collapsed_ = false;
    bool enabled_ = true;
    bool hot_ = false;
    bool pressed_ = false;
    Point lastLocalPoint_;
    std::wstring styleId_;
    TextFormat textFormat_ = TextFormat::Plain;
    MarkdownTextStyle markdownTextStyle_;
    std::wstring commandId_;
    std::wstring tooltipText_;
    int paintOrder_ = 0;
    mutable std::wstring effectiveTooltipText_;
    std::vector<TooltipAction> tooltipActions_;
    std::vector<std::unique_ptr<Control>> tooltipControls_;
    std::vector<std::unique_ptr<Control>> children_;
    mutable bool hostedChildOrderDirty_ = true;
    mutable std::vector<Control*> hostedChildOrderCache_;
    std::optional<TooltipStyle> tooltipStyle_;
    std::function<void(Control&)> localizationHandler_;
    Signal<CommandEvent&> commandSignal_;
    Signal<ValueChangedEvent&> valueChangedSignal_;
    Signal<SelectionChangedEvent&> selectionChangedSignal_;
    Signal<ActivationEvent&> activationSignal_;
    Signal<CommitEvent&> commitSignal_;
    Signal<ExpandedChangedEvent&> expandedChangedSignal_;
    Signal<SortChangedEvent&> sortChangedSignal_;
    Signal<ColumnWidthsChangedEvent&> columnWidthsChangedSignal_;
    Signal<LinkActionEvent&> linkActionSignal_;
    Signal<PopupEvent&> popupEventSignal_;
    Signal<ScrollEvent&> scrollSignal_;
    Signal<DragDeltaEvent&> dragDeltaSignal_;
    std::vector<Rect> contourLayoutRects_;
    std::vector<ContourContentLane> contourContentRowLanes_;
    std::vector<ContourContentLane> contourContentColumnLanes_;
    bool contourContentUseBottomAnchor_ = false;
    bool contourContentUseRightAnchor_ = false;
    ContourMode contourMode_ = ContourMode::FollowParentEdge;
    ContourFollowMapping contourFollowMapping_ = ContourFollowMapping::Band;
    Point contourFollowOffset_;
    Rect contourFollowBounds_;
    Control* parent_ = nullptr;
    Window* owningWindow_ = nullptr;
};

class Panel : public Control {
public:
    explicit Panel(std::wstring id = L"root", Rect bounds = {});

    Control& add(std::unique_ptr<Control> control);
    void setBounds(Rect bounds) override;
    void paint(HDC hdc, Point origin) override;
    void paintOverlay(HDC hdc, Point origin) override;
    Control* hitTestTransientTree(Point point, Point origin) override;
    Control* hitTestTree(Point point, Point origin) override;
    bool dismissTransientUi(Point point, Point origin) override;
    bool wantsAnimationTick() const override;
    Control* findById(const std::wstring& id);
    const Control* findById(const std::wstring& id) const;
    void retranslate() override;
    void captureStateTree(std::vector<ControlState>& states) const;
    void applyStateTree(const std::vector<ControlState>& states, bool restoreGeometry = false);
    Size minimumContentSizeHint() const;
    Size minimumSizeHint() const override;
    const std::vector<std::unique_ptr<Control>>& children() const override;
    bool usesOwnBoundsForContourFollowRemap() const override;

protected:
    void onBoundsChanged() override;
    void onOwningWindowChanged() override;
    void onOwningWindowGeometryChanged() override;
    void layoutChildren();
    void invalidateChildTraversalCache() const override;

private:
    const std::vector<Control*>& orderedVisiblePanelChildren() const;

    std::vector<std::unique_ptr<Control>> children_;
    mutable bool childOrderDirty_ = true;
    mutable std::vector<Control*> childOrderCache_;
};

class ThemedPanel : public Panel {
public:
    ThemedPanel(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setTheme(Theme theme);
    void setStyle(PanelStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setPaintSurface(bool paintSurface);
    bool paintSurface() const;
    void setFill(COLORREF fill);
    void setBorder(COLORREF border);
    void setPadding(int padding);
    Rect contentLayoutRect() const override;
    std::vector<Rect> contentLayoutRects() const override;
    Rect layoutRect(SurfaceRole role = SurfaceRole::ChildLayout, int requestedBandHeight = 14) const override;
    std::vector<Rect> layoutRects(SurfaceRole role = SurfaceRole::ChildLayout, int requestedBandHeight = 14) const override;
    std::optional<SurfaceStyle> windowRegionSurfaceStyle() const override;
    void paint(HDC hdc, Point origin) override;

protected:
    bool hitTestLocal(Point localPoint) const override;

private:
    PanelStyle style_;
    bool paintSurface_ = true;
};

class Card : public Panel {
public:
    Card(std::wstring id, Rect bounds, std::wstring title, Theme theme = Theme::taskBoardFamily());

    void setStyle(CardStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setTitle(std::wstring title);
    void setSubtitle(std::wstring subtitle);
    WDUI_DEPRECATED("Do not use Card::setOnHeaderDrag; use Control::addCommandListener(...) and handle the header-drag CommandEvent instead.")
    void setOnHeaderDrag(std::function<void()> callback);
    std::wstring autoTooltipText() const override;
    Rect contentLayoutRect() const override;
    std::vector<Rect> contentLayoutRects() const override;
    Rect layoutRect(SurfaceRole role = SurfaceRole::ChildLayout, int requestedBandHeight = 14) const override;
    std::vector<Rect> layoutRects(SurfaceRole role = SurfaceRole::ChildLayout, int requestedBandHeight = 14) const override;
    std::optional<SurfaceStyle> windowRegionSurfaceStyle() const override;
    Rect bodyLayoutRect() const;
    std::vector<Rect> bodyLayoutRects() const;
    Rect bodyLayoutEnvelopeRect() const;
    void paint(HDC hdc, Point origin) override;
    void mouseDown() override;

protected:
    bool hitTestLocal(Point localPoint) const override;

private:
    bool headerContains(Point localPoint) const;
    int bodyTop() const;
    Rect titleTextRect() const;
    Rect subtitleTextRect() const;
    CardStyle style_;
    std::wstring title_;
    std::wstring subtitle_;
    std::function<void()> onHeaderDrag_;
};

class Label : public Control {
public:
    Label(std::wstring id, Rect bounds, std::wstring text, Theme theme = Theme::taskBoardFamily());

    void setText(std::wstring text);
    void setTextStyle(TextStyle style);
    void setAlignment(TextAlignment alignment);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    bool preserveContourFollowSize() const override;
    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;

protected:
    bool hitTestLocal(Point localPoint) const override;

private:
    Rect textLayoutRect() const;
    TextStyle displayTextStyle() const;
    std::wstring displayText() const;

    Theme theme_;
    std::wstring text_;
    TextStyle style_;
    TextAlignment alignment_ = TextAlignment::Left;
};

class ShimmerText : public Control {
public:
    ShimmerText(std::wstring id, Rect bounds, std::wstring text, Theme theme = Theme::taskBoardFamily());

    void setText(std::wstring text);
    void setTextStyle(TextStyle style);
    void setHighlightColor(COLORREF color);
    void setAlignment(TextAlignment alignment);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    bool preserveContourFollowSize() const override;
    std::wstring autoTooltipText() const override;
    bool wantsAnimationTick() const override;
    void paint(HDC hdc, Point origin) override;

protected:
    bool hitTestLocal(Point localPoint) const override;

private:
    Rect textLayoutRect() const;
    TextStyle displayTextStyle() const;
    std::wstring displayText() const;

    Theme theme_;
    std::wstring text_;
    TextStyle style_;
    COLORREF highlightColor_;
    TextAlignment alignment_ = TextAlignment::Left;
};

class ThemedButton : public Control {
public:
    ThemedButton(std::wstring id, Rect bounds, std::wstring text, Theme theme = Theme::taskBoardFamily());

    void setText(std::wstring text);
    void setTheme(Theme theme);
    void setStyle(ButtonStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setShape(ButtonShape shape);
    void setActive(bool active);
    void setAlignment(TextAlignment alignment);
    WDUI_DEPRECATED("Do not use ThemedButton::setOnClick; use Control::addCommandListener(...) instead.")
    void setOnClick(std::function<void()> callback);
    std::wstring autoTooltipText() const override;
    std::optional<SurfaceStyle> windowRegionSurfaceStyle() const override;
    Size minimumSizeHint() const override;
    void paint(HDC hdc, Point origin) override;
    void click() override;

protected:
    bool hitTestLocal(Point localPoint) const override;

private:
    bool textLikelyTruncated() const;
    ButtonStyle style_;
    std::wstring text_;
    TextAlignment alignment_ = TextAlignment::Center;
    bool active_ = false;
    std::function<void()> onClick_;
};

class ChromeTitleBar : public Panel {
public:
    ChromeTitleBar(std::wstring id, Rect bounds, std::wstring title, Theme theme = Theme::taskBoardFamily());

    void setStyle(ChromeTitleBarStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setTitle(std::wstring title);
    void setIcon(Image icon);
    void setShowMinimizeButton(bool show);
    void setShowMaximizeButton(bool show);
    void setAllowMaximize(bool allow);
    void setMinimizeTooltipText(std::wstring text);
    void setMaximizeTooltipText(std::wstring text);
    void setCloseTooltipText(std::wstring text);
    void setMinimizeGlyphImages(Image normal, Image hot = {}, Image pressed = {}, Image disabled = {});
    void setMaximizeGlyphImages(Image normal, Image hot = {}, Image pressed = {}, Image disabled = {});
    void setRestoreGlyphImages(Image normal, Image hot = {}, Image pressed = {}, Image disabled = {});
    void setResetGlyphImages(Image normal, Image hot = {}, Image pressed = {}, Image disabled = {});
    void setCloseGlyphImages(Image normal, Image hot = {}, Image pressed = {}, Image disabled = {});
    WDUI_DEPRECATED("Do not use ChromeTitleBar::setOnMinimize; use Control::addCommandListener(...) and handle the minimize CommandEvent instead.")
    void setOnMinimize(std::function<void()> callback);
    WDUI_DEPRECATED("Do not use ChromeTitleBar::setOnMaximize; use Control::addCommandListener(...) and handle the maximize/restore CommandEvent instead.")
    void setOnMaximize(std::function<void()> callback);
    WDUI_DEPRECATED("Do not use ChromeTitleBar::setOnReset; use Control::addCommandListener(...) and handle the reset-size CommandEvent instead.")
    void setOnReset(std::function<void()> callback);
    WDUI_DEPRECATED("Do not use ChromeTitleBar::setOnClose; use Control::addCommandListener(...) and handle the close CommandEvent instead.")
    void setOnClose(std::function<void()> callback);
    WDUI_DEPRECATED("Do not use ChromeTitleBar::setOnDrag; use Control::addCommandListener(...) and handle the drag CommandEvent instead.")
    void setOnDrag(std::function<void()> callback);
    void setMaximized(bool maximized);
    void setShowResetButton(bool show);
    void setResetTooltipText(std::wstring text);
    void setHeaderActionButtonCount(int count);
    int headerActionButtonCount() const;
    void setShowHeaderActionButton(bool show);
    void setHeaderActionEnabled(bool enabled);
    void setHeaderActionEnabled(int index, bool enabled);
    void setHeaderActionTooltipText(std::wstring text);
    void setHeaderActionTooltipText(int index, std::wstring text);
    void setHeaderActionGlyphImages(Image normal, Image hot = {}, Image pressed = {}, Image disabled = {});
    void setHeaderActionGlyphImages(int index, Image normal, Image hot = {}, Image pressed = {}, Image disabled = {});
    void setHeaderActionPulseActive(bool active);
    void setHeaderActionPulseActive(int index, bool active);
    bool headerActionPulseActive(int index) const;
    WDUI_DEPRECATED("Do not use ChromeTitleBar::setOnHeaderAction; use Control::addCommandListener(...) and handle header-action-* CommandEvents instead.")
    void setOnHeaderAction(std::function<void()> callback);
    WDUI_DEPRECATED("Do not use ChromeTitleBar::setOnHeaderAction; use Control::addCommandListener(...) and handle header-action-* CommandEvents instead.")
    void setOnHeaderAction(int index, std::function<void()> callback);
    ThemedButton* headerActionButton();
    const ThemedButton* headerActionButton() const;
    ThemedButton* headerActionButton(int index);
    const ThemedButton* headerActionButton(int index) const;
    const std::wstring& tooltipText() const override;
    std::wstring autoTooltipText() const override;
    bool wantsAnimationTick() const override;
    Rect contentLayoutRect() const override;
    std::vector<Rect> contentLayoutRects() const override;
    Rect layoutRect(SurfaceRole role = SurfaceRole::ChildLayout, int requestedBandHeight = 14) const override;
    std::vector<Rect> layoutRects(SurfaceRole role = SurfaceRole::ChildLayout, int requestedBandHeight = 14) const override;
    std::optional<SurfaceStyle> windowRegionSurfaceStyle() const override;
    void paint(HDC hdc, Point origin) override;
    void mouseDown() override;
    void click() override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void onBoundsChanged() override;

private:
    enum class HitPart {
        None,
        Drag,
        HeaderAction0,
        HeaderAction1,
        HeaderAction2,
        HeaderAction3,
        Minimize,
        Maximize,
        Reset,
        Close
    };

    HitPart hitPart(Point localPoint) const;
    Rect safeContentRectForVerticalRange(int y, int height) const;
    Rect iconRect() const;
    Rect titleTextRect() const;
    Rect buttonRectFromRight(int slot) const;
    int visibleButtonCount() const;
    struct GlyphImages {
        Image normal;
        Image hot;
        Image pressed;
        Image disabled;
        bool custom = false;
    };

    void syncButtonLayout();
    void syncButtonVisualState() const;
    void syncButtonLabels();
    void syncButtonStyle();
    void syncButtonGlyphs();
    void setGlyphImages(GlyphImages& target, Image normal, Image hot, Image pressed, Image disabled);
    const ThemedButton* buttonForPart(HitPart part) const;
    ThemedButton* buttonForPart(HitPart part);
    const GlyphImages& glyphsForPart(HitPart part) const;
    HitPart headerActionPartForIndex(int index) const;
    int headerActionIndexForPart(HitPart part) const;
    const ThemedButton* headerActionButtonUnchecked(int index) const;
    ThemedButton* headerActionButtonUnchecked(int index);
    const Image& glyphImageForState(const GlyphImages& glyphs, const ThemedButton& button) const;
    void paintButtonGlyph(HDC hdc, Point origin, HitPart part) const;

    static constexpr int kMaxHeaderActionButtons = 4;

    ChromeTitleBarStyle style_;
    std::wstring title_;
    Image icon_;
    mutable ThemedButton minimizeButton_;
    mutable ThemedButton maximizeButton_;
    mutable ThemedButton resetButton_;
    mutable ThemedButton closeButton_;
    std::array<std::unique_ptr<ThemedButton>, kMaxHeaderActionButtons> headerActionButtons_;
    ScopedConnection minimizeButtonCommandConnection_;
    ScopedConnection maximizeButtonCommandConnection_;
    ScopedConnection resetButtonCommandConnection_;
    ScopedConnection closeButtonCommandConnection_;
    std::array<ScopedConnection, kMaxHeaderActionButtons> headerActionCommandConnections_{};
    GlyphImages minimizeGlyphs_;
    GlyphImages maximizeGlyphs_;
    GlyphImages restoreGlyphs_;
    GlyphImages resetGlyphs_;
    GlyphImages closeGlyphs_;
    std::array<GlyphImages, kMaxHeaderActionButtons> headerActionGlyphs_{};
    std::array<bool, kMaxHeaderActionButtons> headerActionPulseActive_{};
    bool showMinimizeButton_ = true;
    bool showMaximizeButton_ = true;
    bool showResetButton_ = false;
    int headerActionButtonCount_ = 0;
    bool allowMaximize_ = true;
    bool maximized_ = false;
    std::function<void()> onMinimize_;
    std::function<void()> onMaximize_;
    std::function<void()> onReset_;
    std::function<void()> onClose_;
    std::function<void()> onDrag_;
    std::array<std::function<void()>, kMaxHeaderActionButtons> onHeaderActions_{};
};

class StatusChip : public Control {
public:
    StatusChip(std::wstring id, Rect bounds, std::wstring text, Theme theme = Theme::taskBoardFamily());

    void setStyle(StatusChipStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setText(std::wstring text);
    void setBadgeColor(COLORREF color);
    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;

protected:
    bool hitTestLocal(Point localPoint) const override;

private:
    StatusChipStyle style_;
    std::wstring text_;
};

class ProgressBar : public Control {
public:
    ProgressBar(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setStyle(ProgressBarStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setValue(int percent);
    int value() const;
    void setLabelVisible(bool visible);
    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;

protected:
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;
    bool hitTestLocal(Point localPoint) const override;

private:
    ProgressBarStyle style_;
    int percent_ = 0;
    bool labelVisible_ = true;
};

class ScrollBar : public Control {
public:
    ScrollBar(std::wstring id, Rect bounds, Orientation orientation = Orientation::Vertical, Theme theme = Theme::taskBoardFamily());

    void setStyle(ScrollBarStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setOrientation(Orientation orientation);
    void setRange(int minimum, int maximum, int pageSize, int value);
    void setValue(int value);
    int value() const;
    int minimum() const;
    int maximum() const;
    int pageSize() const;
    void setSteps(int smallStep, int largeStep, int wheelStep = 0);
    WDUI_DEPRECATED("Do not use ScrollBar::setOnValueChanged; use Control::addValueChangedListener(...) instead.")
    void setOnValueChanged(std::function<void(int)> callback);
    void setEdgeLayoutRects(EdgeAnchor edge, std::vector<Rect> lanes);
    void clearEdgeLayoutRects();
    void paint(HDC hdc, Point origin) override;
    void mouseDown() override;
    void mouseMove() override;
    void setPressed(bool pressed) override;
    bool mouseWheel(int delta) override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

private:
    enum class HitPart {
        None,
        DecrementButton,
        IncrementButton,
        TrackBeforeThumb,
        TrackAfterThumb,
        Thumb
    };

    Rect localBounds() const;
    Rect decrementRect() const;
    Rect incrementRect() const;
    Rect trackRect() const;
    Rect thumbRect() const;
    bool usesEdgeLayout() const;
    Rect edgeLayoutEnvelope() const;
    std::vector<Rect> edgeLayoutRectsForAxisRange(int start, int length) const;
    std::vector<Rect> visualEdgeLayoutRectsForAxisRange(int start, int length, int thickness) const;
    HitPart partAt(Point localPoint) const;
    int axisPosition(Point localPoint) const;
    int valueFromThumbPosition(int thumbStart) const;
    int clampValue(int value) const;
    bool setValueInternal(int value, bool notify);
    bool scrollBy(int delta, bool notify);

    ScrollBarStyle style_;
    Orientation orientation_ = Orientation::Vertical;
    int minimum_ = 0;
    int maximum_ = 0;
    int pageSize_ = 1;
    int value_ = 0;
    int smallStep_ = 1;
    int largeStep_ = 8;
    int wheelStep_ = 3;
    double wheelScrollRemainder_ = 0.0;
    ULONGLONG wheelScrollLastMilliseconds_ = 0;
    bool draggingThumb_ = false;
    int dragThumbOffset_ = 0;
    HitPart activePart_ = HitPart::None;
    EdgeAnchor edgeLayoutAnchor_ = EdgeAnchor::Right;
    std::function<void(int)> onValueChanged_;
};

class ToggleSwitch : public Control {
public:
    ToggleSwitch(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setStyle(ToggleSwitchStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    bool checked() const;
    void setChecked(bool checked);
    WDUI_DEPRECATED("Do not use ToggleSwitch::setOnChanged; use Control::addValueChangedListener(...) instead.")
    void setOnChanged(std::function<void(bool)> callback);
    void paint(HDC hdc, Point origin) override;
    void click() override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;

protected:
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;
    bool hitTestLocal(Point localPoint) const override;

private:
    Rect trackRectLocal() const;

    ToggleSwitchStyle style_;
    bool checked_ = false;
    std::function<void(bool)> onChanged_;
};

class Splitter : public Control {
public:
    Splitter(
        std::wstring id,
        Rect bounds,
        SplitterOrientation orientation = SplitterOrientation::Vertical,
        Theme theme = Theme::taskBoardFamily());

    void setStyle(SplitterStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setOrientation(SplitterOrientation orientation);
    SplitterOrientation orientation() const;
    WDUI_DEPRECATED("Do not use Splitter::setOnDragDelta; use Control::addDragDeltaListener(...) instead.")
    void setOnDragDelta(std::function<void(int dx, int dy)> callback);
    void paint(HDC hdc, Point origin) override;
    void mouseDown() override;
    void mouseMove() override;
    void setPressed(bool pressed) override;

protected:
    bool hitTestLocal(Point localPoint) const override;

private:
    SplitterStyle style_;
    SplitterOrientation orientation_ = SplitterOrientation::Vertical;
    Point dragAnchor_{};
    std::function<void(int dx, int dy)> onDragDelta_;

    Rect localBounds() const;
    Rect trackRect() const;
    Rect gripRect() const;
    bool allowsHorizontalDrag() const;
    bool allowsVerticalDrag() const;
    void updateCursor() const;
};

class CheckBox : public Control {
public:
    CheckBox(std::wstring id, Rect bounds, std::wstring text, Theme theme = Theme::taskBoardFamily());

    void setStyle(CheckBoxStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    bool checked() const;
    void setChecked(bool checked);
    void setText(std::wstring text);
    WDUI_DEPRECATED("Do not use CheckBox::setOnChanged; use Control::addValueChangedListener(...) instead.")
    void setOnChanged(std::function<void(bool)> callback);
    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;
    void click() override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;

protected:
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

private:
    CheckBoxStyle style_;
    std::wstring text_;
    bool checked_ = false;
    std::function<void(bool)> onChanged_;
};

class SelectBox : public Control {
public:
    SelectBox(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());
    ~SelectBox() override;

    void setStyle(SelectBoxStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setItems(std::vector<std::wstring> items);
    void setItems(std::vector<SelectBoxItem> items);
    void setHierarchicalItems(std::vector<HierarchicalListBoxItem> items);
    const std::vector<HierarchicalListBoxItem>& hierarchicalItems() const;
    void setDropdownMode(SelectBoxDropdownMode mode);
    SelectBoxDropdownMode dropdownMode() const;
    void setDropdownListStyle(ListBoxStyle style);
    const ListBoxStyle& dropdownListStyle() const;
    void setMaxVisibleItems(int count);
    int maxVisibleItems() const;
    bool dropdownOpen() const;
    HWND dropdownPopupHwndForDiagnostics() const;
    bool dropdownPopupVisibleForDiagnostics() const;
    Rect dropdownPopupScreenRectForDiagnostics() const;
    int selectedIndex() const;
    void setSelectedIndex(int index);
    std::vector<int> selectedPath() const;
    void setSelectedPath(std::vector<int> path);
    std::wstring selectedText() const;
    std::wstring selectedValue() const;
    WDUI_DEPRECATED("Do not use SelectBox::setOnChanged; use Control::addSelectionChangedListener(...) instead.")
    void setOnChanged(std::function<void(int, const std::wstring&)> callback);
    WDUI_DEPRECATED("Do not use SelectBox::setOnHierarchicalChanged; use Control::addSelectionChangedListener(...) instead.")
    void setOnHierarchicalChanged(std::function<void(const std::vector<int>&, const HierarchicalListBoxItem&)> callback);
    void paint(HDC hdc, Point origin) override;
    void paintOverlay(HDC hdc, Point origin) override;
    std::wstring autoTooltipText() const override;
    Size minimumSizeHint() const override;
    Control* hitTestTransientTree(Point point, Point origin) override;
    Control* hitTestTree(Point point, Point origin) override;
    bool dismissTransientUi(Point point, Point origin) override;
    void mouseDown() override;
    void click() override;
    bool mouseWheel(int delta) override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void onBoundsChanged() override;
    void onOwningWindowChanged() override;
    void onOwningWindowGeometryChanged() override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

private:
    friend struct SelectBoxTransientState;

    SelectBoxStyle style_;
    ListBoxStyle dropdownListStyle_;
    std::vector<SelectBoxItem> items_;
    std::vector<HierarchicalListBoxItem> hierarchicalItems_;
    int selectedIndex_ = -1;
    std::vector<int> selectedPath_;
    SelectBoxDropdownMode dropdownMode_ = SelectBoxDropdownMode::List;
    bool dropdownOpen_ = false;
    int dropdownScroll_ = 0;
    std::function<void(int, const std::wstring&)> onChanged_;
    std::function<void(const std::vector<int>&, const HierarchicalListBoxItem&)> onHierarchicalChanged_;
    std::unique_ptr<SelectBoxTransientState> transientState_;

    bool usingHierarchicalDropdown() const;
    bool hasSelectableItems() const;
    Rect localMainRect() const;
    Rect localDropdownRect() const;
    Rect dropdownSpanForVerticalRange(int y, int height) const;
    Rect dropdownItemRowRectForVisibleIndex(int visibleIndex) const;
    int visibleOptionCount() const;
    std::wstring itemText(int index) const;
    std::wstring itemTooltip(int index) const;
    int optionIndexAt(Point localPoint) const;
    int dropdownTextAvailableWidth() const;
    bool dropdownItemTextOverflows(int itemIndex, int availableWidth) const;
    int itemRecommendationStars(int index) const;
    const HierarchicalListBoxItem* hierarchicalItemAtPath(const std::vector<int>& path) const;
    HierarchicalListBoxItem* hierarchicalItemAtPath(const std::vector<int>& path);
    std::vector<int> firstEnabledHierarchicalPath() const;
    int hierarchicalIndexForPath(const std::vector<int>& path) const;
    std::vector<int> hierarchicalPathForIndex(int index) const;
    int hierarchicalVisibleItemCount() const;
    void appendHierarchicalAllPaths(
        const std::vector<HierarchicalListBoxItem>& items,
        std::vector<int>& path,
        std::vector<std::vector<int>>& paths,
        bool enabledOnly) const;
    void appendHierarchicalVisiblePaths(
        const std::vector<HierarchicalListBoxItem>& items,
        std::vector<int>& path,
        std::vector<std::vector<int>>& paths,
        bool enabledOnly) const;
    bool expandHierarchicalPathAncestors(const std::vector<int>& path);
    void selectHierarchicalPath(std::vector<int> path, bool notify);
    bool setHierarchicalExpanded(std::vector<int> path, bool expanded);
    bool moveHierarchicalSelection(int delta);
    ListBoxStyle effectiveDropdownListStyle() const;
    void openDropdown();
    void closeDropdown();
    void selectIndex(int index, bool notify);
};

class ListBox : public Control {
public:
    ListBox(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setStyle(ListBoxStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setItems(std::vector<std::wstring> items);
    void setItems(std::vector<ListBoxItem> items);
    const std::vector<ListBoxItem>& items() const;
    int selectedIndex() const;
    void setSelectedIndex(int index);
    std::wstring selectedText() const;
    std::wstring selectedValue() const;
    int scrollOffset() const;
    void setScrollOffset(int offset);
    int maxScrollOffset() const;
    int visibleRowCapacity() const;
    WDUI_DEPRECATED("Do not use ListBox::setOnSelectionChanged; use Control::addSelectionChangedListener(...) instead.")
    void setOnSelectionChanged(std::function<void(int, const ListBoxItem&)> callback);
    WDUI_DEPRECATED("Do not use ListBox::setOnActivated; use Control::addActivationListener(...) instead.")
    void setOnActivated(std::function<void(int, const ListBoxItem&)> callback);
    void paint(HDC hdc, Point origin) override;
    std::wstring autoTooltipText() const override;
    void mouseDown() override;
    void mouseMove() override;
    void setPressed(bool pressed) override;
    void click() override;
    bool mouseWheel(int delta) override;
    bool mouseHorizontalWheel(int delta) override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

private:
    enum class ScrollHitPart {
        None,
        TrackBeforeThumb,
        TrackAfterThumb,
        Thumb,
    };

    ListBoxStyle style_;
    std::vector<ListBoxItem> items_;
    int selectedIndex_ = -1;
    int scrollOffset_ = 0;
    double wheelScrollRemainder_ = 0.0;
    ULONGLONG wheelScrollLastMilliseconds_ = 0;
    ScrollHitPart activeScrollPart_ = ScrollHitPart::None;
    int dragThumbOffset_ = 0;
    bool draggingThumb_ = false;
    bool suppressNextClick_ = false;
    ULONGLONG lastActivationClickMilliseconds_ = 0;
    int lastActivationClickIndex_ = -1;
    std::function<void(int, const ListBoxItem&)> onSelectionChanged_;
    std::function<void(int, const ListBoxItem&)> onActivated_;

    Rect surfaceSpanForVerticalRange(int y, int height) const;
    Rect listViewportRect() const;
    Rect scrollBarRect() const;
    Rect scrollTrackRect() const;
    Rect scrollThumbRect() const;
    bool needsScrollBar() const;
    int rowIndexAt(Point localPoint) const;
    Rect rowRectForVisibleIndex(int visibleIndex) const;
    Rect rowTextRect(Rect rowRect, bool selected, bool hot) const;
    int scrollValueFromThumbPosition(int thumbTop) const;
    ScrollHitPart scrollPartAt(Point localPoint) const;
    bool setScrollOffsetInternal(int offset, bool invalidate);
    void ensureSelectedVisible();
    void selectIndex(int index, bool notify);
    void activateIndex(int index);
    bool scrollByRows(int rows);
    int listViewportPixelHeight() const;
    int firstVisibleItemIndex() const;
};

class HierarchicalListBox : public Control {
public:
    HierarchicalListBox(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setStyle(ListBoxStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setItems(std::vector<HierarchicalListBoxItem> items);
    const std::vector<HierarchicalListBoxItem>& items() const;
    std::vector<int> selectedPath() const;
    void setSelectedPath(std::vector<int> path);
    const HierarchicalListBoxItem* selectedItem() const;
    std::wstring selectedText() const;
    std::wstring selectedValue() const;
    std::vector<int> pathAtLocalPoint(Point localPoint) const;
    const HierarchicalListBoxItem* itemAtLocalPoint(Point localPoint) const;
    int scrollOffset() const;
    void setScrollOffset(int offset);
    int maxScrollOffset() const;
    int visibleRowCapacity() const;
    void setExpanded(std::vector<int> path, bool expanded);
    bool expanded(const std::vector<int>& path) const;
    void toggleExpanded(const std::vector<int>& path);
    void expandAll();
    void collapseAll();
    void setItemTooltipsEnabled(bool enabled);
    bool itemTooltipsEnabled() const;
    WDUI_DEPRECATED("Do not use HierarchicalListBox::setOnSelectionChanged; use Control::addSelectionChangedListener(...) instead.")
    void setOnSelectionChanged(std::function<void(const std::vector<int>&, const HierarchicalListBoxItem&)> callback);
    WDUI_DEPRECATED("Do not use HierarchicalListBox::setOnActivated; use Control::addActivationListener(...) instead.")
    void setOnActivated(std::function<void(const std::vector<int>&, const HierarchicalListBoxItem&)> callback);
    WDUI_DEPRECATED("Do not use HierarchicalListBox::setOnExpandedChanged; use Control::addExpandedChangedListener(...) instead.")
    void setOnExpandedChanged(std::function<void(const std::vector<int>&, bool)> callback);
    void paint(HDC hdc, Point origin) override;
    std::wstring autoTooltipText() const override;
    void mouseDown() override;
    void mouseMove() override;
    void setPressed(bool pressed) override;
    void click() override;
    bool mouseWheel(int delta) override;
    bool mouseHorizontalWheel(int delta) override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;

protected:
    Control* hitTestTree(Point point, Point origin) override;
    bool hitTestLocal(Point localPoint) const override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

    friend class HierarchicalListBoxItemControl;

private:
    enum class ScrollHitPart {
        None,
        TrackBeforeThumb,
        TrackAfterThumb,
        Thumb,
    };

    struct FlatItem {
        const HierarchicalListBoxItem* item = nullptr;
        std::vector<int> path;
        int depth = 0;
        bool hasChildren = false;
    };

    ListBoxStyle style_;
    std::vector<HierarchicalListBoxItem> items_;
    std::vector<int> selectedPath_;
    int scrollOffset_ = 0;
    double wheelScrollRemainder_ = 0.0;
    ULONGLONG wheelScrollLastMilliseconds_ = 0;
    ScrollHitPart activeScrollPart_ = ScrollHitPart::None;
    int dragThumbOffset_ = 0;
    bool draggingThumb_ = false;
    bool suppressNextClick_ = false;
    bool itemTooltipsEnabled_ = true;
    ULONGLONG lastActivationClickMilliseconds_ = 0;
    std::vector<int> lastActivationClickPath_;
    std::vector<HierarchicalListBoxItemControl*> itemControls_;
    mutable bool flatItemsDirty_ = true;
    mutable std::vector<FlatItem> flatItems_;
    std::function<void(const std::vector<int>&, const HierarchicalListBoxItem&)> onSelectionChanged_;
    std::function<void(const std::vector<int>&, const HierarchicalListBoxItem&)> onActivated_;
    std::function<void(const std::vector<int>&, bool)> onExpandedChanged_;

    Rect surfaceSpanForVerticalRange(int y, int height) const;
    Rect listViewportRect() const;
    Rect scrollBarRect() const;
    Rect scrollTrackRect() const;
    Rect scrollThumbRect() const;
    bool needsScrollBar() const;
    int rowIndexAt(Point localPoint) const;
    Rect rowRectForVisibleIndex(int visibleIndex) const;
    Rect rowTextRect(Rect rowRect, bool selected, bool hot, int depth, bool hasChildren) const;
    Rect expanderRect(Rect rowRect, bool selected, bool hot, int depth) const;
    int scrollValueFromThumbPosition(int thumbTop) const;
    ScrollHitPart scrollPartAt(Point localPoint) const;
    bool setScrollOffsetInternal(int offset, bool invalidate);
    void ensureSelectedVisible();
    void selectPath(std::vector<int> path, bool notify);
    void activatePath(const std::vector<int>& path);
    bool scrollByRows(int rows);
    void syncItemControls();
    void paintItemControl(const HierarchicalListBoxItemControl& control, HDC hdc, Point origin);
    std::wstring itemControlTooltipText(const HierarchicalListBoxItemControl& control) const;
    void mouseDownItemControl(HierarchicalListBoxItemControl& control);
    void clickFlatIndex(int index);
    void clickItemControl(const HierarchicalListBoxItemControl& control);
    int listViewportPixelHeight() const;
    int firstVisibleItemIndex() const;
    const std::vector<FlatItem>& flatItems() const;
    void rebuildFlatItems() const;
    void appendFlatItems(const std::vector<HierarchicalListBoxItem>& items, std::vector<int>& path, int depth) const;
    void invalidateFlatItems() const;
    int flatIndexForPath(const std::vector<int>& path) const;
    const HierarchicalListBoxItem* itemAtPath(const std::vector<int>& path) const;
    HierarchicalListBoxItem* itemAtPath(const std::vector<int>& path);
    std::vector<int> firstEnabledPath() const;
    bool pathContainsSelectedDescendant(const std::vector<int>& path) const;
    bool setExpandedInternal(std::vector<int> path, bool expanded, bool notify);
    void setExpandedRecursive(std::vector<HierarchicalListBoxItem>& items, bool expanded);
    std::wstring expandedPathsText() const;
    void applyExpandedPathsText(const std::wstring& text);
};

class DiskViewer : public Control {
public:
    DiskViewer(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setStyle(ListBoxStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setItems(std::vector<DiskViewerItem> items, std::wstring currentPath = L"");
    bool setCurrentPath(std::wstring path);
    const std::wstring& currentPath() const;
    bool refresh();
    void setShowFiles(bool showFiles);
    bool showFiles() const;
    void setShowHidden(bool showHidden);
    bool showHidden() const;
    const std::vector<DiskViewerItem>& items() const;
    int selectedIndex() const;
    void setSelectedIndex(int index);
    const DiskViewerItem* selectedItem() const;
    std::wstring selectedName() const;
    std::wstring selectedPath() const;
    const std::wstring& lastError() const;
    int scrollOffset() const;
    void setScrollOffset(int offset);
    int maxScrollOffset() const;
    int visibleRowCapacity() const;
    WDUI_DEPRECATED("Do not use DiskViewer::setOnSelectionChanged; use Control::addSelectionChangedListener(...) instead.")
    void setOnSelectionChanged(std::function<void(int, const DiskViewerItem&)> callback);
    WDUI_DEPRECATED("Do not use DiskViewer::setOnActivated; use Control::addActivationListener(...) instead.")
    void setOnActivated(std::function<void(const DiskViewerItem&)> callback);
    WDUI_DEPRECATED("Do not use DiskViewer::setOnPathChanged; use Control::addValueChangedListener(...) instead.")
    void setOnPathChanged(std::function<void(const std::wstring&)> callback);
    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;
    void mouseDown() override;
    void mouseMove() override;
    void setPressed(bool pressed) override;
    void click() override;
    bool mouseWheel(int delta) override;
    bool mouseHorizontalWheel(int delta) override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;
    void applyState(const ControlState& state, bool restoreGeometry = false) override;

protected:
    Control* hitTestTree(Point point, Point origin) override;
    bool hitTestLocal(Point localPoint) const override;
    void onBoundsChanged() override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

    friend class DiskViewerItemControl;

private:
    enum class ScrollHitPart {
        None,
        TrackBeforeThumb,
        TrackAfterThumb,
        Thumb,
    };

    struct LayoutCache {
        bool valid = false;
        Rect viewport;
        Rect scrollBar;
        Rect scrollTrack;
        Rect scrollThumb;
        int viewportHeight = 0;
        int maxScrollOffset = 0;
        int firstVisibleIndex = 0;
        int visibleRowCapacity = 1;
        int partialRowOffset = 0;
        bool needsScrollBar = false;
    };

    ListBoxStyle style_;
    std::vector<DiskViewerItem> items_;
    std::wstring currentPath_;
    std::wstring lastError_;
    bool showFiles_ = true;
    bool showHidden_ = false;
    bool customItems_ = false;
    int selectedIndex_ = -1;
    int scrollOffset_ = 0;
    double wheelScrollRemainder_ = 0.0;
    ULONGLONG wheelScrollLastMilliseconds_ = 0;
    ScrollHitPart activeScrollPart_ = ScrollHitPart::None;
    int dragThumbOffset_ = 0;
    bool draggingThumb_ = false;
    bool suppressNextClick_ = false;
    ULONGLONG lastActivationClickMilliseconds_ = 0;
    int lastActivationClickIndex_ = -1;
    mutable LayoutCache layoutCache_;
    std::vector<DiskViewerItemControl*> itemControls_;
    std::function<void(int, const DiskViewerItem&)> onSelectionChanged_;
    std::function<void(const DiskViewerItem&)> onActivated_;
    std::function<void(const std::wstring&)> onPathChanged_;

    Rect surfaceSpanForVerticalRange(int y, int height) const;
    Rect listViewportRect() const;
    Rect scrollBarRect() const;
    Rect scrollTrackRect() const;
    Rect scrollThumbRect() const;
    bool needsScrollBar() const;
    int rowIndexAt(Point localPoint) const;
    Rect rowRectForVisibleIndex(int visibleIndex) const;
    Rect rowTextRect(Rect rowRect, bool selected, bool hot) const;
    Rect rowIconRect(Rect rowRect, bool selected, bool hot) const;
    int scrollValueFromThumbPosition(int thumbTop) const;
    ScrollHitPart scrollPartAt(Point localPoint) const;
    bool setScrollOffsetInternal(int offset, bool invalidate);
    void ensureSelectedVisible();
    void selectIndex(int index, bool notify);
    void activateIndex(int index);
    bool navigateToPath(const std::wstring& path);
    bool navigateToRoot();
    bool navigateToParent();
    bool scrollByRows(int rows);
    int listViewportPixelHeight() const;
    int firstVisibleItemIndex() const;
    const LayoutCache& layoutCache() const;
    void invalidateLayoutCache() const;
    void syncItemControls();
    void paintItemControl(const DiskViewerItemControl& control, HDC hdc, Point origin);
    std::wstring itemControlTooltipText(const DiskViewerItemControl& control) const;
    void clickItemIndex(int index);
    void clickItemControl(const DiskViewerItemControl& control);
    std::wstring currentRootPath() const;
    std::wstring currentParentPath() const;
    void resetSelectionAfterRefresh(std::wstring preferredPath);
};

class DateInput : public Control {
public:
    DateInput(std::wstring id, Rect bounds, DateValue value = {}, Theme theme = Theme::taskBoardFamily());
    ~DateInput() override;

    void setStyle(DateInputStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    DateValue value() const;
    void setValue(DateValue value);
    std::wstring valueText() const;
    WDUI_DEPRECATED("Do not use DateInput::setOnChanged; use Control::addValueChangedListener(...) instead.")
    void setOnChanged(std::function<void(DateValue)> callback);
    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;
    void paintOverlay(HDC hdc, Point origin) override;
    Control* hitTestTransientTree(Point point, Point origin) override;
    Control* hitTestTree(Point point, Point origin) override;
    bool dismissTransientUi(Point point, Point origin) override;
    void mouseDown() override;
    void click() override;
    bool mouseWheel(int delta) override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void onBoundsChanged() override;
    void onOwningWindowChanged() override;
    void onOwningWindowGeometryChanged() override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

private:
    friend struct DateInputTransientState;

    DateInputStyle style_;
    DateValue value_{};
    int viewYear_ = 0;
    int viewMonth_ = 0;
    bool calendarOpen_ = false;
    int hoverCell_ = -1;
    int pressedCell_ = -1;
    int hoverNav_ = 0;
    int pressedNav_ = 0;
    std::function<void(DateValue)> onChanged_;
    std::unique_ptr<DateInputTransientState> transientState_;

    static DateValue today();
    static bool isValidDate(DateValue date);
    static DateValue normalizedDate(DateValue date);
    static int daysInMonth(int year, int month);
    static int dayOfWeekMonday(DateValue date);
    static DateValue addDays(DateValue date, int days);
    static DateValue addMonths(DateValue date, int months);
    static std::wstring formatDate(DateValue date);
    static std::wstring formatMonthTitle(int year, int month);
    static std::wstring weekdayLabel(int mondayIndex);

    Rect localMainRect() const;
    Rect localCalendarRect() const;
    Rect localArrowRect() const;
    Rect calendarHeaderRect() const;
    Rect calendarPrevRect() const;
    Rect calendarNextRect() const;
    Rect calendarGridRect() const;
    int calendarCellAt(Point localPoint) const;
    int calendarNavAt(Point localPoint) const;
    DateValue dateForCell(int cell) const;
    void paintCalendarAt(HDC hdc, Point origin);
    void openCalendar();
    void closeCalendar();
    void selectDate(DateValue date, bool notify);
    void changeViewMonth(int delta);
};

struct TabItem {
    std::wstring id;
    std::wstring label;
};

class TabStrip : public Control {
public:
    TabStrip(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setStyle(TabStripStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setItems(std::vector<TabItem> items);
    void setOrientation(Orientation orientation);
    int activeIndex() const;
    void setActiveIndex(int index);
    WDUI_DEPRECATED("Do not use TabStrip::setOnChanged; use Control::addSelectionChangedListener(...) instead.")
    void setOnChanged(std::function<void(int, const TabItem&)> callback);
    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;
    void click() override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

private:
    int itemIndexAt(Point localPoint) const;

    TabStripStyle style_;
    std::vector<TabItem> items_;
    Orientation orientation_ = Orientation::Horizontal;
    int activeIndex_ = 0;
    std::function<void(int, const TabItem&)> onChanged_;
};

struct MenuItem {
    std::wstring id;
    std::wstring label;
    std::wstring shortcut;
    bool enabled = true;
    bool checked = false;
    bool separator = false;
    std::vector<MenuItem> children;
    std::function<void()> callback;

    static MenuItem separatorItem();
};

class MenuBar : public Control {
public:
    MenuBar(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());
    ~MenuBar() override;

    void setStyle(MenuBarStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setItems(std::vector<MenuItem> items);
    const std::vector<MenuItem>& items() const;
    WDUI_DEPRECATED("Do not use MenuBar::setOnCommand; use Control::addCommandListener(...) instead.")
    void setOnCommand(std::function<void(const MenuItem&)> callback);
    int activeRootIndex() const;
    void closeMenu();
    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;
    bool dismissTransientUi(Point point, Point origin) override;
    void mouseDown() override;
    void click() override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void onBoundsChanged() override;
    void onOwningWindowChanged() override;
    void onOwningWindowGeometryChanged() override;

private:
    friend struct MenuBarTransientState;

    MenuBarStyle style_;
    std::vector<MenuItem> items_;
    int activeRootIndex_ = -1;
    int pressedRootIndex_ = -1;
    std::function<void(const MenuItem&)> onCommand_;
    std::unique_ptr<MenuBarTransientState> transientState_;

    Rect rootItemRect(int index) const;
    int rootIndexAt(Point localPoint) const;
    int estimatedTextWidth(const std::wstring& text, const TextStyle& style) const;
    int popupWidthForItems(const std::vector<MenuItem>& items) const;
    int popupHeightForItems(const std::vector<MenuItem>& items) const;
    void openRoot(int index);
    void activateItem(const MenuItem& item);
    void syncPopup();
};

struct TableColumn {
    std::wstring title;
    int width = 120;
    bool sortable = true;
};

struct TableRow {
    std::vector<std::wstring> cells;
    std::wstring severity;
};

class TableList : public Control {
public:
    TableList(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setStyle(TableListStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setColumns(std::vector<TableColumn> columns);
    void setRows(std::vector<TableRow> rows);
    int selectedIndex() const;
    void setSelectedIndex(int index);
    void setHorizontalOffset(int offset);
    int horizontalOffset() const;
    void setColumnsResizable(bool enabled);
    bool columnsResizable() const;
    void setMinimumColumnWidth(int width);
    int minimumColumnWidth() const;
    void setAutoSizeColumnsToContent(bool enabled);
    bool autoSizeColumnsToContent() const;
    std::vector<int> columnWidths() const;
    void setColumnWidths(const std::vector<int>& widths);
    int contentWidth() const;
    int maxHorizontalOffset() const;
    int visibleRowCapacity() const;
    WDUI_DEPRECATED("Do not use TableList::setOnSelectionChanged; use Control::addSelectionChangedListener(...) instead.")
    void setOnSelectionChanged(std::function<void(int, const TableRow&)> callback);
    WDUI_DEPRECATED("Do not use TableList::setOnColumnWidthsChanged; use Control::addColumnWidthsChangedListener(...) instead.")
    void setOnColumnWidthsChanged(std::function<void(const std::vector<int>&)> callback);
    void setOnWheel(std::function<bool(int)> callback);
    void setSortingEnabled(bool enabled);
    bool sortingEnabled() const;
    void setAutoSortRows(bool enabled);
    bool autoSortRows() const;
    void setSort(int column, SortDirection direction);
    int sortColumn() const;
    SortDirection sortDirection() const;
    WDUI_DEPRECATED("Do not use TableList::setOnSortChanged; use Control::addSortChangedListener(...) instead.")
    void setOnSortChanged(std::function<void(int, SortDirection)> callback);
    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;
    void mouseDown() override;
    void mouseMove() override;
    void setPressed(bool pressed) override;
    void click() override;
    bool mouseWheel(int delta) override;
    bool mouseHorizontalWheel(int delta) override;
    void applyState(const ControlState& state, bool restoreGeometry = false) override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

private:
    COLORREF rowFill(const TableRow& row, bool selected) const;
    COLORREF rowText(const TableRow& row, bool selected) const;
    int estimatedTextWidth(const std::wstring& text) const;
    std::vector<int> effectiveColumnWidths() const;
    Rect surfaceSpanForVerticalRange(int y, int height) const;
    int visibleColumnAreaWidth() const;
    int effectiveMinimumColumnWidth() const;
    int columnResizeHitIndex(Point localPoint) const;
    int columnIndexAtHeader(Point localPoint) const;
    int rowIndexAt(Point localPoint) const;
    void applySortToRows();

    TableListStyle style_;
    std::vector<TableColumn> columns_;
    std::vector<TableRow> rows_;
    int selectedIndex_ = -1;
    int horizontalOffset_ = 0;
    double horizontalWheelScrollRemainder_ = 0.0;
    ULONGLONG horizontalWheelScrollLastMilliseconds_ = 0;
    bool columnsResizable_ = false;
    bool autoSizeColumnsToContent_ = false;
    int minimumColumnWidth_ = 28;
    int resizingColumn_ = -1;
    int resizeStartX_ = 0;
    int resizeStartWidth_ = 0;
    std::vector<int> resizeStartWidths_;
    bool resizedColumnsDirty_ = false;
    bool suppressNextClick_ = false;
    bool sortingEnabled_ = false;
    bool autoSortRows_ = true;
    int sortColumn_ = -1;
    SortDirection sortDirection_ = SortDirection::None;
    int pendingSortColumn_ = -1;
    std::function<void(int, const TableRow&)> onSelectionChanged_;
    std::function<void(const std::vector<int>&)> onColumnWidthsChanged_;
    std::function<bool(int)> onWheel_;
    std::function<void(int, SortDirection)> onSortChanged_;
};

enum class RichSegmentKind {
    Text,
    Icon,
    AnimatedIcon,
    Link
};

struct RichTextSegment {
    RichSegmentKind kind = RichSegmentKind::Text;
    std::wstring text;
    std::wstring target;
    COLORREF color = CLR_INVALID;
    TextStyle textStyle{};
    bool hasTextStyle = false;
    Image iconImage;
    AnimatedImage animatedIcon;
    int iconWidth = 16;
    int iconHeight = 16;
};

class RichTextBlock : public Control {
public:
    RichTextBlock(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setStyle(RichTextStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setText(std::wstring text);
    const std::wstring& text() const;
    void clear();
    void addText(std::wstring text);
    void addIcon(std::wstring glyph, COLORREF color = CLR_INVALID);
    void addIcon(Image image, int width = 16, int height = 16);
    void addAnimatedIcon(AnimatedImage image, int width = 16, int height = 16);
    void addLink(std::wstring text, std::wstring target);
    void setSegments(std::vector<RichTextSegment> segments);
    WDUI_DEPRECATED("Do not use RichTextBlock::setOnLinkClick; use Control::addLinkActionListener(...) instead.")
    void setOnLinkClick(std::function<void(const std::wstring&)> callback);
    void paint(HDC hdc, Point origin) override;
    void click() override;
    bool wantsAnimationTick() const override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void onTextFormatChanged() override;

private:
    struct LinkRect {
        RECT rect{};
        std::wstring target;
        std::wstring text;
    };

    void refreshTextSegmentsFromText();

    RichTextStyle style_;
    std::wstring text_;
    std::vector<RichTextSegment> segments_;
    std::vector<LinkRect> linkRects_;
    std::function<void(const std::wstring&)> onLinkClick_;
    bool segmentsFromText_ = false;
};

class TextInput : public Control {
public:
    TextInput(std::wstring id, Rect bounds, std::wstring text = L"", Theme theme = Theme::taskBoardFamily());

    void setStyle(TextInputStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setText(std::wstring text);
    const std::wstring& text() const;
    void setPlaceholder(std::wstring placeholder);
    const std::wstring& placeholder() const;
    void setMultiline(bool multiline);
    bool multiline() const;
    void setReadOnly(bool readOnly);
    bool readOnly() const;
    void setPasswordMode(bool passwordMode);
    bool passwordMode() const;
    void setOverwriteMode(bool overwriteMode);
    bool overwriteMode() const;
    int caretIndex() const;
    void setCaretIndex(int index, bool keepSelection = false);
    void selectAll();
    bool canUndo() const;
    bool canRedo() const;
    bool undo();
    bool redo();
    void clearUndoHistory();
    Size minimumTextSizeForCharacterCount(int characterCount, std::wstring sampleCharacters = L"0123456789") const;
    Size minimumSizeHint() const override;
    void setInputFilter(TextInputFilter filter);
    void clearInputFilter();
    const TextInputFilter& inputFilter() const;
    void setAllowedCharacters(std::wstring characters);
    void setRejectedCharacters(std::wstring characters);
    void setSanitizeFilter(std::function<std::wstring(std::wstring)> callback);
    void setFormatFilter(std::function<bool(const std::wstring&)> callback);
    void setOnRejectedInput(std::function<bool(const std::wstring&)> callback);
    void setAcceptsAttachments(bool acceptsAttachments);
    bool acceptsAttachments() const;
    void setAttachments(std::vector<TextInputAttachment> attachments);
    const std::vector<TextInputAttachment>& attachments() const;
    void addAttachment(TextInputAttachment attachment);
    bool addAttachmentFromFile(std::wstring path);
    void clearAttachments();
    WDUI_DEPRECATED("Do not use TextInput::setOnChanged; use Control::addValueChangedListener(...) instead.")
    void setOnChanged(std::function<void(const std::wstring&)> callback);
    WDUI_DEPRECATED("Do not use TextInput::setOnSubmit; use Control::addCommitListener(...) instead.")
    void setOnSubmit(std::function<void(const std::wstring&)> callback);
    void setOnEnterKey(std::function<bool(bool, bool, bool, HWND)> callback);
    void setOnUnhandledKey(std::function<bool(UINT, bool, bool, bool, HWND)> callback);
    void setOnUnhandledMouseWheel(std::function<bool(int)> callback);
    void setOnAttachmentRemoved(std::function<void(const TextInputAttachment&)> callback);
    void paint(HDC hdc, Point origin) override;
    void mouseDown() override;
    void mouseMove() override;
    void setPressed(bool pressed) override;
    bool mouseWheel(int delta) override;
    bool mouseHorizontalWheel(int delta) override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;
    bool textInput(wchar_t ch, HWND owner) override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

private:
    struct EditingSnapshot {
        std::wstring text;
        int caretIndex = 0;
        int selectionAnchor = 0;
        int textScrollOffset = 0;
    };
    static constexpr std::size_t kMaxUndoStates = 128;

    TextInputStyle style_;
    std::wstring text_;
    std::wstring lastNotifiedText_;
    std::wstring placeholder_;
    bool multiline_ = false;
    bool readOnly_ = false;
    bool passwordMode_ = false;
    bool overwriteMode_ = false;
    TextInputFilter inputFilter_;
    bool acceptsAttachments_ = true;
    std::vector<TextInputAttachment> attachments_;
    int caretIndex_ = 0;
    int selectionAnchor_ = 0;
    int textScrollOffset_ = 0;
    double wheelScrollRemainder_ = 0.0;
    ULONGLONG wheelScrollLastMilliseconds_ = 0;
    std::function<void(const std::wstring&)> onChanged_;
    std::function<void(const std::wstring&)> onSubmit_;
    std::function<bool(bool, bool, bool, HWND)> onEnterKey_;
    std::function<bool(UINT, bool, bool, bool, HWND)> onUnhandledKey_;
    std::function<bool(int)> onUnhandledMouseWheel_;
    std::function<bool(const std::wstring&)> onRejectedInput_;
    std::function<void(const TextInputAttachment&)> onAttachmentRemoved_;

    Rect textArea() const;
    int attachmentRows() const;
    int textContentHeight() const;
    int maxTextScrollOffset() const;
    bool setTextScrollOffsetInternal(int offset);
    int characterIndexAt(Point localPoint) const;
    std::pair<int, int> normalizedSelection() const;
    bool hasInputFilter() const;
    bool characterAllowedByFilter(wchar_t ch) const;
    std::wstring filterCharacters(std::wstring text) const;
    std::wstring sanitizeCandidate(std::wstring text) const;
    bool acceptsFilteredText(const std::wstring& text) const;
    bool candidateForReplacement(const std::wstring& replacement, std::wstring* candidate) const;
    std::wstring acceptedReplacement(std::wstring replacement) const;
    void replaceSelection(std::wstring replacement);
    EditingSnapshot captureEditingSnapshot() const;
    void restoreEditingSnapshot(const EditingSnapshot& snapshot, bool notify);
    void pushUndoState(const EditingSnapshot& snapshot);
    bool sameEditingSnapshot(const EditingSnapshot& left, const EditingSnapshot& right) const;
    int previousWordBoundary(int index) const;
    int nextWordBoundary(int index) const;
    int lineStartForIndex(int index) const;
    int lineEndForIndex(int index) const;
    void notifyChanged();
    void copySelectionToClipboard(HWND owner) const;
    void pasteFromClipboard(HWND owner);
    void removeSelectedText();
    void removeAttachmentAt(Point localPoint);

    std::vector<EditingSnapshot> undoStack_;
    std::vector<EditingSnapshot> redoStack_;
};

class TimeInput : public Panel {
public:
    TimeInput(std::wstring id, Rect bounds, int minutes = 0, Theme theme = Theme::taskBoardFamily());

    void setTextInputStyle(TextInputStyle style);
    void setStepperButtonStyle(ButtonStyle style);
    void setInputStyleId(std::wstring styleId);
    void setStepperStyleId(std::wstring styleId);
    void setValueMinutes(int minutes);
    int valueMinutes() const;
    bool tryValueMinutes(int* minutes) const;
    bool commit();
    void setMinuteStep(int minutes);
    int minuteStep() const;
    void setPlaceholder(std::wstring placeholder);
    void setTooltipText(std::wstring text);
    void setInvalidTooltipText(std::wstring text);
    void setStepperTooltipText(std::wstring incrementText, std::wstring decrementText);
    WDUI_DEPRECATED("Do not use TimeInput::setOnChanged; use Control::addValueChangedListener(...) instead.")
    void setOnChanged(std::function<void(int)> callback);
    WDUI_DEPRECATED("Do not use TimeInput::setOnCommitted; use Control::addCommitListener(...) instead.")
    void setOnCommitted(std::function<void(int)> callback);
    void refreshLayout();
    void onStyleCatalogApplied() override;
    bool mouseWheel(int delta) override;
    Size minimumSizeHint() const override;

protected:
    void onBoundsChanged() override;

private:
    TextInput* hourInput_ = nullptr;
    TextInput* minuteInput_ = nullptr;
    Label* separatorLabel_ = nullptr;
    ThemedButton* upButton_ = nullptr;
    ThemedButton* downButton_ = nullptr;
    int valueMinutes_ = 0;
    int minuteStep_ = 5;
    std::wstring tooltipText_;
    std::wstring invalidTooltipText_;
    std::function<void(int)> onChanged_;
    std::function<void(int)> onCommitted_;

    static bool acceptsPartialTimeText(const std::wstring& text);
    static bool acceptsPartialHourText(const std::wstring& text);
    static bool acceptsPartialMinuteText(const std::wstring& text);
    static std::optional<int> parseTimeText(const std::wstring& text);
    static std::optional<int> parseTimePartText(const std::wstring& text, int maximum);
    static std::wstring formatTime(int minutes);
    Size desiredMinimumSize() const;
    void layoutParts();
    void refreshValidityTooltip();
    void focusHour(bool selectText);
    void focusMinute(bool selectText);
    void notifyIfValidChanged();
    void notifyCommitted();
    bool commitFromText(bool notify);
    void stepBy(int steps, bool notify);
};

class SelectableTextBlock : public Control {
public:
    SelectableTextBlock(std::wstring id, Rect bounds, std::wstring text = L"", Theme theme = Theme::taskBoardFamily());

    void setStyle(SelectableTextStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setText(std::wstring text);
    const std::wstring& text() const;
    void setWordWrap(bool enabled);
    bool wordWrap() const;
    void setScrollOffset(int offset);
    int scrollOffset() const;
    void setHorizontalScrollOffset(int offset);
    int horizontalScrollOffset() const;
    int contentHeight();
    int contentWidth();
    int maxScrollOffset();
    int maxHorizontalScrollOffset();
    std::wstring selectedText();
    WDUI_DEPRECATED("Do not use SelectableTextBlock::setOnScrollChanged; use Control::addScrollListener(...) instead.")
    void setOnScrollChanged(std::function<void(int)> callback);
    WDUI_DEPRECATED("Do not use SelectableTextBlock::setOnHorizontalScrollChanged; use Control::addScrollListener(...) instead.")
    void setOnHorizontalScrollChanged(std::function<void(int)> callback);
    void paint(HDC hdc, Point origin) override;
    void mouseDown() override;
    void mouseMove() override;
    void setPressed(bool pressed) override;
    bool mouseWheel(int delta) override;
    bool mouseHorizontalWheel(int delta) override;
    bool keyDown(UINT key, bool control, bool shift, bool alt, HWND owner) override;

protected:
    bool hitTestLocal(Point localPoint) const override;
    void onTextFormatChanged() override;
    void captureStateValues(ControlState& state) const override;
    void applyStateValue(const StateValue& value) override;

private:
    struct TextLine {
        std::wstring text;
        int start = 0;
        int length = 0;
        int y = 0;
        int height = 0;
        int width = 0;
        TextStyle style{};
        std::vector<int> prefixWidths;
    };

    void rebuildLayout();
    void invalidateLayout();
    int averageCharacterWidth() const;
    int averageCharacterWidth(const TextStyle& style) const;
    int characterIndexAt(Point localPoint);
    std::pair<int, int> normalizedSelection() const;
    bool copySelectionToClipboard(HWND owner);
    bool setScrollOffsetInternal(int offset, bool notify);
    bool setHorizontalScrollOffsetInternal(int offset, bool notify);

    SelectableTextStyle style_;
    std::wstring text_;
    std::wstring layoutText_;
    std::vector<TextLine> lines_;
    int layoutWidth_ = -1;
    int layoutContentWidth_ = 0;
    int scrollOffset_ = 0;
    int horizontalScrollOffset_ = 0;
    double wheelScrollRemainder_ = 0.0;
    double horizontalWheelScrollRemainder_ = 0.0;
    ULONGLONG wheelScrollLastMilliseconds_ = 0;
    ULONGLONG horizontalWheelScrollLastMilliseconds_ = 0;
    int selectionAnchor_ = 0;
    int selectionCaret_ = 0;
    bool wordWrap_ = true;
    bool selecting_ = false;
    std::function<void(int)> onScrollChanged_;
    std::function<void(int)> onHorizontalScrollChanged_;
};

struct PopupAction {
    std::wstring id;
    std::wstring label;
    bool primary = false;
    std::function<void()> callback;
};

class DesignedPopup : public Control {
public:
    DesignedPopup(std::wstring id, Rect bounds, Theme theme = Theme::taskBoardFamily());

    void setStyle(PopupStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setTitle(std::wstring title);
    void setMessage(std::wstring message);
    void setIconText(std::wstring iconText);
    void setOpen(bool open);
    bool open() const;
    WDUI_DEPRECATED("Do not use DesignedPopup::setOnClose; use Control::addPopupEventListener(...) instead.")
    void setOnClose(std::function<void()> callback);
    WDUI_DEPRECATED("Do not use DesignedPopup::setOnDrag; use Control::addPopupEventListener(...) instead.")
    void setOnDrag(std::function<void()> callback);
    void addAction(PopupAction action);
    void clearActions();
    std::wstring autoTooltipText() const override;
    std::optional<SurfaceStyle> windowRegionSurfaceStyle() const override;
    void paint(HDC hdc, Point origin) override;
    void paintOverlay(HDC hdc, Point origin) override;
    Control* hitTestTree(Point point, Point origin) override;
    void mouseDown() override;
    void click() override;

protected:
    bool hitTestLocal(Point localPoint) const override;

private:
    int actionIndexAt(Point localPoint) const;
    bool actionLabelLikelyTruncated(int index) const;
    Rect closeRect() const;
    Rect actionRect(int index) const;

    PopupStyle style_;
    std::wstring title_;
    std::wstring message_;
    std::wstring iconText_ = L"i";
    bool open_ = false;
    std::vector<PopupAction> actions_;
    std::function<void()> onClose_;
    std::function<void()> onDrag_;
};

class BitmapButton : public Control {
public:
    BitmapButton(std::wstring id, Rect bounds, std::wstring text, Image normal);

    void setImages(Image normal, Image hot, Image pressed, Image disabled);
    void setText(std::wstring text);
    void setTextStyle(TextStyle style);
    void setStyle(BitmapButtonStyle style);
    bool applyStyleFromCatalog(const StyleCatalog& catalog) override;
    void setTint(BitmapTint tint);
    const BitmapTint& tint() const;
    WDUI_DEPRECATED("Do not use BitmapButton::setOnClick; use Control::addCommandListener(...) instead.")
    void setOnClick(std::function<void()> callback);
    void setPixelHitTesting(bool enabled, std::uint8_t alphaThreshold = 16);

    std::wstring autoTooltipText() const override;
    void paint(HDC hdc, Point origin) override;
    void click() override;

protected:
    bool hitTestLocal(Point localPoint) const override;

private:
    const Image& imageForState() const;
    const BitmapTint& tintForState() const;
    bool textLikelyTruncated() const;

    std::wstring text_;
    TextStyle textStyle_;
    Image normal_;
    Image hotImage_;
    Image pressedImage_;
    Image disabledImage_;
    StatefulBitmapTint tint_;
    bool pixelHitTesting_ = true;
    std::uint8_t alphaThreshold_ = 16;
    std::function<void()> onClick_;
};

class Window {
public:
    Window();
    virtual ~Window();

    bool create(
        HINSTANCE instance,
        const std::wstring& title,
        int width,
        int height,
        DWORD style = WS_OVERLAPPEDWINDOW,
        DWORD exStyle = 0,
        HWND owner = nullptr);

    void show(int showCommand = SW_SHOWNORMAL);
    int run();
    HWND hwnd() const;
    const std::wstring& title() const;
    void setTitle(std::wstring title);
    Panel& root();
    Control* focusedControl() const;
    void setFocusedControl(Control* control);
    DebugOptions& debugOptions();
    void setBackgroundColor(COLORREF color);
    void setWindowStyle(WindowStyle style);
    const WindowStyle& windowStyle() const;
    PerformanceProfile performanceProfile() const;
    void setPerformanceProfile(PerformanceProfile profile);
    RenderBackend renderBackend() const;
    RenderBackend effectiveRenderBackend() const;
    bool direct2DActiveForDiagnostics() const;
    int direct2DNativeSurfacePaintCountForDiagnostics() const;
    int direct2DNativeShaderPaintCountForDiagnostics() const;
    int direct2DHlslEffectPaintCountForDiagnostics() const;
    void setRenderBackend(RenderBackend backend);
    void setSurfaceRegionEnabled(bool enabled);
    void setChildSurfaceRegionEnabled(bool enabled);
    void applySurfaceRegion();
    void clearSurfaceRegion();
    void setTooltipTheme(Theme theme);
    void setTooltipStyle(TooltipStyle style);
    const TooltipStyle& tooltipStyle() const;
    void setTooltipDelayMilliseconds(int delayMilliseconds);
    void setTooltipInteractionMode(TooltipInteractionMode mode);
    TooltipInteractionMode tooltipInteractionMode() const;
    void setTooltipMotionDismissTolerance(int pixels);
    int tooltipMotionDismissTolerance() const;
    void setTooltipPinDelayMilliseconds(int delayMilliseconds);
    int tooltipPinDelayMilliseconds() const;
    void setTooltipActionHandler(std::function<void(const Control&, const TooltipAction&)> callback);
    void updateTooltipStateForDiagnostics();
    const Control* hotControlForDiagnostics() const;
    bool activeTooltipVisibleForDiagnostics() const;
    bool activeTooltipPinnedForDiagnostics() const;
    Rect activeTooltipRectForDiagnostics() const;
    const Control* activeTooltipControlForDiagnostics() const;
    Rect nestedTooltipRectForDiagnostics() const;
    const Control* nestedTooltipControlForDiagnostics() const;
    Connection addInputPreviewListener(std::function<void(RoutedEvent&)> callback);
    Connection addInputTargetListener(std::function<void(RoutedEvent&)> callback);
    Connection addInputBubbleListener(std::function<void(RoutedEvent&)> callback);
    Connection addResizeListener(std::function<void(WindowResizeEvent&)> callback);
    void clearInputListeners();
    void hideTooltip();
    bool isControlInActiveTooltip(const Control* control) const;
    void setTransientLayerOrder(int order);
    int transientLayerOrder() const;
    void setLocalizationHandler(std::function<void(Window&)> callback);
    void clearLocalizationHandler();
    bool hasLocalizationHandler() const;
    void setMinimumClientSize(Size size);
    Size minimumClientSize() const;
    void setDefaultClientSize(Size size);
    Size defaultClientSize() const;
    bool resetToDefaultSize();
    void setAutoMinimumClientSizeEnabled(bool enabled);
    bool autoMinimumClientSizeEnabled() const;
    WDUI_DEPRECATED("Do not use Window::setOnResize; use Window::addResizeListener(...) instead.")
    void setOnResize(std::function<void(Size)> callback);
    void setMessageHandler(std::function<std::optional<LRESULT>(UINT, WPARAM, LPARAM)> callback);
    void setQuitOnDestroy(bool enabled);
    void setDismissOnDeactivate(bool enabled);
    bool dismissOnDeactivate() const;
    WindowState captureWindowState() const;
    void applyWindowState(const WindowState& state);
    AppUiState captureUiState() const;
    void applyUiState(const AppUiState& state, bool restoreControlGeometry = false);
    void invalidate();
    void invalidate(Rect rect);
    void invalidateControl(const Control& control, int padding = 8);
    void retranslate();
    std::optional<Point> originOfControl(const Control* target) const;
    std::optional<Point> layoutOriginOfControl(const Control* target) const;
    void centerOn(HWND owner = nullptr);
    void minimize();
    void toggleMaximize();
    void close();
    void beginMoveDrag();

    static LRESULT CALLBACK staticWindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

protected:
    virtual void onCreated();
    virtual void onDestroying();
    virtual void onPaintOverlay(HDC hdc, const RECT& clientRect);

private:
    LRESULT windowProc(UINT message, WPARAM wParam, LPARAM lParam);

    void paint();
    void paintContentToHdc(HDC hdc, const RECT& client, Rect dirtyRect);
    bool ensureBackBuffer(HDC hdc, int width, int height);
    void releaseBackBuffer();
    bool paintDirect2D(const PAINTSTRUCT& paintStruct, const RECT& client, int width, int height);
    bool ensureDirect2DRenderTarget(int width, int height, bool& targetCreatedOrResized);
    void releaseDirect2DRenderTarget();
    void releaseDirect2DResources();
    void updateRootSize();
    void emitResize(WindowResizeEvent& event);
    void syncLayoutToClient();
    void ensureWindowVisibleOnCurrentMonitor();
    void dismissBecauseDeactivated();
    Size effectiveMinimumClientSize() const;
    Size minimumWindowTrackSize() const;
    Size windowSizeForClientSize(Size clientSize) const;
    Rect fitWindowRectToMinimumAndWorkArea(Rect rect) const;
    void constrainSizingRect(WPARAM sizingEdge, RECT& rect) const;
    LRESULT resizeHitTest(Point screenPoint) const;
    void traceHitTestDiagnostic(Point screenPoint, LRESULT hit) const;
    void traceSizingDiagnostic(WPARAM sizingEdge, Point screenPoint, const RECT& before, const RECT& after) const;
    void traceMinMaxDiagnostic(Point screenPoint, const MINMAXINFO& info) const;
    Control* hitTest(Point point);
    bool dispatchInputEvent(RoutedEvent& event);
    Point screenPointFromClient(Point point) const;
    Point localPointForControl(const Control* target, Point clientPoint, bool tooltipTarget) const;
    bool routePointerInput(Control* source, Control* target, Point clientPoint, PointerButton button, int clickCount, WPARAM keyState, bool tooltipTarget);
    bool routeWheelInput(Control* source, Control* target, Point clientPoint, Point screenPoint, int delta, bool horizontal, WPARAM keyState, bool tooltipTarget);
    bool routeKeyInput(Control* target, UINT key, bool control, bool shift, bool alt);
    bool routeTextInput(Control* target, wchar_t ch);
    std::optional<Point> findControlOrigin(
        const Control* target,
        const Control& current,
        Point parentOrigin,
        bool includeTargetFollowOffset = true,
        bool includeAncestorFollowOffset = true) const;
    std::optional<Point> findTooltipControlOrigin(
        const Control* target,
        bool includeTargetFollowOffset = true,
        bool includeAncestorFollowOffset = true) const;
    void dispatchCapturedMouseMove(Point point);
    void updateHotControl(Control* nextHot);
    void updateTooltipState();
    bool windowSurfaceWantsAnimationTick() const;
    bool dismissTooltipTransientUi(Point point);
    bool tooltipUsesPointerTransit() const;
    bool tooltipUsesPinOnClick() const;
    bool tooltipAllowsPointerTransit() const;
    bool tooltipCanBePinned(ULONGLONG nowMilliseconds) const;
    bool pinTooltipIfEligible(ULONGLONG nowMilliseconds);
    void unpinTooltip();
    bool tooltipPointerMoveIsSignificant(Point point) const;
    void resetTooltipPointerIdle(Point point, ULONGLONG nowMilliseconds);
    bool noteTooltipPointerMove(Point point, ULONGLONG nowMilliseconds);
    bool pointInActiveTooltip(Point point) const;
    bool pointInTooltipHoverZone(Point point) const;
    bool shouldKeepTooltipForPointerTransit(Point point, Point previousPoint, ULONGLONG nowMilliseconds);
    bool pointInTooltipText(Point point) const;
    int tooltipActionIndexAt(Point point) const;
    Control* hitTestTooltipControl(Point point);
    void releaseTooltipReferencesForTooltipControlsOf(const Control* owner);
    void updateTooltipHotControl(Control* nextHot);
    void dispatchTooltipCapturedMouseMove(Point point);
    std::wstring tooltipDisplayText() const;
    int tooltipTextCharacterIndexAt(Point point) const;
    void updateTooltipTextSelection(Point point);
    std::pair<int, int> normalizedTooltipTextSelection() const;
    std::wstring selectedTooltipText() const;
    bool copyTooltipTextSelectionToClipboard() const;
    void resetTooltipTextSelection();
    bool tooltipControlsWantAnimationTick() const;
    bool scrollActiveTooltip(int wheelDelta);
    const TooltipStyle& activeTooltipStyle() const;
    void paintTooltipControls(HDC hdc, const std::vector<std::unique_ptr<Control>>& controls, Point origin);
    void drawTooltip(HDC hdc, const RECT& clientRect);
    void drawNestedTooltip(HDC hdc, const RECT& clientRect);
    void drawDebugOverlay(HDC hdc, const RECT& clientRect);

    HWND hwnd_ = nullptr;
    HINSTANCE instance_ = nullptr;
    friend class Control;
    std::wstring title_;
    Panel root_;
    DebugOptions debug_;
    COLORREF backgroundColor_ = RGB(9, 17, 18);
    WindowStyle windowStyle_;
    PerformanceProfile performanceProfile_ = PerformanceProfile::Balanced;
    RenderBackend renderBackend_ = RenderBackend::Gdi;
    RenderBackend effectiveRenderBackend_ = RenderBackend::Gdi;
    TooltipStyle tooltipStyle_;
    EventDispatcher inputDispatcher_;
    Signal<WindowResizeEvent&> resizeSignal_;
    std::function<void(const Control&, const TooltipAction&)> tooltipActionHandler_;
    std::function<void(Window&)> localizationHandler_;
    Size minimumClientSize_;
    std::function<void(Size)> onResize_;
    std::function<std::optional<LRESULT>(UINT, WPARAM, LPARAM)> messageHandler_;
    Size defaultClientSize_;
    Size lastClientSize_;
    int tooltipDelayMilliseconds_ = 650;
    TooltipInteractionMode tooltipInteractionMode_ = TooltipInteractionMode::PinOnClick;
    int tooltipMotionDismissTolerance_ = 4;
    int tooltipPinDelayMilliseconds_ = 350;
    int transientLayerOrder_ = 0;
    bool quitOnDestroy_ = true;
    bool dismissOnDeactivate_ = false;
    bool autoMinimumClientSizeEnabled_ = true;
    bool hasLastClientSize_ = false;
    bool resetToDefaultSizeActive_ = false;
    Control* hotControl_ = nullptr;
    Control* pressedControl_ = nullptr;
    Control* focusedControl_ = nullptr;
    Control* tooltipControl_ = nullptr;
    Control* hotTooltipControl_ = nullptr;
    Control* nestedTooltipControl_ = nullptr;
    Control* pressedTooltipControl_ = nullptr;
    Control* focusedTooltipControl_ = nullptr;
    Rect tooltipRect_;
    Rect nestedTooltipRect_;
    Rect tooltipTextViewportRect_;
    Rect tooltipTextContentRect_;
    Rect tooltipControlsViewportRect_;
    Point tooltipControlsOrigin_;
    std::vector<Rect> tooltipActionRects_;
    Point tooltipAnchor_;
    int tooltipScrollOffset_ = 0;
    double tooltipWheelScrollRemainder_ = 0.0;
    ULONGLONG tooltipWheelScrollLastMilliseconds_ = 0;
    int tooltipMaxScrollOffset_ = 0;
    int tooltipTextBlockHeight_ = 0;
    int tooltipTextLineHeight_ = 0;
    int tooltipSelectionAnchor_ = 0;
    int tooltipSelectionCaret_ = 0;
    int pressedTooltipActionIndex_ = -1;
    ULONGLONG hotControlSinceMilliseconds_ = 0;
    ULONGLONG hotTooltipControlSinceMilliseconds_ = 0;
    ULONGLONG tooltipPointerIdleSinceMilliseconds_ = 0;
    ULONGLONG tooltipTransitGraceUntilMilliseconds_ = 0;
    ULONGLONG tooltipShownSinceMilliseconds_ = 0;
    bool tooltipVisible_ = false;
    bool tooltipPinned_ = false;
    bool tooltipTextSelecting_ = false;
    bool tooltipTextFocused_ = false;
    bool tooltipPointerIdleReferenceValid_ = false;
    bool mouseLeaveTracked_ = false;
    Point tooltipPointerIdleReference_;
    Point previousCursor_;
    Point lastCursor_;
    ID2D1Factory* d2dFactory_ = nullptr;
    ID2D1HwndRenderTarget* d2dRenderTarget_ = nullptr;
    ID2D1GdiInteropRenderTarget* d2dGdiInterop_ = nullptr;
    Size d2dRenderTargetSize_;
    bool direct2DUnavailable_ = false;
    int direct2DNativeSurfacePaintCount_ = 0;
    int direct2DNativeShaderPaintCount_ = 0;
    int direct2DHlslEffectPaintCount_ = 0;
    HDC backBufferDc_ = nullptr;
    HBITMAP backBufferBitmap_ = nullptr;
    HGDIOBJ backBufferOldBitmap_ = nullptr;
    Size backBufferSize_;
};

enum class DialogResult {
    None,
    Ok,
    Cancel,
    Yes,
    No,
    Close
};

enum class MessageBoxButtons {
    Ok,
    OkCancel,
    YesNo,
    YesNoCancel
};

enum class MessageBoxIcon {
    Info,
    Warning,
    Error,
    Question
};

struct MessageBoxOptions {
    std::wstring title;
    std::wstring message;
    MessageBoxButtons buttons = MessageBoxButtons::Ok;
    MessageBoxIcon icon = MessageBoxIcon::Info;
    Theme theme = Theme::taskBoardFamily();
    PopupStyle popupStyle = PopupStyle::fromTheme();
    WindowStyle windowStyle = WindowStyle::dialog();
    int width = 520;
    int height = 260;
};

class DialogWindow : public Window {
public:
    DialogWindow();

    bool createDialog(
        HINSTANCE instance,
        HWND owner,
        const std::wstring& title,
        int width,
        int height,
        DWORD style = WS_POPUP | WS_THICKFRAME | WS_SYSMENU,
        DWORD exStyle = WS_EX_TOOLWINDOW);

    void showModeless(int showCommand = SW_SHOWNORMAL);
    DialogResult showModal(HWND owner = nullptr);
    void closeWithResult(DialogResult result);
    DialogResult result() const;

protected:
    void onDestroying() override;

private:
    HWND owner_ = nullptr;
    DialogResult result_ = DialogResult::None;
    bool modalEnded_ = false;
};

DialogResult showMessageBox(HINSTANCE instance, HWND owner, MessageBoxOptions options);

} // namespace wdui
