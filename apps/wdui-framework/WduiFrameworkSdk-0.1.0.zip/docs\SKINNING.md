# Skiny a fonty

Výchozí skiny jsou JSON soubory v assets\skins. Při instalaci aplikace je kopíruj vedle EXE do složky skins.

Fonty jsou v assets\fonts. Jsou app-local a WDUi je načítá jen pro aktuální proces. Neinstaluj je do %WINDIR%\Fonts.

Základní runtime layout:

    my_app.exe
    skins\00-wdui-default-skins.json
    skins\01-wdui-black-gemstone-skins.json
    fonts\inter\Inter[opsz,wght].ttf
    fonts\...\OFL.txt

Vlastní skin přidej jako další skins\*.json. Pokud použije stejné id jako existující skin a načte se později, nahradí předchozí preset.