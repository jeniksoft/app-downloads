# WDUi výchozí JSON skiny

Tato složka obsahuje sdílené připravené WDUi skin presety jako JSON data.
`00-wdui-default-skins.json` drží hlavní výchozí katalog a
`01-wdui-black-gemstone-skins.json` přidává černé gemstone/soft-glass varianty
Emerald/Ruby/Sapphire/Amber Black a Neon Glass Black.

Build skripty trvalých aplikací kopírují `*.json` z této složky do složky
`dist\skins` každé aplikace a tyto soubory embedují do setupu. Setup je potom
rozbalí vedle nainstalovaného EXE do `skins\`.

WDUi samo tyto skiny nekompiluje do knihovny. Runtime discovery skinů čte každý
platný soubor `skins\*.json` vedle EXE přes `wdui::SkinCatalog::availableSkins()`.
Pokud je nainstalovaná složka `skins` prázdná, aplikace by měly dál fungovat s
běžným fallback stylingem WDUi.

Výchozí skiny by měly obsahovat palette/material data, volby app-local fontů,
data `shapes` a cílené `styles`/`variants` overrides tam, kde sdílená rodina
controlů musí napříč skiny vizuálně držet pohromadě. Hodnoty shape jsou
`rectangle`, `rounded-rect`, `capsule`, `diamond`, `beveled`, `octagon`,
`hexagon`, `slant-right` a `slant-left`; akceptují se aliasy jako `rect`,
`round-rect`, `win11-rounded`, `pill`, `rhombus`, `cut-corner`, `chamfer` a
`parallelogram-right`. `variants` mohou dodat několik vizuálních rolí stejného
controlu, například toolbar buttons, primary actions, danger actions, compact
selects, bitmap icon buttons nebo app-specific ids; pro dědění z jiného style id
stejného typu controlu používej `base`/`based_on`/`extends`.

Kompaktní blok `materials` je výchozí způsob, jak skin definuje svůj vizuální
materiálový jazyk. Měl by pojmenovat materiály `surface`, `control` a `accent`
plus sdílené hodnoty tint/strength/gradient. Přímé `styles` overrides používej
jen tehdy, když se konkrétní rodina controlů potřebuje od sdíleného
materiálového jazyka odchýlit. Tmavé divadelní skiny mohou používat
`obsidian_glass` pro lahvově černé povrchy a `blood_gloss` pro malé mokře
červené akcenty, ale červená má zůstat na malých plochách, pokud koncept skinu
výslovně nepožaduje červený povrch.
Výchozí skiny mají nastavovat i material `depth`, `light_angle` a
`light_elevation`, aby povrchy nepůsobily jako plochá bitmapová tapeta. Čisté
profesionální skiny drž nízko, crafted/gemstone/divadelní skiny mohou použít
silnější barevné světlo, ale pořád musí zůstat čitelné v `Balanced` profilu.
Amber/jantarové skiny mohou používat `amber_glass`: černé base fills,
medově-oranžové material tinty, tmavé spálené okraje a teplé bitmap tint palety
bez čistě bílé špičky, aby výsledek nepůsobil jako bílý odlesk na skle.
Soft/neon glass skiny mohou používat `luminous_glass`: skoro černé base fills,
barevný `backlight_color`, `inner_glow`, `rim_light`, velký `light_blob_scale`
a nízký grain. Tento materiál patří hlavně na panely, popupy, tooltipy,
title cards a vybrané dialogy; text musí zůstat čitelný i bez bloomu v rychlých
performance profilech.

Fonty výchozích skinů musí pocházet z `tools\win32-design-ui\default-fonts\`,
pokud product-specific skin výslovně nepřibaluje vlastní app-local složku fontů.
Nesměruj sdílené skiny na fonty, které nejsou přibalené nebo garantované
Windows.

Každý připravený skin by měl mít dostupné `styles.bitmap_button.default`,
`styles.bitmap_button.action` a `styles.bitmap_button.muted`. Tyto varianty
tintují monochromatické bitmap controls z rolí skinu (`text`, `accent`,
`accent_hot`, `muted_text`, `disabled_text`) a přitom zachovávají bitmap alpha
jako skutečnou průhlednost a hit mask. Výchozí varianty bitmap buttonů by měly
používat `palette_map` s plnou 32barvovou `palette`, aby se bitmap art mohl
přebarvit až na 32 současných zdrojových barev; bitmapy s méně barvami použijí
jen potřebnou část mapování. Nekopíruj jeden identický tint blok do každého
skinu: každý připravený skin by měl zvolit bitmap tint profil, který sedí jeho
materiálovému jazyku, včetně `mode`, `palette`, `secondary_role`,
`preserve_luminance`, `amount`, `coverage_threshold` a state-specific
normal/hot/pressed/active/disabled rolí tam, kde jsou užitečné.

Sdílená výchozí rodina Windows 11 je `win11-auto`, `win11-dark` a `win11-light`.
Aplikace mohou ukládat `win11-auto`; WDUi ho při renderování vyřeší na světlý
nebo tmavý preset podle Windows app light/dark setting.

Výchozí skiny nemají působit jako stejné UI přebarvené třináctkrát. Každý
připravený skin má zvolit tvary controlů a proporce scrollbarů podle svého
významu: klidné obdélníkové formuláře pro čisté profesionální skiny, beveled
tvary pro crafted/workbench skiny, hex/octagonal tvary pro game-like nebo signal
skiny a slanted tvary tam, kde má skin záměrně energický pocit. Platí to i pro
`ScrollBar` controls a `SelectBox` dropdown scrollbars; uvnitř jednoho skinu by
měly sdílet stejné metriky, ale ne nutně napříč všemi skiny.

Barvy scrollbar track, thumb, hot, pressed, shadow, glow a outline mají pořád
pocházet z aktivního skin theme, pokud skin nepotřebuje konkrétní override.
Arctic Instrument má zůstat ledový, Obsidian Atelier teplý/tmavý, Codex Forge
teal/gold a app-local skiny si mohou držet vlastní materiálový jazyk.

Toto jsou katalogová data, ne trvalé pravidlo WDUi. Jediné tvrdé pravidlo pro
shape je, že capsule má být skutečná capsule: průměr koncové čepičky se rovná
kratší straně kresleného rectu a zbytek délky tvoří tělo.

Když výchozí skin používá angled, cut, hexagonal, capsule nebo diamond povrchy,
jeho metriky musí nechat dost prostoru pro WDUi shape-safe obsah a layout area.
Text, table cells, combo items, input text, status chips, action labels a child
controls mají zůstat uvnitř použitelného tvaru po aplikování surface safe insetu
a vlastního paddingu controlu. Agresivní tvary jsou v pořádku pro vizuální
identitu, ale kompaktní controls pořád potřebují čitelné přirozené minimální
rozměry.
