param(
    [ValidateSet("Debug", "Release")]
    [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"

$examples = Split-Path -Parent $MyInvocation.MyCommand.Path
$sdkRoot = Split-Path -Parent $examples
$build = Join-Path $sdkRoot "build"
$obj = Join-Path $build "minimal_app.obj"
$exe = Join-Path $build "minimal_app.exe"

New-Item -ItemType Directory -Force -Path $build | Out-Null

if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) {
    throw "cl.exe was not found. Run this from an x64 Visual Studio Developer shell."
}

$compileFlags = @(
    "/nologo",
    "/std:c++20",
    "/utf-8",
    "/EHsc",
    "/DUNICODE",
    "/D_UNICODE",
    "/I$sdkRoot\include"
)
if ($Configuration -eq "Release") {
    $compileFlags += @("/O2", "/DNDEBUG")
} else {
    $compileFlags += @("/Zi", "/Od")
}

& cl.exe @compileFlags "/Fo$obj" /c (Join-Path $examples "minimal_app.cpp")
if ($LASTEXITCODE -ne 0) {
    throw "example compile failed with exit code $LASTEXITCODE"
}

& link.exe /nologo "/OUT:$exe" /SUBSYSTEM:WINDOWS $obj "$sdkRoot\lib\x64\wdui.lib" User32.lib Gdi32.lib D2d1.lib D3d11.lib Msimg32.lib Ole32.lib Advapi32.lib Windowscodecs.lib
if ($LASTEXITCODE -ne 0) {
    throw "example link failed with exit code $LASTEXITCODE"
}

Remove-Item -LiteralPath (Join-Path $build "skins") -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $build "fonts") -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -LiteralPath (Join-Path $sdkRoot "assets\skins") -Destination (Join-Path $build "skins") -Recurse -Force
Copy-Item -LiteralPath (Join-Path $sdkRoot "assets\fonts") -Destination (Join-Path $build "fonts") -Recurse -Force

Write-Host "wdui_example_built=$exe"