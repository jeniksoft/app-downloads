# WDUi Framework SDK 0.1.0

WDUi je proprietární C++/Win32 UI framework od Jeniksoft pro skinovatelné nativní Windows aplikace.

Tento veřejný SDK balík obsahuje hotovou x64 statickou knihovnu, veřejné hlavičky, výchozí skiny, app-local fonty, binární demo a ukázkový zdrojový kód aplikace. Neobsahuje zdrojové .cpp soubory knihovny.

## Obsah balíku

    include/wdui/           veřejné hlavičky
    lib/x64/wdui.lib        statická knihovna pro MSVC x64
    bin/wdui_demo.exe       binární demo a smoke nástroj
    assets/skins/           výchozí JSON skiny
    assets/fonts/           app-local fonty a OFL licence
    examples/               otevřené ukázky použití SDK
    docs/                   stručný návod a poznámky k licenci

## Rychlý start

1. Rozbal ZIP mimo systémové složky, například do C:\SDK\WDUi.
2. Otevři "x64 Native Tools Command Prompt for VS" nebo PowerShell s dostupným cl.exe.
3. Spusť:

    powershell -NoProfile -ExecutionPolicy Bypass -File examples\build_example.ps1

Výsledkem bude build\minimal_app.exe. Skript vedle EXE zkopíruje skins\ a fonts\, aby runtime našel výchozí WDUi assety.

## Linkování

Minimální MSVC link používá:

    /I include examples\minimal_app.cpp lib\x64\wdui.lib
    User32.lib Gdi32.lib D2d1.lib D3d11.lib Msimg32.lib Ole32.lib Advapi32.lib Windowscodecs.lib

Kompiluj jako C++20 a UTF-8:

    /std:c++20 /utf-8 /EHsc /DUNICODE /D_UNICODE

## Runtime assets

WDUi hledá skiny v skins\*.json vedle EXE a fonty v fonts\ vedle EXE. Fonty se načítají jako private process fonts, takže se neinstalují globálně do Windows.

## Licence

WDUi knihovna a veřejné hlavičky nejsou open source. Podrobnosti jsou v LICENSE-NOTICE.md.

Ukázkové zdroje v examples\ jsou volně použitelné pod MIT-0 licencí; viz examples\LICENSE-MIT-0.txt. Přibalené fonty jsou pod SIL Open Font License 1.1; ponech u nich příslušné OFL.txt.