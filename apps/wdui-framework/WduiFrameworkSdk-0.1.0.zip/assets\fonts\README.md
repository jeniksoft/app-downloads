# WDUi výchozí app-local fonty

Tato složka obsahuje sdílený balík WDUi fontů pro připravené JSON skiny.

Tyto fonty se k WDUi aplikacím přibalují jako aplikačně lokální assety. Build/setup
skripty by měly tuto složku kopírovat do nainstalované aplikace jako `fonts\`
vedle EXE aplikace. WDUi načítá `fonts\*.ttf`, `*.otf`, `*.ttc` a `*.otc`
rekurzivně přes `AddFontResourceExW(..., FR_PRIVATE)`, takže fonty vidí jen
aktuální proces. Neinstaluj je do `%WINDIR%\Fonts` a pro běžné balení WDUi
aplikace nezapisuj fontové registry keys.

Všechny zahrnuté rodiny fontů jsou pod licencí SIL Open Font License 1.1. Při
kopírování nebo embedování této složky ponech u každé rodiny její `OFL.txt`
vedle souborů fontu.

Zahrnuté rodiny:

* `inter` - proměnný UI font Inter, z Google Fonts / Inter, SIL OFL 1.1.
* `ibmplexsans` - proměnný UI font IBM Plex Sans, z Google Fonts / IBM Plex, SIL OFL 1.1.
* `atkinsonhyperlegible` - Atkinson Hyperlegible regular/bold, z Google Fonts / Braille Institute, SIL OFL 1.1.
* `exo2` - proměnný UI font Exo 2, z Google Fonts, SIL OFL 1.1.
* `rajdhani` - Rajdhani regular/semibold/bold, z Google Fonts, SIL OFL 1.1.
* `orbitron` - proměnný display font Orbitron, z Google Fonts, SIL OFL 1.1.
* `oxanium` - proměnný display/UI font Oxanium, z Google Fonts, SIL OFL 1.1.
* `nunito` - proměnný zaoblený UI font Nunito, z Google Fonts, SIL OFL 1.1.
* `jetbrainsmono` - proměnný mono font JetBrains Mono, z Google Fonts / JetBrains, SIL OFL 1.1.

Mapování výchozích skinů:

* Čisté Windows/profesionální skiny používají Inter, IBM Plex Sans nebo Atkinson Hyperlegible.
* Instrument/editor/ops skiny preferují Atkinson Hyperlegible kvůli čitelnosti.
* Jemné tmavé/luxusní skiny používají Nunito, když je žádoucí zaoblenější a méně mechanický UI hlas.
* Sci-fi, companion a 3D/gaming skiny používají Exo 2, Rajdhani, Orbitron nebo Oxanium.
* Monospace text používá v celém výchozím katalogu JetBrains Mono.
