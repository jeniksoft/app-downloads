#include <wdui/DesignUi.h>

#include <memory>
#include <string>

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int showCommand)
{
    wdui::setDefaultRenderBackend(wdui::RenderBackend::Auto);
    wdui::setDefaultPerformanceProfile(wdui::PerformanceProfile::Balanced);

    const wdui::Theme theme = wdui::Theme::taskBoardFamily();

    wdui::Window window;
    window.setBackgroundColor(theme.shell);
    if (!window.create(instance, L"WDUi Minimal Example", 720, 420)) {
        return 1;
    }

    auto title = std::make_unique<wdui::Label>(
        L"example.title",
        wdui::Rect{32, 28, 640, 32},
        L"WDUi minimal app",
        theme);
    title->setAlignment(wdui::TextAlignment::Center);
    window.root().add(std::move(title));

    auto* status = static_cast<wdui::Label*>(&window.root().add(std::make_unique<wdui::Label>(
        L"example.status",
        wdui::Rect{32, 92, 640, 72},
        L"Klikni na tlacitko. Handler pouziva typed CommandEvent, ne deprecated setOnClick.",
        theme)));
    status->setAlignment(wdui::TextAlignment::Center);

    auto button = std::make_unique<wdui::ThemedButton>(
        L"example.button",
        wdui::Rect{250, 190, 220, 44},
        L"Pozdravit",
        theme);
    button->setCommandId(L"say-hello");
    button->addCommandListener([status](wdui::CommandEvent& event) {
        if (event.commandId == L"say-hello") {
            status->setText(L"Ahoj z WDUi. Renderer je Auto a appka je cista Win32/C++.");
            event.markHandled();
        }
    });
    window.root().add(std::move(button));

    window.show(showCommand);
    return window.run();
}