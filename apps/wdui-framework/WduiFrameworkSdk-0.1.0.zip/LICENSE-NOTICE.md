# License Notice

WDUi Framework SDK je proprietární binární SDK od Jeniksoft.

Tento balík je veřejně ke stažení, ale WDUi knihovna, veřejné hlavičky, JSON skiny a související runtime assety nejsou vydané jako open-source projekt. Není udělena licence k redistribuci samotného SDK, repackagingu knihovny nebo publikování zdrojových souborů knihovny bez samostatného svolení Jeniksoft.

Aplikace vytvořené s tímto SDK mohou linkovat wdui.lib podle domluvených podmínek projektu. Pokud potřebuješ distribuovat WDUi SDK dál, domluv si licenci přímo s Jeniksoft.

Složka examples\ je výjimka: ukázkové zdrojové soubory můžeš používat, kopírovat a upravovat pod MIT-0 licencí; viz examples\LICENSE-MIT-0.txt.

Přibalené fonty jsou licencované samostatně pod SIL Open Font License 1.1. Ponech u nich příslušné OFL.txt soubory.